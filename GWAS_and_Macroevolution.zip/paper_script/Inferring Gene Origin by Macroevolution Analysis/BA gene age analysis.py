#brain
import os,pickle,sys,math
import pandas as pd
import numpy as np
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from collections import Counter
from scipy.stats import binom_test
from gene_age_function import gene_age_process_1,age_inf,gene_age_process_0,gene_age_process_2,gene_age_process_0_greater,gene_age_process_1_greater,gene_age_process_2_greater,ensembl_id_name_1,gene_age_process_2017_greater
from matplotlib import pyplot as plt
import matplotlib.lines as lines
import matplotlib as mpl
import matplotlib.patches as mpathes
mpl.rcParams['pdf.fonttype'] = 42
from matplotlib_venn import venn2


path = '/data/user/msd/ukbiobank_asymmetry/gene_age/gene_age.csv'
dict_sbp,dict_sbp_label,dict_historian,dict_historian_label = age_inf(path)
path2 = '/data/user/msd/human_genome/hgnc_complete_set_2023-03-02.txt'
table_inf = pd.read_table(path2)
dictionary1 = dict(zip(table_inf['symbol'],table_inf['ensembl_gene_id']))
table_whole2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t')

age_inf_3_2 = table_whole2.loc[table_whole2['emsembl_phenoscanner'] !='-',:]
gene_names = list(set(age_inf_3_2['emsembl_phenoscanner']))
age_inf_4 = table_whole2.loc[(table_whole2['Func.refGene_annovar']!='.') & (table_whole2['Func.refGene_annovar']!='intergenic'),: ]
age_inf_5 = age_inf_4.loc[age_inf_4['Gene.refGene_annovar'].apply(lambda x: ';' not in x),:]
list_genes = list(Counter(age_inf_5['Gene.refGene_annovar']).keys())
list_genes3 = set(list_genes).intersection(set(dictionary1.keys()))
list_genes4 = [dictionary1[a] for a in list_genes3]
list_genes5 = set(list_genes4)
list_genes_annovar_pA = list(list_genes5)

subset = [set(gene_names),set(list_genes_annovar_pA)]
fig,axes = plt.subplots(1,1,figsize=(3,3))
g=venn2(subsets=subset, set_labels=('Phenoscanner', 'Annovar'),ax=axes)
axes.set_title('intersection between Annovar and Phenoscanner',size=8)
plt.savefig('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_intersection_brain_ann_phe_1.pdf')


all1 = list(set(gene_names+list_genes_annovar_pA))
with open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_GENE_in_brain_clump_instance2.txt','w') as f:
    for a in all1:
        f.write(a+'\n')

#genetree
#genetree
gene_names1 = list(set(all1).intersection(set(dict_sbp.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_0_greater(gene_names1,dict_sbp)
aaaaa = [[a,dict_sbp[a] ]for a in gene_names1]
bbbbb = pd.DataFrame(aaaaa)
bbbbb.columns = ['gene_name','clade']
bbbbb.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_clumped_genetree_snp_geneage_41.csv')
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_41.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_raw41.csv')
#historian
gene_names1 = list(set(all1).intersection(set(dict_historian.keys())))
aaaaa = [[a,dict_historian[a] ]for a in gene_names1]
bbbbb = pd.DataFrame(aaaaa)
bbbbb.columns = ['gene_name','clade']
bbbbb.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_clumped_historian_snp_geneage_41.csv')
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_1_greater(gene_names1,dict_historian)
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_41.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_raw41.csv')

#sbp for whole gene set
gene_names1 = list(set(all1).intersection(set(dict_sbp.keys())))
gene_ages = Counter([dict_sbp[a] for a in gene_names1])#所有基因对应的年龄
gene_ages_0 = Counter(dict_sbp.values())
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_0_greater(gene_names1,dict_sbp)

length_1 = len(gene_names1)
length_2 = len(dict_sbp)
length_1 = length_1 - gene_ages[0]
length_2 = length_2 - gene_ages_0[0]
list_1 = []
for n in range(14):
    if n in [0]:
        continue
    list_1.append(binom_test(gene_ages[n], length_1, p=(gene_ages_0[n] / length_2),alternative='greater'))
gene_ages_compare1 = gene_ages_compare.drop([0])
gene_ages_compare1.columns = ['planA', 'origin']
gene_ages_compare1['planA'] = gene_ages_compare1['planA'] / (length_1)
gene_ages_compare1['origin'] = gene_ages_compare1['origin'] / (length_2)
gene_ages_compare1.insert(loc=2, column='pvalue_drop_' + str(1), value=list_1)
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_drop_0_1.csv')

length_1 = length_1 - gene_ages[1]
length_2 = length_2 - gene_ages_0[1]
list_1 = []
for n in range(14):
    if n in [0,1]:
        continue
    list_1.append(binom_test(gene_ages[n], length_1, p=(gene_ages_0[n] / length_2),alternative='greater'))
gene_ages_compare1 = gene_ages_compare.drop([0,1])
gene_ages_compare1.columns = ['planA', 'origin']
gene_ages_compare1['planA'] = gene_ages_compare1['planA'] / (length_1)
gene_ages_compare1['origin'] = gene_ages_compare1['origin'] / (length_2)
gene_ages_compare1.insert(loc=2, column='pvalue_drop_' + str(2), value=list_1)
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_drop_0-1_1.csv')


#historian for whole gene set
gene_names1 = list(set(all1).intersection(set(dict_historian.keys())))
gene_ages = Counter([dict_historian[a] for a in gene_names1])#所有基因对应的年龄
gene_ages_0 = Counter(dict_historian.values())
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_1_greater(gene_names1,dict_historian)

length_1 = len(gene_names1)
length_2 = len(dict_historian)
length_1 = length_1 - gene_ages[12]
length_2 = length_2 - gene_ages_0[12]
list_1 = []
for n in range(16):
    if n in [12]:
        continue
    list_1.append(binom_test(gene_ages[n], length_1, p=(gene_ages_0[n] / length_2),alternative='greater'))
gene_ages_compare1 = gene_ages_compare.drop([12])
gene_ages_compare1.columns = ['planA', 'origin']
gene_ages_compare1['planA'] = gene_ages_compare1['planA'] / (length_1)
gene_ages_compare1['origin'] = gene_ages_compare1['origin'] / (length_2)
gene_ages_compare1.insert(loc=2, column='pvalue_drop_' + str(1), value=list_1)
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_drop_12_1.csv')

length_1 = length_1 - gene_ages[9]
length_2 = length_2 - gene_ages_0[9]
list_1 = []
for n in range(16):
    if n in [12,9]:
        continue
    list_1.append(binom_test(gene_ages[n], length_1, p=(gene_ages_0[n] / length_2),alternative='greater'))
gene_ages_compare1 = gene_ages_compare.drop([12,9])
gene_ages_compare1.columns = ['planA', 'origin']
gene_ages_compare1['planA'] = gene_ages_compare1['planA'] / (length_1)
gene_ages_compare1['origin'] = gene_ages_compare1['origin'] / (length_2)
gene_ages_compare1.insert(loc=2, column='pvalue_drop_' + str(2), value=list_1)
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_drop_12-9_1.csv')

length_1 = length_1 - gene_ages[11]
length_2 = length_2 - gene_ages_0[11]
list_1 = []
for n in range(16):
    if n in [12,9,11]:
        continue
    list_1.append(binom_test(gene_ages[n], length_1, p=(gene_ages_0[n] / length_2),alternative='greater'))
gene_ages_compare1 = gene_ages_compare.drop([12,9,11])
gene_ages_compare1.columns = ['planA', 'origin']
gene_ages_compare1['planA'] = gene_ages_compare1['planA'] / (length_1)
gene_ages_compare1['origin'] = gene_ages_compare1['origin'] / (length_2)
gene_ages_compare1.insert(loc=2, column='pvalue_drop_' + str(3), value=list_1)
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_drop_12-9-11_1.csv')


import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.lines as lines
import matplotlib as mpl
import matplotlib.patches as mpathes
mpl.rcParams['pdf.fonttype'] = 42
plt.rcParams['font.serif'] = ['Times New Roman']

fig,axes = plt.subplots(figsize = [6,3])
for i in range(15):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,40)
axes.text(17,14.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,12.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,11.8, color='black',s=' Rhesus',size = '7')
axes.text(17,10.8, color='black',s=' Murinae',size = '7')
axes.text(17,9.8, color='black',s=' Laurasiatheria',size = '7')
axes.text(17,8.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,7.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,6.8, color='black',s=' Gallus gallus',size = '7')
axes.text(17,5.8, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,4.8, color='black',s=' Clupeocephala',size = '7')
axes.text(17,3.8, color='black',s=' Ciona intestinalis',size = '7')
axes.text(17,2.8, color='black',s=' Strongylocentrotus purpuratus',size = '7')
axes.text(17,1.8, color='black',s=' Ecdysozoa',size = '7')
axes.text(17,0.8, color='black',s=' Ascomycota',size = '7')
axes.text(17,-0.2, color='black',s=' Other Eukaryota',size = '7')
axes.text(17,-1.2, color='black',s=' Bacteria and Archaea',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,17)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_41.csv')
axes.set_xlim(-95,60)

for i in range(16):
    i1 = 15-i
    if dataframe2['pvalue'][i1] < (0.05):
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], dataframe2['origin'][i1]*100,0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0 - dataframe2['planA'][i1]*100,0.6,facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-60,-0.3+i*(1)],dataframe2['origin'][i1]*100,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0-dataframe2['planA'][i1]*100,0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i1] < (0.01):
        axes.text(-32,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i1] < (0.1):
        axes.text(-32, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-60,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_raw41.csv')
phylo_name = ['Cellular_Organisms ','Eukaryota ','Opisthokonta ','Bilateria ','Deuterostomia ','Chordata ','Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Euarchontoglires ','Catarrhini ','Homininae ','HUMAN ']
for i in range(16):
    i1 = 15-i
    axes.text(-59+dataframe2['origin'][i1]*100,i-0.2, color='black',s=str(int(dataframe1['origin'][i1])),size = '7')
    if np.isnan(dataframe1['planA'][i1]):
        axes.text(-61,i-0.2, color='black', s=str(0), size='7',ha='right')
    else:
        axes.text(-61 - dataframe2['planA'][i1] * 100, i - 0.2, color='black', s=str(int(dataframe1['planA'][i1])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-90,-80,-70, -60,-50, -40,-30])
axes.set_xticklabels([abs(abs(a)-60)/100 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_fig_brain_5_A_historian_brain_2_small.pdf')


fig,axes = plt.subplots(figsize = [6,3])
for i in range(13):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,35)
axes.text(17,12.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,10.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,9.8, color='black',s=' Pongo pygmaeus abelii',size = '7')
axes.text(17,8.8, color='black',s=' Nomascus leucogenys',size = '7')
axes.text(17,7.8, color='black',s=' Macaca mulatta',size = '7')
axes.text(17,6.8, color='black',s=' Callithrix jacchus',size = '7')
axes.text(17,5.8, color='black',s=' Mus musculus,Oryctolagus cuniculus,etc.',size = '7')
axes.text(17,4.8, color='black',s=' Canis lupus familiaris,Bos taurus,etc.',size = '7')
axes.text(17,3.8, color='black',s=' Loxodonta africana',size = '7')
axes.text(17,2.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,1.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,0.8, color='black',s=' Gallus gallus,zebra finch,etc.',size = '7')
axes.text(17,-0.2, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,-1.2, color='black',s=' Danio rerio,Tetraodon nigroviridis,etc.',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,14)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_41.csv')
axes.set_xlim(-140,100)

for i in range(14):
    if dataframe2['pvalue'][i] < (0.05):
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], dataframe2['origin'][i]*50, 0.6, facecolor='red',)
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0 - dataframe2['planA'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-95,-0.3+i*(1)],dataframe2['origin'][i]*50,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0-dataframe2['planA'][i]*50, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i] < (0.01):
        axes.text(-45,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i] < (0.1):
        axes.text(-45, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-95,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_raw41.csv')
phylo_name = ['Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Boreoeutheria ','Euarchontoglires ','Simiiformes ','Catarrhini ','Hominoidea ','Hominidae ','Homininae ','Homo Sapiens ',]
for i in range(14):
    axes.text(-94+dataframe2['origin'][i]*50,i-0.2, color='black',s=str(int(dataframe1['origin'][i])),size = '7')
    if np.isnan(dataframe1['planA'][i]):
        axes.text(-96,i-0.2, color='black', s=str(int(0)), size='7',ha='right')
    else:
        axes.text(-96 - dataframe2['planA'][i] * 50, i - 0.2, color='black', s=str(int(dataframe1['planA'][i])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-135,-115, -95,-75, -55])
axes.set_xticklabels([abs(abs(a)-95)/50 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_fig_brain_5_A_brain_sbp_2_small.pdf')


#up-down HGNC
fig,axes = plt.subplots(figsize = [6,3])
for i in range(15):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,40)
axes.text(17,14.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,12.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,11.8, color='black',s=' Rhesus',size = '7')
axes.text(17,10.8, color='black',s=' Murinae',size = '7')
axes.text(17,9.8, color='black',s=' Laurasiatheria',size = '7')
axes.text(17,8.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,7.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,6.8, color='black',s=' Gallus gallus',size = '7')
axes.text(17,5.8, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,4.8, color='black',s=' Clupeocephala',size = '7')
axes.text(17,3.8, color='black',s=' Ciona intestinalis',size = '7')
axes.text(17,2.8, color='black',s=' Strongylocentrotus purpuratus',size = '7')
axes.text(17,1.8, color='black',s=' Ecdysozoa',size = '7')
axes.text(17,0.8, color='black',s=' Ascomycota',size = '7')
axes.text(17,-0.2, color='black',s=' Other Eukaryota',size = '7')
axes.text(17,-1.2, color='black',s=' Bacteria and Archaea',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,17)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/all_brain_his_updown_41.csv')
axes.set_xlim(-95,60)

for i in range(16):
    i1 = 15-i
    if dataframe2['pvalue'][i1] < (0.05):
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], dataframe2['origin'][i1]*100, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0 - dataframe2['planA'][i1]*100, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-60,-0.3+i*(1)],dataframe2['origin'][i1]*100,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0-dataframe2['planA'][i1]*100, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i1] < (0.01):
        axes.text(-32,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i1] < (0.1):
        axes.text(-32, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-60,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/all_brain_his_updown_raw41.csv')
phylo_name = ['Cellular_Organisms ','Eukaryota ','Opisthokonta ','Bilateria ','Deuterostomia ','Chordata ','Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Euarchontoglires ','Catarrhini ','Homininae ','HUMAN ']
for i in range(16):
    i1 = 15-i
    #axes.text(-59+dataframe2['origin'][i1]*100,i-0.2, color='black',s=str(int(dataframe1['origin'][i1])),size = '7')
    if np.isnan(dataframe1['planA'][i1]):
        axes.text(-61,i-0.2, color='black', s=str(0)+'(1)', size='7',ha='right')
    else:
        axes.text(-61 - dataframe2['planA'][i1] * 100, i - 0.2, color='black', s=str(int(dataframe1['planA'][i1]))+'('+str(round(dataframe2['pvalue'][i1],2))+')',size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-90,-80,-70, -60,-50, -40,-30])
axes.set_xticklabels([abs(abs(a)-60)/100 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/fig_brain_5_A_historian_brain_2_updown_small.pdf')


fig,axes = plt.subplots(figsize = [6,3])
for i in range(13):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,35)
axes.text(17,12.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,10.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,9.8, color='black',s=' Pongo pygmaeus abelii',size = '7')
axes.text(17,8.8, color='black',s=' Nomascus leucogenys',size = '7')
axes.text(17,7.8, color='black',s=' Macaca mulatta',size = '7')
axes.text(17,6.8, color='black',s=' Callithrix jacchus',size = '7')
axes.text(17,5.8, color='black',s=' Mus musculus,Oryctolagus cuniculus,etc.',size = '7')
axes.text(17,4.8, color='black',s=' Canis lupus familiaris,Bos taurus,etc.',size = '7')
axes.text(17,3.8, color='black',s=' Loxodonta africana',size = '7')
axes.text(17,2.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,1.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,0.8, color='black',s=' Gallus gallus,zebra finch,etc.',size = '7')
axes.text(17,-0.2, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,-1.2, color='black',s=' Danio rerio,Tetraodon nigroviridis,etc.',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,14)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/all_brain_sbp_updown_41.csv')
axes.set_xlim(-140,100)

for i in range(14):
    if dataframe2['pvalue'][i] < (0.05):
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], dataframe2['origin'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0 - dataframe2['planA'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-95,-0.3+i*(1)],dataframe2['origin'][i]*50,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0-dataframe2['planA'][i]*50, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i] < (0.01):
        axes.text(-45,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i] < (0.1):
        axes.text(-45, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-95,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/all_brain_sbp_updown_raw41.csv')
phylo_name = ['Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Boreoeutheria ','Euarchontoglires ','Simiiformes ','Catarrhini ','Hominoidea ','Hominidae ','Homininae ','Homo Sapiens ',]
for i in range(14):
    #axes.text(-94+dataframe2['origin'][i]*50,i-0.2, color='black',s=str(int(dataframe1['origin'][i])),size = '7')
    if np.isnan(dataframe1['planA'][i]):
        axes.text(-96,i-0.2, color='black', s=str(int(0)), size='7',ha='right')
    else:
        axes.text(-96 - dataframe2['planA'][i] * 50, i - 0.2, color='black', s=str(int(dataframe1['planA'][i])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-135,-115, -95,-75, -55])
axes.set_xticklabels([abs(abs(a)-95)/50 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/fig_brain_5_A_brain_sbp_2_updown_small.pdf')


####################degenerated ProteinHistorian
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.lines as lines
import matplotlib as mpl
import matplotlib.patches as mpathes
mpl.rcParams['pdf.fonttype'] = 42

fig,axes = plt.subplots(figsize = [6,3])
for i in range(15):
    if i <6:
        continue
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 6], [6, 6], color='black',linewidth=0.5)
axes.set_xlim(-5,35)
axes.text(17,14.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,12.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,11.8, color='black',s=' Rhesus',size = '7')
axes.text(17,10.8, color='black',s=' Murinae',size = '7')
axes.text(17,9.8, color='black',s=' Laurasiatheria',size = '7')
axes.text(17,8.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,7.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,6.8, color='black',s=' Gallus gallus',size = '7')
axes.text(17,5.8, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,4.8, color='black',s=' Clupeocephala',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(4,17)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_41.csv')
axes.set_xlim(-110,55)

for i in range(16):
    i1 = 15-i
    if i1 >8:
        continue
    if dataframe2['pvalue'][i1] < (0.05):
        rect = mpathes.Rectangle([-88, -0.6 + i * (1)], dataframe2['origin'][i1]*20, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-88, -0.6 + i * (1)], 0 - dataframe2['planA'][i1]*20, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-88,-0.3+i*(1)],dataframe2['origin'][i1]*20,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-88, -0.3 + i * (1)], 0-dataframe2['planA'][i1]*20, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i1] < (0.01):
        axes.text(-80,i-0.6,color='brown',size='large',s='**')
    elif dataframe2['pvalue'][i1] < (0.1):
        axes.text(-80, i-0.6, color='brown', size='large', s='*')
axes.axvline(x=-88,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_raw41.csv')
phylo_name = ['Cellular_Organisms ','Eukaryota ','Opisthokonta ','Bilateria ','Deuterostomia ','Chordata ','Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Euarchontoglires ','Catarrhini ','Homininae ','Human ']
for i in range(16):
    i1 = 15-i
    if i1 >8:
        continue
    axes.text(-87+dataframe2['origin'][i1]*20,i-0.2, color='black',s=str(int(dataframe1['origin'][i1])),size = '7')
    if np.isnan(dataframe1['planA'][i1]):
        axes.text(-89,i-0.2, color='black', s=str(int(0)), size='7',ha='right')
    else:
        axes.text(-89 - dataframe2['planA'][i1] * 20, i - 0.2, color='black', s=str(int(dataframe1['planA'][i1])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
m=9
dataframe1_before = dataframe1.iloc[m:,:].sum()
axes.text(-87+dataframe2['origin'][16]*20,(15-m)-0.2, color='black',s=str(int(dataframe1_before['origin'])),size = '7')
axes.text(-89 - dataframe2['planA'][16] * 20, (15-m) - 0.2, color='black', s=str(int(dataframe1_before['planA'])),size='7', ha='right')
rect = mpathes.Rectangle([-88, -0.3 + (15-m) * (1)], dataframe2['origin'][16] * 20, 0.6, facecolor='red')
axes.add_patch(rect)
rect = mpathes.Rectangle([-88, -0.3 + (15-m) * (1)], 0 - dataframe2['planA'][16] * 20, 0.6, facecolor='red')
axes.text(-60, (15-m)-0.3, color='brown', size='7', s='**')
axes.add_patch(rect)
axes.text(-3,6-0.2, color='black', s='all clades before Tetrapoda ', size='7',ha='right')
axes.set_xticks([-108,-98,-88, -78,-68])
axes.set_xticklabels([abs(abs(a)-88)/20 for a in axes.get_xticks()])
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_fig_brain_5_A_historian_brain_oldclades_2_small.pdf')
