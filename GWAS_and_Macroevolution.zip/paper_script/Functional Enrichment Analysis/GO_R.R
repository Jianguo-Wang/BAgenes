library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)


makeGOdotplot<-function(GO){
  test=as.data.frame(GO)
  test=test[1:10,]
  library(stringr)
  gr1 <- as.numeric(str_split(test$GeneRatio,"/",simplify = T)[,1])
  gr2 <- as.numeric(str_split(test$GeneRatio,"/",simplify = T)[,2])
  bg1 <- as.numeric(str_split(test$BgRatio,"/",simplify = T)[,1])
  bg2 <- as.numeric(str_split(test$BgRatio,"/",simplify = T)[,2])
  test$fold <- round((gr1/gr2)/(bg1/bg2),2)
  test$GeneRatio <- (gr1/gr2)
  test <- arrange(test,GeneRatio)
  test$Description = factor(test$Description,levels = test$Description,ordered = T)
  ggplot(test,aes(x = GeneRatio,y = Description,label=as.character(fold)))+
    geom_point(aes(color = p.adjust,size = Count))+
    geom_text(nudge_x = 0.01)+
    scale_color_gradient(low = "red", high = "blue")+
    xlab("GeneRatio")+ylab('GO')+theme(axis.text.y = element_text(angle=45,hjust=1))+
    theme_bw()
}
makeGOdotplot1<-function(GO){
  test=as.data.frame(GO)
  test=test[,]
  library(stringr)
  gr1 <- as.numeric(str_split(test$GeneRatio,"/",simplify = T)[,1])
  gr2 <- as.numeric(str_split(test$GeneRatio,"/",simplify = T)[,2])
  bg1 <- as.numeric(str_split(test$BgRatio,"/",simplify = T)[,1])
  bg2 <- as.numeric(str_split(test$BgRatio,"/",simplify = T)[,2])
  test$fold <- round((gr1/gr2)/(bg1/bg2),2)
  test$GeneRatio <- (gr1/gr2)
  test <- arrange(test,GeneRatio)
  test$Description = factor(test$Description,levels = test$Description,ordered = T)
  ggplot(test,aes(x = GeneRatio,y = Description,label=as.character(fold)))+
    geom_point(aes(color = p.adjust,size = Count))+
    geom_text(nudge_x = 0.01)+
    scale_color_gradient(low = "red", high = "blue")+
    xlab("GeneRatio")+ylab('GO')+theme(axis.text.y = element_text(angle=45,hjust=1))+
    theme_bw()
}

table = read.table("/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_GENE_in_brain_clump_instance2.txt",sep = '\t')
ac_genes = c(table[,1])

ac_GO_BP<-enrichGO(gene=ac_genes, OrgDb = org.Hs.eg.db,ont = 'BP',keyType = 'ENSEMBL')
ac_GO_MF<-enrichGO(gene=ac_genes, OrgDb = org.Hs.eg.db,ont = 'MF',keyType = 'ENSEMBL')
ac_GO_CC<-enrichGO(gene=ac_genes, OrgDb = org.Hs.eg.db,ont = 'CC',keyType = 'ENSEMBL')


table1_BP = as.data.frame(ac_GO_BP)
table1_MF = as.data.frame(ac_GO_MF)
table1_CC = as.data.frame(ac_GO_CC)

makeGOdotplot(ac_GO_BP)
makeGOdotplot1(ac_GO_MF)
makeGOdotplot(ac_GO_CC)
write.table(table1_BP,'/data/user/msd/ukbiobank_asymmetry/compare_2_time/table_GO_R_BP.txt',sep='\t',row.names = FALSE)
write.table(table1_MF,'/data/user/msd/ukbiobank_asymmetry/compare_2_time/table_GO_R_MF.txt',sep='\t',row.names = FALSE)
write.table(table1_CC,'/data/user/msd/ukbiobank_asymmetry/compare_2_time/table_GO_R_CC.txt',sep='\t',row.names = FALSE)

