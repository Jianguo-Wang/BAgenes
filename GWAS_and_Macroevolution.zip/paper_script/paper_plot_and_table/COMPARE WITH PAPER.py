import pandas as pd
import numpy as np
from collections import    Counter
import sys
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from gene_age_function import ensembl_id_name_1

path2 = '/data/user/msd/human_genome/hgnc_complete_set_2023-03-02.txt'
table_inf = pd.read_table(path2)
dictionary2 = dict(zip(table_inf['symbol'],table_inf['ensembl_gene_id']))

table_whole2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t')
table_whole_nhb = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/2222.csv')
table_whole_nhb1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/1111.txt',header=None).T
table_whole_nhb1.insert(loc= 0,column='ensembl_id',value=table_whole_nhb1.iloc[:,0].apply(lambda x:  dictionary2[x] if x in dictionary2.keys() else np.nan))
all111 = list(set(table_whole_nhb1.iloc[:,0]))
table_whole_handness = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/handedness_genes.csv')
table_whole_nhb.insert(loc= 0,column='ensembl_id',value=table_whole_nhb.iloc[:,0].apply(lambda x:  dictionary2[x] if x in dictionary2.keys() else np.nan))
all222 = list(set(table_whole_nhb.iloc[:,0]))
all222.remove(np.nan)
table_whole_handness.insert(loc= 0,column='ensembl_id',value=table_whole_handness.iloc[:,0].apply(lambda x:  dictionary2[x] if x in dictionary2.keys() else np.nan))

age_inf_3_2 = table_whole2.loc[table_whole2['emsembl_phenoscanner'] !='-',:]
gene_names = list(set(age_inf_3_2['emsembl_phenoscanner']))
age_inf_4 = table_whole2.loc[(table_whole2['Func.refGene_annovar']!='.') & (table_whole2['Func.refGene_annovar']!='intergenic'),: ]
age_inf_5 = age_inf_4.loc[age_inf_4['Gene.refGene_annovar'].apply(lambda x: ';' not in x),:]
list_genes = list(Counter(age_inf_5['Gene.refGene_annovar']).keys())
list_genes3 = set(list_genes).intersection(set(dictionary2.keys()))
list_genes4 = [dictionary2[a] for a in list_genes3]
list_genes5 = set(list_genes4)
list_genes_annovar_pA = list(list_genes5)
all1 = list(set(gene_names+list_genes_annovar_pA))

table_whole_handedness = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/handedness sha paper gene list.txt',sep='\t',header=None)
table_whole_handedness.columns=['gene_name']
table_whole_handedness.insert(loc= 0,column='ensembl_id',value=table_whole_handedness.iloc[:,0].apply(lambda x:  dictionary2[x] if x in dictionary2.keys() else np.nan))
table_whole_handedness.insert(loc= 2,column='overlap_with_our_geneset',value=table_whole_handedness['ensembl_id'].apply(lambda x:  'overlap' if x in all1 else 'unidentified'))

table_32989287_handedness = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/handedness 32989287 paper gene list.txt',sep='\t',header=None)
table_32989287_handedness.columns=['gene_name']
table_32989287_handedness.insert(loc= 0,column='ensembl_id',value=table_32989287_handedness.iloc[:,0].apply(lambda x:  dictionary2[x] if x in dictionary2.keys() else np.nan))
table_32989287_handedness.insert(loc= 2,column='overlap_with_our_geneset',value=table_32989287_handedness['ensembl_id'].apply(lambda x:  'overlap' if x in all1 else 'unidentified'))


table_whole_nhb.insert(loc= 2,column='overlap_with_our_geneset',value=table_whole_nhb['ensembl_id'].apply(lambda x:  'overlap' if x in all1 else 'unidentified'))
table_whole_handness.insert(loc= 2,column='overlap_with_our_geneset',value=table_whole_handness['ensembl_id'].apply(lambda x:  'overlap' if x in all1 else 'unidentified'))

table_whole_nhb.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/nature_human_behavior_compare.csv')
table_whole_handness.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/handedness_gwas_compare.csv')
table_whole_handedness.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/handedness_sha_gwas_compare.csv')
table_32989287_handedness.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/handedness_32989287_gwas_compare.csv')

genes_rare_mutant = ['CDC42', 'FAM172A','ITIH5', 'BCL11B', 'LRCH1', 'ENPP2', 'SEMA3D', 'WNT4', 'TLN2', 'KIAA0825']
genes_rare_mutant1 = pd.DataFrame(genes_rare_mutant)
genes_rare_mutant1.columns=['gene_name']
genes_rare_mutant1.insert(loc= 0,column='ensembl_id',value=genes_rare_mutant1.iloc[:,0].apply(lambda x:  dictionary2[x] if x in dictionary2.keys() else np.nan))
genes_rare_mutant1.insert(loc= 2,column='overlap_with_our_geneset',value=genes_rare_mutant1['ensembl_id'].apply(lambda x:  'overlap' if x in all1 else 'unidentified'))
genes_rare_mutant1.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/RARE_mutant_gwas_compare.csv')

set(all1).intersection(table_whole_handness['ensembl_id'])

all2 = list(set(all1+list(table_whole_nhb['ensembl_id'])))
all2.remove(np.nan)

import os,pickle,sys,math
import pandas as pd
import numpy as np
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from collections import Counter
from scipy.stats import binom_test
from gene_age_function import gene_age_process_1,age_inf,gene_age_process_0,gene_age_process_2,gene_age_process_0_greater,gene_age_process_1_greater,gene_age_process_2_greater,ensembl_id_name_1,gene_age_process_2017_greater

path = '/data/user/msd/ukbiobank_asymmetry/gene_age/gene_age.csv'
dict_sbp,dict_sbp_label,dict_historian,dict_historian_label = age_inf(path)
path2 = '/data/user/msd/human_genome/hgnc_complete_set_2023-03-02.txt'
table_inf = pd.read_table(path2)
dictionary1 = dict(zip(table_inf['symbol'],table_inf['ensembl_gene_id']))


#significant enrichment genes in Sha's study
gene_names1 = list(set(all222).intersection(set(dict_sbp.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_0_greater(gene_names1,dict_sbp)
aaaaa = [[a,dict_sbp[a] ]for a in gene_names1]
bbbbb = pd.DataFrame(aaaaa)
bbbbb.columns = ['gene_name','clade']
bbbbb.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_clumped_nhb_Sha_gentree_geneage.csv')
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_53.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_raw53.csv')
#historian
gene_names1 = list(set(all222).intersection(set(dict_historian.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_1_greater(gene_names1,dict_historian)
aaaaa = [[a,dict_historian[a] ]for a in gene_names1]
bbbbb = pd.DataFrame(aaaaa)
bbbbb.columns = ['gene_name','clade']
bbbbb.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_clumped_nhb_Sha_historian_geneage.csv')
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_53.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_raw53.csv')

###############plot#########################
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.lines as lines
import matplotlib as mpl
import matplotlib.patches as mpathes
mpl.rcParams['pdf.fonttype'] = 42
plt.rcParams['font.serif'] = ['Times New Roman']

fig,axes = plt.subplots(figsize = [6,3])
for i in range(15):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,40)
axes.text(17,14.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,12.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,11.8, color='black',s=' Rhesus',size = '7')
axes.text(17,10.8, color='black',s=' Murinae',size = '7')
axes.text(17,9.8, color='black',s=' Laurasiatheria',size = '7')
axes.text(17,8.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,7.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,6.8, color='black',s=' Gallus gallus',size = '7')
axes.text(17,5.8, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,4.8, color='black',s=' Clupeocephala',size = '7')
axes.text(17,3.8, color='black',s=' Ciona intestinalis',size = '7')
axes.text(17,2.8, color='black',s=' Strongylocentrotus purpuratus',size = '7')
axes.text(17,1.8, color='black',s=' Ecdysozoa',size = '7')
axes.text(17,0.8, color='black',s=' Ascomycota',size = '7')
axes.text(17,-0.2, color='black',s=' Other Eukaryota',size = '7')
axes.text(17,-1.2, color='black',s=' Bacteria and Archaea',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,17)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_53.csv')
axes.set_xlim(-95,60)

for i in range(16):
    i1 = 15-i
    if dataframe2['pvalue'][i1] < (0.05):
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], dataframe2['origin'][i1]*100, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0 - dataframe2['planA'][i1]*100, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-60,-0.3+i*(1)],dataframe2['origin'][i1]*100,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0-dataframe2['planA'][i1]*100, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i1] < (0.01):
        axes.text(-32,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i1] < (0.1):
        axes.text(-32, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-60,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_raw53.csv')
phylo_name = ['Cellular_Organisms ','Eukaryota ','Opisthokonta ','Bilateria ','Deuterostomia ','Chordata ','Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Euarchontoglires ','Catarrhini ','Homininae ','HUMAN ']
for i in range(16):
    i1 = 15-i
    #axes.text(-59+dataframe2['origin'][i1]*100,i-0.2, color='black',s=str(int(dataframe1['origin'][i1])),size = '7')
    if np.isnan(dataframe1['planA'][i1]):
        axes.text(-61,i-0.2, color='black', s=str(0)+'(1)', size='7',ha='right')
    else:
        axes.text(-61 - dataframe2['planA'][i1] * 100, i - 0.2, color='black', s=str(int(dataframe1['planA'][i1]))+'('+str(round(dataframe2['pvalue'][i1],2))+')',size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-90,-80,-70, -60,-50, -40,-30])
axes.set_xticklabels([abs(abs(a)-60)/100 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_nhb_his_2_sig_gene.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(15):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,40)
axes.text(17,14.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,12.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,11.8, color='black',s=' Rhesus',size = '7')
axes.text(17,10.8, color='black',s=' Murinae',size = '7')
axes.text(17,9.8, color='black',s=' Laurasiatheria',size = '7')
axes.text(17,8.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,7.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,6.8, color='black',s=' Gallus gallus',size = '7')
axes.text(17,5.8, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,4.8, color='black',s=' Clupeocephala',size = '7')
axes.text(17,3.8, color='black',s=' Ciona intestinalis',size = '7')
axes.text(17,2.8, color='black',s=' Strongylocentrotus purpuratus',size = '7')
axes.text(17,1.8, color='black',s=' Ecdysozoa',size = '7')
axes.text(17,0.8, color='black',s=' Ascomycota',size = '7')
axes.text(17,-0.2, color='black',s=' Other Eukaryota',size = '7')
axes.text(17,-1.2, color='black',s=' Bacteria and Archaea',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,17)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_52.csv')
axes.set_xlim(-95,60)

for i in range(16):
    i1 = 15-i
    if dataframe2['pvalue'][i1] < (0.05):
        rect = mpathes.Rectangle([-60, -0.4 + i * (1)], dataframe2['origin'][i1]*100, 0.8, facecolor='red',edgecolor='blue')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.4 + i * (1)], 0 - dataframe2['planA'][i1]*100, 0.8, facecolor='red',edgecolor='blue')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-60,-0.4+i*(1)],dataframe2['origin'][i1]*100,0.8,facecolor='yellow',edgecolor='blue')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.4 + i * (1)], 0-dataframe2['planA'][i1]*100, 0.8,facecolor='yellow',edgecolor='blue')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i1] < (0.01):
        axes.text(-32,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i1] < (0.1):
        axes.text(-32, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-60,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_raw52.csv')
phylo_name = ['Cellular_Organisms ','Eukaryota ','Opisthokonta ','Bilateria ','Deuterostomia ','Chordata ','Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Euarchontoglires ','Catarrhini ','Homininae ','HUMAN ']
for i in range(16):
    i1 = 15-i
    #axes.text(-59+dataframe2['origin'][i1]*100,i-0.2, color='black',s=str(int(dataframe1['origin'][i1])),size = '7')
    if np.isnan(dataframe1['planA'][i1]):
        axes.text(-61,i-0.2, color='black', s=str(0)+'(1)', size='7',ha='right')
    else:
        axes.text(-61 - dataframe2['planA'][i1] * 100, i - 0.2, color='black', s=str(int(dataframe1['planA'][i1]))+'('+str(round(dataframe2['pvalue'][i1],2))+')',size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-90,-80,-70, -60,-50, -40,-30])
axes.set_xticklabels([abs(abs(a)-60)/100 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_nhb_his_2_all_gene.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(13):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,35)
axes.text(17,12.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,10.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,9.8, color='black',s=' Pongo pygmaeus abelii',size = '7')
axes.text(17,8.8, color='black',s=' Nomascus leucogenys',size = '7')
axes.text(17,7.8, color='black',s=' Macaca mulatta',size = '7')
axes.text(17,6.8, color='black',s=' Callithrix jacchus',size = '7')
axes.text(17,5.8, color='black',s=' Mus musculus,Oryctolagus cuniculus,etc.',size = '7')
axes.text(17,4.8, color='black',s=' Canis lupus familiaris,Bos taurus,etc.',size = '7')
axes.text(17,3.8, color='black',s=' Loxodonta africana',size = '7')
axes.text(17,2.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,1.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,0.8, color='black',s=' Gallus gallus,zebra finch,etc.',size = '7')
axes.text(17,-0.2, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,-1.2, color='black',s=' Danio rerio,Tetraodon nigroviridis,etc.',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,14)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_53.csv')
axes.set_xlim(-140,100)

for i in range(14):
    if dataframe2['pvalue'][i] < (0.05):
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], dataframe2['origin'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0 - dataframe2['planA'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-95,-0.3+i*(1)],dataframe2['origin'][i]*50,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0-dataframe2['planA'][i]*50, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i] < (0.01):
        axes.text(-45,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i] < (0.1):
        axes.text(-45, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-95,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_raw53.csv')
phylo_name = ['Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Boreoeutheria ','Euarchontoglires ','Simiiformes ','Catarrhini ','Hominoidea ','Hominidae ','Homininae ','Homo Sapiens ',]
for i in range(14):
    axes.text(-94+dataframe2['origin'][i]*50,i-0.2, color='black',s=str(int(dataframe1['origin'][i])),size = '7')
    if np.isnan(dataframe1['planA'][i]):
        axes.text(-96,i-0.2, color='black', s=str(int(0)), size='7',ha='right')
    else:
        axes.text(-96 - dataframe2['planA'][i] * 50, i - 0.2, color='black', s=str(int(dataframe1['planA'][i])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-135,-115, -95,-75, -55])
axes.set_xticklabels([abs(abs(a)-95)/50 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_nhb_sbp_2_sig_gene.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(13):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,35)
axes.text(17,12.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,10.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,9.8, color='black',s=' Pongo pygmaeus abelii',size = '7')
axes.text(17,8.8, color='black',s=' Nomascus leucogenys',size = '7')
axes.text(17,7.8, color='black',s=' Macaca mulatta',size = '7')
axes.text(17,6.8, color='black',s=' Callithrix jacchus',size = '7')
axes.text(17,5.8, color='black',s=' Mus musculus,Oryctolagus cuniculus,etc.',size = '7')
axes.text(17,4.8, color='black',s=' Canis lupus familiaris,Bos taurus,etc.',size = '7')
axes.text(17,3.8, color='black',s=' Loxodonta africana',size = '7')
axes.text(17,2.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,1.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,0.8, color='black',s=' Gallus gallus,zebra finch,etc.',size = '7')
axes.text(17,-0.2, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,-1.2, color='black',s=' Danio rerio,Tetraodon nigroviridis,etc.',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,14)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_52.csv')
axes.set_xlim(-140,100)

for i in range(14):
    if dataframe2['pvalue'][i] < (0.05):
        rect = mpathes.Rectangle([-95, -0.4 + i * (1)], dataframe2['origin'][i]*50, 0.8, facecolor='red',edgecolor='blue')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.4 + i * (1)], 0 - dataframe2['planA'][i]*50, 0.8, facecolor='red',edgecolor='blue')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-95,-0.4+i*(1)],dataframe2['origin'][i]*50,0.8,facecolor='yellow',edgecolor='blue')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.4 + i * (1)], 0-dataframe2['planA'][i]*50, 0.8,facecolor='yellow',edgecolor='blue')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i] < (0.01):
        axes.text(-45,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i] < (0.1):
        axes.text(-45, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-95,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_raw52.csv')
phylo_name = ['Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Boreoeutheria ','Euarchontoglires ','Simiiformes ','Catarrhini ','Hominoidea ','Hominidae ','Homininae ','Homo Sapiens ',]
for i in range(14):
    axes.text(-94+dataframe2['origin'][i]*50,i-0.2, color='black',s=str(int(dataframe1['origin'][i])),size = '7')
    if np.isnan(dataframe1['planA'][i]):
        axes.text(-96,i-0.2, color='black', s=str(int(0)), size='7',ha='right')
    else:
        axes.text(-96 - dataframe2['planA'][i] * 50, i - 0.2, color='black', s=str(int(dataframe1['planA'][i])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-135,-115, -95,-75, -55])
axes.set_xticklabels([abs(abs(a)-95)/50 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_nhb_sbp_2_all_gene.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(15):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,40)
axes.text(17,14.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,12.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,11.8, color='black',s=' Rhesus',size = '7')
axes.text(17,10.8, color='black',s=' Murinae',size = '7')
axes.text(17,9.8, color='black',s=' Laurasiatheria',size = '7')
axes.text(17,8.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,7.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,6.8, color='black',s=' Gallus gallus',size = '7')
axes.text(17,5.8, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,4.8, color='black',s=' Clupeocephala',size = '7')
axes.text(17,3.8, color='black',s=' Ciona intestinalis',size = '7')
axes.text(17,2.8, color='black',s=' Strongylocentrotus purpuratus',size = '7')
axes.text(17,1.8, color='black',s=' Ecdysozoa',size = '7')
axes.text(17,0.8, color='black',s=' Ascomycota',size = '7')
axes.text(17,-0.2, color='black',s=' Other Eukaryota',size = '7')
axes.text(17,-1.2, color='black',s=' Bacteria and Archaea',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,17)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_51.csv')
axes.set_xlim(-95,60)

for i in range(16):
    i1 = 15-i
    if dataframe2['pvalue'][i1] < (0.05):
        rect = mpathes.Rectangle([-60, -0.4 + i * (1)], dataframe2['origin'][i1]*100, 0.8, facecolor='red',edgecolor='blue')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.4 + i * (1)], 0 - dataframe2['planA'][i1]*100, 0.8, facecolor='red',edgecolor='blue')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-60,-0.4+i*(1)],dataframe2['origin'][i1]*100,0.8,facecolor='yellow',edgecolor='blue')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.4 + i * (1)], 0-dataframe2['planA'][i1]*100, 0.8,facecolor='yellow',edgecolor='blue')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i1] < (0.01):
        axes.text(-32,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i1] < (0.1):
        axes.text(-32, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-60,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_raw51.csv')
phylo_name = ['Cellular_Organisms ','Eukaryota ','Opisthokonta ','Bilateria ','Deuterostomia ','Chordata ','Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Euarchontoglires ','Catarrhini ','Homininae ','HUMAN ']
for i in range(16):
    i1 = 15-i
    axes.text(-59+dataframe2['origin'][i1]*100,i-0.2, color='black',s=str(int(dataframe1['origin'][i1])),size = '7')
    if np.isnan(dataframe1['planA'][i1]):
        axes.text(-61,i-0.2, color='black', s=str(0), size='7',ha='right')
    else:
        axes.text(-61 - dataframe2['planA'][i1] * 100, i - 0.2, color='black', s=str(int(dataframe1['planA'][i1])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-90,-80,-70, -60,-50, -40,-30])
axes.set_xticklabels([abs(abs(a)-60)/100 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_his_2_our_nhb_unite.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(13):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,35)
axes.text(17,12.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,10.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,9.8, color='black',s=' Pongo pygmaeus abelii',size = '7')
axes.text(17,8.8, color='black',s=' Nomascus leucogenys',size = '7')
axes.text(17,7.8, color='black',s=' Macaca mulatta',size = '7')
axes.text(17,6.8, color='black',s=' Callithrix jacchus',size = '7')
axes.text(17,5.8, color='black',s=' Mus musculus,Oryctolagus cuniculus,etc.',size = '7')
axes.text(17,4.8, color='black',s=' Canis lupus familiaris,Bos taurus,etc.',size = '7')
axes.text(17,3.8, color='black',s=' Loxodonta africana',size = '7')
axes.text(17,2.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,1.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,0.8, color='black',s=' Gallus gallus,zebra finch,etc.',size = '7')
axes.text(17,-0.2, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,-1.2, color='black',s=' Danio rerio,Tetraodon nigroviridis,etc.',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,14)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_51.csv')
axes.set_xlim(-140,100)

for i in range(14):
    if dataframe2['pvalue'][i] < (0.05):
        rect = mpathes.Rectangle([-95, -0.4 + i * (1)], dataframe2['origin'][i]*50, 0.8, facecolor='red',edgecolor='blue')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.4 + i * (1)], 0 - dataframe2['planA'][i]*50, 0.8, facecolor='red',edgecolor='blue')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-95,-0.4+i*(1)],dataframe2['origin'][i]*50,0.8,facecolor='yellow',edgecolor='blue')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.4 + i * (1)], 0-dataframe2['planA'][i]*50, 0.8,facecolor='yellow',edgecolor='blue')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i] < (0.01):
        axes.text(-45,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i] < (0.1):
        axes.text(-45, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-95,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_raw51.csv')
phylo_name = ['Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Boreoeutheria ','Euarchontoglires ','Simiiformes ','Catarrhini ','Hominoidea ','Hominidae ','Homininae ','Homo Sapiens ',]
for i in range(14):
    axes.text(-94+dataframe2['origin'][i]*50,i-0.2, color='black',s=str(int(dataframe1['origin'][i])),size = '7')
    if np.isnan(dataframe1['planA'][i]):
        axes.text(-96,i-0.2, color='black', s=str(int(0)), size='7',ha='right')
    else:
        axes.text(-96 - dataframe2['planA'][i] * 50, i - 0.2, color='black', s=str(int(dataframe1['planA'][i])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-135,-115, -95,-75, -55])
axes.set_xticklabels([abs(abs(a)-95)/50 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_sbp_2_our_nhb_unite.pdf')


#torque genes
table_whole_toque1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/torque_snp.csv',header=None)
table_whole_toque1.insert(loc= 0,column='ensembl_id',value=table_whole_toque1.iloc[:,0].apply(lambda x:  dictionary2[x] if x in dictionary2.keys() else np.nan))
all333 = list(set(table_whole_toque1.iloc[:,0]))
all333.remove(np.nan)
gene_names1 = list(set(all333).intersection(set(dict_sbp.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_0_greater(gene_names1,dict_sbp)
aaaaa = [[a,dict_sbp[a] ]for a in gene_names1]
bbbbb = pd.DataFrame(aaaaa)
bbbbb.columns = ['gene_name','clade']
bbbbb.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_clumped_torque_zhao_gentree_geneage.csv')
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_54.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_raw54.csv')
#historian
gene_names1 = list(set(all333).intersection(set(dict_historian.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_1_greater(gene_names1,dict_historian)
aaaaa = [[a,dict_historian[a] ]for a in gene_names1]
bbbbb = pd.DataFrame(aaaaa)
bbbbb.columns = ['gene_name','clade']
bbbbb.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_clumped_torque_zhao_historian_geneage.csv')
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_54.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_raw54.csv')

#torque gene + our genes
all3 = list(set(all333+all1))
gene_names1 = list(set(all3).intersection(set(dict_sbp.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_0_greater(gene_names1,dict_sbp)
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_55.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_raw55.csv')
#historian
gene_names1 = list(set(all3).intersection(set(dict_historian.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_1_greater(gene_names1,dict_historian)
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_55.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_raw55.csv')

#torque + nhb+ours
all4 = list(set(all333+all222+all1))
gene_names1 = list(set(all4).intersection(set(dict_sbp.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_0_greater(gene_names1,dict_sbp)
aaaaa = [[a,dict_sbp[a] ]for a in gene_names1]
bbbbb = pd.DataFrame(aaaaa)
bbbbb.columns = ['gene_name','clade']
bbbbb.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_clumped_united_gentree_geneage.csv')
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_56.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_sbp_raw56.csv')
#historian
gene_names1 = list(set(all4).intersection(set(dict_historian.keys())))
gene_ages_compare,gene_ages_compare1,gene_ages_compare2_brain,gene_ages_compare3 = gene_age_process_1_greater(gene_names1,dict_historian)
aaaaa = [[a,dict_historian[a] ]for a in gene_names1]
bbbbb = pd.DataFrame(aaaaa)
bbbbb.columns = ['gene_name','clade']
bbbbb.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_clumped_united_historian_geneage.csv')
gene_ages_compare2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_56.csv')
gene_ages_compare1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/HGNC_all_brain_his_raw56.csv')

from matplotlib import pyplot as plt
from matplotlib_venn import venn3
figure, axes = plt.subplots(1, 1,figsize = [3,3])
a = venn3(subsets=[set(all222),set(all333),set(all1)], set_labels = ('Sha', 'Zhao', 'This research'),set_colors=("gray","lightblue",'red'), ax=axes)
plt.savefig('/data/user/msd/ukbiobank_asymmetry/compare_2_time/tri_venn_compare_paper.pdf')

number_hgncall = len(set(dictionary2.values()))
number_hgnc_ours = len(set(all1).intersection(set(dictionary2.values())))
p_background = number_hgnc_ours/number_hgncall
from scipy.stats import binom_test
binom_test(len(set(all222).intersection(set(all1))),len(all222),p=p_background,alternative='greater')# p = 1.7521786642707062e-60
binom_test(len(set(all333).intersection(set(all1))),len(all333),p=p_background,alternative='greater')# p = 0.00037547004629304316
#binom_test(gene_ages[n], length_1, p=(gene_ages_0[n] / length_2),alternative='greater')

from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
import math
import matplotlib.patches as mpathes
compare_paper = pd.read_csv('C:/Users/MaSidi/OneDrive/brain_paper/HGNC_method/compare_with_paper.csv')
compare_paper['sbp_log'] = -np.log10(compare_paper.sbp)
compare_paper['his_9_log'] = -np.log10(compare_paper.his_9)
compare_paper['his_12_log'] = -np.log10(compare_paper.his_12)

figure, axes = plt.subplots(1, 1,figsize = [6,3])
axes.set_xlim(-1,5)
axes.set_ylim(0,9)
for i in range(3):
    if i == 0:
        rect = mpathes.Rectangle([i*2-0.6,0], 0.4, compare_paper.iloc[0,-3+i], facecolor='red',label = 'This study')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([i*2-0.2,0], 0.4, compare_paper.iloc[1,-3+i], facecolor='gray',label = 'Sha‘s study')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([i*2+0.2,0], 0.4, compare_paper.iloc[2,-3+i], facecolor='lightblue',label = 'Zhao’s study')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([i*2-0.6,0], 0.4, compare_paper.iloc[0,-3+i], facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([i*2-0.2,0], 0.4, compare_paper.iloc[1,-3+i], facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([i*2+0.2,0], 0.4, compare_paper.iloc[2,-3+i], facecolor='lightblue')
        axes.add_patch(rect)

axes.set_xticks([0,2,4])
axes.axhline(y=-math.log10(0.05),linestyle='--',color='black')
axes.set_ylabel('-lo$\mathregular{g_{10}}$($P$)')
axes.set_xticklabels(['SBP','ProteinHistorian clade 9','ProteinHistorian clade 12'],fontsize = 9)
axes.legend()
plt.savefig('C:/Users/MaSidi/OneDrive/brain_paper/HGNC_method/compare_paper_plot_1.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(15):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,40)
axes.text(17,14.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,12.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,11.8, color='black',s=' Rhesus',size = '7')
axes.text(17,10.8, color='black',s=' Murinae',size = '7')
axes.text(17,9.8, color='black',s=' Laurasiatheria',size = '7')
axes.text(17,8.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,7.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,6.8, color='black',s=' Gallus gallus',size = '7')
axes.text(17,5.8, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,4.8, color='black',s=' Clupeocephala',size = '7')
axes.text(17,3.8, color='black',s=' Ciona intestinalis',size = '7')
axes.text(17,2.8, color='black',s=' Strongylocentrotus purpuratus',size = '7')
axes.text(17,1.8, color='black',s=' Ecdysozoa',size = '7')
axes.text(17,0.8, color='black',s=' Ascomycota',size = '7')
axes.text(17,-0.2, color='black',s=' Other Eukaryota',size = '7')
axes.text(17,-1.2, color='black',s=' Bacteria and Archaea',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,17)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_56.csv')
axes.set_xlim(-95,60)

for i in range(16):
    i1 = 15-i
    if dataframe2['pvalue'][i1] < (0.05):
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], dataframe2['origin'][i1]*100, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0 - dataframe2['planA'][i1]*100, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-60,-0.3+i*(1)],dataframe2['origin'][i1]*100,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0-dataframe2['planA'][i1]*100, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i1] < (0.01):
        axes.text(-32,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i1] < (0.1):
        axes.text(-32, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-60,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_raw56.csv')
phylo_name = ['Cellular_Organisms ','Eukaryota ','Opisthokonta ','Bilateria ','Deuterostomia ','Chordata ','Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Euarchontoglires ','Catarrhini ','Homininae ','HUMAN ']
for i in range(16):
    i1 = 15-i
    axes.text(-59+dataframe2['origin'][i1]*100,i-0.2, color='black',s=str(int(dataframe1['origin'][i1])),size = '7')
    if np.isnan(dataframe1['planA'][i1]):
        axes.text(-61,i-0.2, color='black', s=str(0), size='7',ha='right')
    else:
        axes.text(-61 - dataframe2['planA'][i1] * 100, i - 0.2, color='black', s=str(int(dataframe1['planA'][i1])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-90,-80,-70, -60,-50, -40,-30])
axes.set_xticklabels([abs(abs(a)-60)/100 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_his_2_our_nhb_torque_unite.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(13):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,35)
axes.text(17,12.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,10.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,9.8, color='black',s=' Pongo pygmaeus abelii',size = '7')
axes.text(17,8.8, color='black',s=' Nomascus leucogenys',size = '7')
axes.text(17,7.8, color='black',s=' Macaca mulatta',size = '7')
axes.text(17,6.8, color='black',s=' Callithrix jacchus',size = '7')
axes.text(17,5.8, color='black',s=' Mus musculus,Oryctolagus cuniculus,etc.',size = '7')
axes.text(17,4.8, color='black',s=' Canis lupus familiaris,Bos taurus,etc.',size = '7')
axes.text(17,3.8, color='black',s=' Loxodonta africana',size = '7')
axes.text(17,2.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,1.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,0.8, color='black',s=' Gallus gallus,zebra finch,etc.',size = '7')
axes.text(17,-0.2, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,-1.2, color='black',s=' Danio rerio,Tetraodon nigroviridis,etc.',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,14)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_56.csv')
axes.set_xlim(-140,100)

for i in range(14):
    if dataframe2['pvalue'][i] < (0.05):
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], dataframe2['origin'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0 - dataframe2['planA'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-95,-0.3+i*(1)],dataframe2['origin'][i]*50,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0-dataframe2['planA'][i]*50, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i] < (0.01):
        axes.text(-45,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i] < (0.1):
        axes.text(-45, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-95,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_raw56.csv')
phylo_name = ['Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Boreoeutheria ','Euarchontoglires ','Simiiformes ','Catarrhini ','Hominoidea ','Hominidae ','Homininae ','Homo Sapiens ',]
for i in range(14):
    axes.text(-94+dataframe2['origin'][i]*50,i-0.2, color='black',s=str(int(dataframe1['origin'][i])),size = '7')
    if np.isnan(dataframe1['planA'][i]):
        axes.text(-96,i-0.2, color='black', s=str(int(0)), size='7',ha='right')
    else:
        axes.text(-96 - dataframe2['planA'][i] * 50, i - 0.2, color='black', s=str(int(dataframe1['planA'][i])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-135,-115, -95,-75, -55])
axes.set_xticklabels([abs(abs(a)-95)/50 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_sbp_2_our_nhb_torque_unite.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(15):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,40)
axes.text(17,14.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,12.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,11.8, color='black',s=' Rhesus',size = '7')
axes.text(17,10.8, color='black',s=' Murinae',size = '7')
axes.text(17,9.8, color='black',s=' Laurasiatheria',size = '7')
axes.text(17,8.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,7.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,6.8, color='black',s=' Gallus gallus',size = '7')
axes.text(17,5.8, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,4.8, color='black',s=' Clupeocephala',size = '7')
axes.text(17,3.8, color='black',s=' Ciona intestinalis',size = '7')
axes.text(17,2.8, color='black',s=' Strongylocentrotus purpuratus',size = '7')
axes.text(17,1.8, color='black',s=' Ecdysozoa',size = '7')
axes.text(17,0.8, color='black',s=' Ascomycota',size = '7')
axes.text(17,-0.2, color='black',s=' Other Eukaryota',size = '7')
axes.text(17,-1.2, color='black',s=' Bacteria and Archaea',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,17)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_54.csv')
axes.set_xlim(-95,60)

for i in range(16):
    i1 = 15-i
    if dataframe2['pvalue'][i1] < (0.05):
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], dataframe2['origin'][i1]*100, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0 - dataframe2['planA'][i1]*100, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-60,-0.3+i*(1)],dataframe2['origin'][i1]*100,0.6,facecolor='gray')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-60, -0.3 + i * (1)], 0-dataframe2['planA'][i1]*100, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i1] < (0.01):
        axes.text(-32,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i1] < (0.1):
        axes.text(-32, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-60,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_his_raw54.csv')
phylo_name = ['Cellular_Organisms ','Eukaryota ','Opisthokonta ','Bilateria ','Deuterostomia ','Chordata ','Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Euarchontoglires ','Catarrhini ','Homininae ','HUMAN ']
for i in range(16):
    i1 = 15-i
    axes.text(-59+dataframe2['origin'][i1]*100,i-0.2, color='black',s=str(int(dataframe1['origin'][i1])),size = '7')
    if np.isnan(dataframe1['planA'][i1]):
        axes.text(-61,i-0.2, color='black', s=str(0), size='7',ha='right')
    else:
        axes.text(-61 - dataframe2['planA'][i1] * 100, i - 0.2, color='black', s=str(int(dataframe1['planA'][i1])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-90,-80,-70, -60,-50, -40,-30])
axes.set_xticklabels([abs(abs(a)-60)/100 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_his_2_torque.pdf')

fig,axes = plt.subplots(figsize = [6,3])
for i in range(13):
    axes.plot([i, i], [i, i+1], color='black',linewidth=0.5)
    axes.plot([i, i+1], [i+1, i + 1], color='black',linewidth=0.5)
    axes.plot([i, i], [i, i-1], color='black',linewidth=0.5)
    axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
    axes.plot([i, -3], [i+1, i+1], color='lightgray',ls='--',linewidth=0.5)
axes.plot([i, 17], [i-1, i-1], color='black',linewidth=0.5)
axes.plot([i, 17], [i+1, i + 1], color='black',linewidth=0.5)
axes.plot([-3, 0], [0, 0], color='black',linewidth=0.5)
axes.set_xlim(-5,35)
axes.text(17,12.8, color='black',s=' Homo sapiens',size = '7')
axes.text(17,10.8, color='black',s=' Pan troglodytes',size = '7')
axes.text(17,9.8, color='black',s=' Pongo pygmaeus abelii',size = '7')
axes.text(17,8.8, color='black',s=' Nomascus leucogenys',size = '7')
axes.text(17,7.8, color='black',s=' Macaca mulatta',size = '7')
axes.text(17,6.8, color='black',s=' Callithrix jacchus',size = '7')
axes.text(17,5.8, color='black',s=' Mus musculus,Oryctolagus cuniculus,etc.',size = '7')
axes.text(17,4.8, color='black',s=' Canis lupus familiaris,Bos taurus,etc.',size = '7')
axes.text(17,3.8, color='black',s=' Loxodonta africana',size = '7')
axes.text(17,2.8, color='black',s=' Monodelphis domestica',size = '7')
axes.text(17,1.8, color='black',s=' Ornithorhynchus anatinus',size = '7')
axes.text(17,0.8, color='black',s=' Gallus gallus,zebra finch,etc.',size = '7')
axes.text(17,-0.2, color='black',s=' Xenopus tropicalis',size = '7')
axes.text(17,-1.2, color='black',s=' Danio rerio,Tetraodon nigroviridis,etc.',size = '7')
axes.get_xaxis().set_visible(True)
axes.get_yaxis().set_visible(False)
axes.set_ylim(-2,14)

dataframe2 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_54.csv')
axes.set_xlim(-140,100)

for i in range(14):
    if dataframe2['pvalue'][i] < (0.05):
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], dataframe2['origin'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0 - dataframe2['planA'][i]*50, 0.6, facecolor='red')
        axes.add_patch(rect)
    else:
        rect = mpathes.Rectangle([-95,-0.3+i*(1)],dataframe2['origin'][i]*50,0.6,facecolor='gray',)
        axes.add_patch(rect)
        rect = mpathes.Rectangle([-95, -0.3 + i * (1)], 0-dataframe2['planA'][i]*50, 0.6,facecolor='gray')
        axes.add_patch(rect)
    if dataframe2['pvalue'][i] < (0.01):
        axes.text(-45,i-0.3,color='brown',size='7',s='**')
    elif dataframe2['pvalue'][i] < (0.1):
        axes.text(-45, i-0.3, color='brown', size='7', s='*')
axes.axvline(x=-95,c='black',linewidth=0.7)
dataframe1 = pd.read_csv('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_all_brain_sbp_raw54.csv')
phylo_name = ['Euteleostomi ','Tetrapoda ','Amniota ','Mammalia ','Theria ','Eutheria ','Boreoeutheria ','Euarchontoglires ','Simiiformes ','Catarrhini ','Hominoidea ','Hominidae ','Homininae ','Homo Sapiens ',]
for i in range(14):
    axes.text(-94+dataframe2['origin'][i]*50,i-0.2, color='black',s=str(int(dataframe1['origin'][i])),size = '7')
    if np.isnan(dataframe1['planA'][i]):
        axes.text(-96,i-0.2, color='black', s=str(int(0)), size='7',ha='right')
    else:
        axes.text(-96 - dataframe2['planA'][i] * 50, i - 0.2, color='black', s=str(int(dataframe1['planA'][i])),size='7', ha='right')
    axes.text(-3,i-0.2, color='black', s=phylo_name[i], size='7',ha='right')
axes.set_xticks([-135,-115, -95,-75, -55])
axes.set_xticklabels([abs(abs(a)-95)/50 for a in axes.get_xticks()],fontsize=8)
for key, spine in axes.spines.items():
    if key == 'left' or key == 'right' or key == 'top' :
        spine.set_visible(False)
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/HGNC_sbp_2_torque.pdf')
