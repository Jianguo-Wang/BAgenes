import os,pickle,sys
import pandas as pd
import matplotlib as mpl
from matplotlib import pyplot as plt
from collections import Counter
import numpy as np
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from scipy.stats import binom_test
from gene_age_function import gene_age_process_1,age_inf,gene_age_process_0,gene_age_process_2,gene_age_process_0_greater,gene_age_process_1_greater,gene_age_process_2_greater
mpl.rcParams['pdf.fonttype'] = 42
from multiprocessing import Pool
table_whole1 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',index_col=0)

list_1 = list(set(list(table_whole1['emsembl_phenoscanner'])))
list_1.remove('-')
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_GENE_in_SNP_brain_clump.txt','w') as f:
    for a in list_1:
        f.write(a+'\n')

table_whole2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t')
table_whole2_2 = table_whole2.loc[table_whole2['Func.refGene_annovar'] !='-',: ]
brains = Counter(table_whole2_2['Func.refGene_annovar'])
aaa= list(set([a for a in list(table_whole2_2['Gene.refGene_annovar']) if ';' not in a]))
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_GENE_in_SNP_brain_clump_annovar.txt','w') as f:
    for a in aaa:
        f.write(a+'\n')
