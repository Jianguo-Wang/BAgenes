import os,pickle
import pandas as pd
import matplotlib as mpl
from matplotlib import pyplot as plt
from collections import Counter
mpl.rcParams['pdf.fonttype'] = 42
from multiprocessing import Pool

#qqplot
import pandas as pd
import matplotlib.pyplot as plt
from geneview.gwas import qqplot
f, ax = plt.subplots(figsize=(10, 10), facecolor="w", edgecolor="k")
pvalue=[]
filename = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/geno_assoc_asymmetry_control_1_25565-2.0_25566-2.0.fastGWA'
context = pd.read_table(filename)
pvalue = list(context['P'])
ax = qqplot(pvalue, color="#00bb33", xlabel="Expected p-value(-log10)", ylabel="Observed p-value(-log10)") #
plt.savefig('/data/user/msd/ukbiobank_asymmetry/compare_2_time/gwas_25565-2.0_25566-2_qqlot.pdf')
plt.savefig('/data/user/msd/ukbiobank_asymmetry/compare_2_time/gwas_25565-2.0_25566-2_qqlot.png')


#fig2 d : clumped snp with annotation

#table S3 - 7
table_whole = []
clumped_result_path = '/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_planA_clumped_2.pickle'
ee = open(clumped_result_path,"rb")
a = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/paper_context/symmetry_features_organ_all.csv')
dict_all_organ = dict(zip(a['code'],a['organ_new']))
clump_inf = pickle.load(ee)[0]
table2 = []
for key in clump_inf.keys():
    if dict_all_organ[key.split('_')[0]] == 'brain':
        table1 = pd.DataFrame(clump_inf[key])
        table1.insert(loc = 0,column = 'organ',value = ['brain']*table1.shape[0])
        table1.insert(loc=0, column='trait', value=[key] * table1.shape[0])
        table2.append(table1)
table2 = pd.concat(table2)
table2.insert(loc=0,column='plan',value = ['plan1']*table2.shape[0])
table2.columns = ['plan', 'trait', 'organ', 'chr', 'index_snp', 'loc', 'p', 'number', 'snps',]
table2['p'] = table2['p'].apply(float)
table_whole.append(table2)

clumped_result_path = '/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_planB_clumped_2.pickle'
ee = open(clumped_result_path,"rb")
clump_inf = pickle.load(ee)[0]
table2 = []
for key in clump_inf.keys():
    if dict_all_organ[key.split('_')[0]] == 'brain':
        table1 = pd.DataFrame(clump_inf[key])
        table1.insert(loc = 0,column = 'organ',value = ['brain']*table1.shape[0])
        table1.insert(loc=0, column='trait', value=[key] * table1.shape[0])
        table2.append(table1)
table2 = pd.concat(table2)
table2.insert(loc=0,column='plan',value = ['plan3']*table2.shape[0])
table2.columns = ['plan', 'trait', 'organ', 'chr', 'index_snp', 'loc', 'p', 'number', 'snps',]
table2['p'] = table2['p'].apply(float)
table_whole.append(table2)

clumped_result_path = '/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_abs_planA_clumped_2.pickle'
ee = open(clumped_result_path,"rb")
clump_inf = pickle.load(ee)[0]
table2 = []
for key in clump_inf.keys():
    if dict_all_organ[key.split('_')[0]] == 'brain':
        table1 = pd.DataFrame(clump_inf[key])
        table1.insert(loc = 0,column = 'organ',value = ['brain']*table1.shape[0])
        table1.insert(loc=0, column='trait', value=[key] * table1.shape[0])
        table2.append(table1)
table2 = pd.concat(table2)
table2.insert(loc=0,column='plan',value = ['plan2']*table2.shape[0])
table2.columns = ['plan', 'trait', 'organ', 'chr', 'index_snp', 'loc', 'p', 'number', 'snps',]
table2['p'] = table2['p'].apply(float)
table_whole.append(table2)

clumped_result_path = '/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_abs_planB_clumped_2.pickle'
ee = open(clumped_result_path,"rb")
clump_inf = pickle.load(ee)[0]
table2 = []
for key in clump_inf.keys():
    if dict_all_organ[key.split('_')[0]] == 'brain':
        table1 = pd.DataFrame(clump_inf[key])
        table1.insert(loc = 0,column = 'organ',value = ['brain']*table1.shape[0])
        table1.insert(loc=0, column='trait', value=[key] * table1.shape[0])
        table2.append(table1)
table2 = pd.concat(table2)
table2.insert(loc=0,column='plan',value = ['plan4']*table2.shape[0])
table2.columns = ['plan', 'trait', 'organ', 'chr', 'index_snp', 'loc', 'p', 'number', 'snps',]
table2['p'] = table2['p'].apply(float)
table_whole.append(table2)

col_table1 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_MAF_GWAS_SNP_1.txt',index_col=0)
col_table20 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_MAF_GWAS_SNP_annovar_1.txt',index_col=0)
col_table2 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_MAF_GWAS_SNP_annovar_2.txt',index_col=0)

dict_col_1 = dict(zip(col_table1['snp'],col_table1['hgnc']))
dict_col_2 = dict(zip(col_table1['snp'],col_table1['ensembl']))
dict_col_3 = dict(zip(col_table1['snp'],col_table1['consequence']))

dict_col_1_anno = dict(zip(col_table2['snp'],col_table2['Gene.refGene']))
dict_col_2_anno = dict(zip(col_table2['snp'],col_table2['Func.refGene']))

table_whole1 = pd.concat(table_whole)
table_whole1.insert(loc=0,column='trait_id',value = table_whole1.apply(lambda x : '|'.join([x[0],x[1]]),axis=1))
table_whole1.insert(loc = 9,column = 'gene_phenoscanner',value = [dict_col_1[a] if a in dict_col_1.keys() else '-'  for  a in table_whole1['index_snp']])
table_whole1.insert(loc = 9,column = 'emsembl_phenoscanner',value = [dict_col_2[a] if a in dict_col_2.keys() else '-'  for  a in table_whole1['index_snp']])
table_whole1.insert(loc = 9,column = 'consequence_phenoscanner',value = [dict_col_3[a] if a in dict_col_3.keys() else '-'  for  a in table_whole1['index_snp']])
table_whole1.insert(loc = 9,column = 'Gene.refGene_annovar',value = [dict_col_1_anno[a] if a in dict_col_2.keys() else '-'  for  a in table_whole1['index_snp']])
table_whole1.insert(loc = 9,column = 'Func.refGene_annovar',value = [dict_col_2_anno[a] if a in dict_col_3.keys() else '-'  for  a in table_whole1['index_snp']])


table_whole2 = table_whole1.loc[table_whole1['trait'].apply(lambda x: '-3.' not in x ),:]
table_whole3 = table_whole1.loc[table_whole1['trait'].apply(lambda x: '-3.' in x ),:]

with open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump.pickle','wb') as F:
    pickle.dump(table_whole1, F)
table_whole1.iloc[:,0:-1].to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump.txt',sep = '\t')
with open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.pickle','wb') as F:
    pickle.dump(table_whole2, F)
table_whole2.iloc[:,0:-1].to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t')

#fig intron information
table_whole2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t')
table_whole2_1 = table_whole2.loc[table_whole2['consequence_phenoscanner'] !='-',: ]
brains = Counter(table_whole2_1['consequence_phenoscanner'])
plt.figure()
plt.pie(x=[(brains[a]/table_whole2_1.shape[0]) for a in list(brains.keys())],labels=[a+'('+str(brains[a])+')' for a in list(brains.keys())])
plt.savefig('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/fig_2b_brain_1.pdf')

table_whole2_2 = table_whole2.loc[table_whole2['Func.refGene_annovar'] !='-',: ]
brains = Counter(table_whole2_2['Func.refGene_annovar'])
plt.figure()
plt.pie(x=[(brains[a]/table_whole2_2.shape[0]) for a in list(brains.keys())],labels=[a+'('+str(brains[a])+')' for a in list(brains.keys())])
plt.savefig('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/fig_2b_brain_2.pdf')

#fig clump counts
counts_clump = Counter(table_whole2['trait_id'])
counts_clump1 = pd.DataFrame([[a,counts_clump[a]] for a in counts_clump.keys()])
plt.figure()
plt.hist(counts_clump1.iloc[:,1],bins=100)
plt.savefig('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/fig_2a_brain_clump_counts.pdf')
#这里输出一个带summary statistics的表table S2
results_all = []
table_whole1 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump.txt',index_col=0)
path1 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/'
prefix1 = 'geno_assoc_asymmetry_control_1_'
files = os.listdir(path1)
files1 = [a for a in files if a.startswith('geno_assoc_asymmetry_control_1_') and a.endswith('fastGWA')]
path3 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/'
prefix3 = 'geno_assoc_asymmetry_centralized_1_'
files = os.listdir(path3)
files3 = [a for a in files if a.startswith('geno_assoc_asymmetry_centralized_1_') and a.endswith('fastGWA')]
path2 = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_A_1/'
prefix2 = 'geno_assoc_asymmetry_abs_A_'
files = os.listdir(path2)
files2 = [a for a in files if a.startswith('geno_assoc_asymmetry_abs_A_') and a.endswith('fastGWA')]
path4 = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/'
prefix4 = 'geno_assoc_asymmetry_abs_B_'
files = os.listdir(path4)
files4 = [a for a in files if a.startswith('geno_assoc_asymmetry_abs_B_') and a.endswith('fastGWA')]
table_whole1_p1 = table_whole1.loc[table_whole1['plan'] == 'plan1',:]
table_whole1_p2 = table_whole1.loc[table_whole1['plan'] == 'plan2',:]
table_whole1_p3 = table_whole1.loc[table_whole1['plan'] == 'plan3',:]
table_whole1_p4 = table_whole1.loc[table_whole1['plan'] == 'plan4',:]
def clumped_to_gwas(path1,key,prefix1,suffix1,table2,i):
    print(i)
    file_name = path1+prefix1+key+suffix1
    table1 = pd.read_table(file_name)
    table1.index = table1['SNP']
    table3 = table2.loc[table2['trait'] == key,:]
    table3.index = table3['index_snp']
    table1_1 = table1.loc[table3.index,:]
    mid = pd.concat([table3.loc[:,['trait_id', 'plan', 'trait', 'organ','index_snp']],table1_1],axis=1,join='inner')
    return [key,mid]

suffix1 = '.fastGWA'
table2 = table_whole1_p1
cores_num = 20
pool = Pool(processes=cores_num)
wrong = []
right = []
i=0
for key in list(set(table_whole1_p1['trait'])):
    i+=1
    right.append(pool.apply_async(clumped_to_gwas, args=(path1,key,prefix1,suffix1,table2,i,)))
pool.close()
pool.join()

results = []
for i in right:
    results.append(i.get())
results1 = [a[1] for a in results]
results2 = pd.concat(results1)
results_all.append(results2)

table2 = table_whole1_p2
cores_num = 20
pool = Pool(processes=cores_num)
wrong = []
right = []
i=0
for key in list(set(table_whole1_p2['trait'])):
    i+=1
    right.append(pool.apply_async(clumped_to_gwas, args=(path2,key,prefix2,suffix1,table2,i,)))
pool.close()
pool.join()

results = []
for i in right:
    results.append(i.get())
results1 = [a[1] for a in results]
results2 = pd.concat(results1)
results_all.append(results2)

table2 = table_whole1_p3
cores_num = 20
pool = Pool(processes=cores_num)
wrong = []
right = []
i=0
for key in list(set(table_whole1_p3['trait'])):
    i+=1
    right.append(pool.apply_async(clumped_to_gwas, args=(path3,key,prefix3,suffix1,table2,i,)))
pool.close()
pool.join()

results = []
for i in right:
    results.append(i.get())
results1 = [a[1] for a in results]
results2 = pd.concat(results1)
results_all.append(results2)

table2 = table_whole1_p4
cores_num = 20
pool = Pool(processes=cores_num)
wrong = []
right = []
i=0
for key in list(set(table_whole1_p4['trait'])):
    i+=1
    right.append(pool.apply_async(clumped_to_gwas, args=(path4,key,prefix4,suffix1,table2,i,)))
pool.close()
pool.join()

results = []
for i in right:
    results.append(i.get())
results1 = [a[1] for a in results]
results2 = pd.concat(results1)
results_all.append(results2)

results_all1 = pd.concat(results_all)
results_all1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_summarySTATS.txt',sep = '\t')
results_all1 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_summarySTATS.txt',sep = '\t')
results_all12 = results_all1.loc[results_all1['trait'].apply(lambda x: '-3.' not in x ),:]
results_all13 = results_all1.loc[results_all1['trait'].apply(lambda x: '-3.' in x ),:]
results_all12.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_summarySTATS_1.txt',sep = '\t')
################tableS2
results_all12=pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_summarySTATS_1.txt',sep = '\t',index_col=0)
results_all12.insert(loc=0,column='name1',value=results_all12.apply(lambda x: '_'.join([x.iloc[0],x.iloc[1]]),axis=1))

table3=pd.read_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/brainloci_replicate_phase3_total_whole.csv')
table3.insert(loc=0,column='name1',value=table3.apply(lambda x: '_'.join([x.iloc[0],'|'.join([x.iloc[1],x.iloc[3]])]),axis=1))

table31=pd.read_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/brainloci_replicate_phase2_total_whole.csv',index_col=0)
table31.insert(loc=0,column='name1',value=table31.apply(lambda x: '_'.join([x.iloc[4],'|'.join([x.iloc[0],x.iloc[2]])]),axis=1))
results_all12.index =results_all12['name1']
table3.index =table3['name1']
table31.index =table31['name1']
table_final = pd.concat([results_all12,table31.iloc[:,[-2,-1]],table3.iloc[:,[-2,-1]]],axis=1)
table_final.columns = ['name1', 'index_snp', 'trait_id', 'plan', 'trait', 'organ',
       'index_snp.1', 'CHR', 'SNP', 'POS', 'A1', 'A2', 'N', 'AF1', 'BETA',
       'SE', 'P', 'BETA_p2', 'P_p2', 'BETA_p3', 'P_p3']
table_whole2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t',index_col=0)
table_whole2.insert(loc=0,column='name1',value=table_whole2.apply(lambda x: '_'.join([x.iloc[5],x.iloc[0]]),axis=1))
table_whole2.index = table_whole2['name1']
table_final1 = pd.concat([table_final,table_whole2.iloc[:,-5:]],axis=1)
table_final1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_summarySTATS_1.1.txt',sep = '\t',)


#table S4-S7
traits_num = len(set(table_whole1['trait_id']))
p_threshold = (5e-8)/traits_num
table_whole1_new = table_whole1.loc[table_whole1['p'] < p_threshold,:]

with open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1.pickle','wb') as F:
    pickle.dump(table_whole1_new, F)
table_whole1_new.iloc[:,0:-1].to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1.txt',sep = '\t')

table_whole1_new_p1 = table_whole1_new.loc[table_whole1_new['plan'] == 'plan1',:]
table_whole1_new_p2 = table_whole1_new.loc[table_whole1_new['plan'] == 'plan2',:]
table_whole1_new_p3 = table_whole1_new.loc[table_whole1_new['plan'] == 'plan3',:]
table_whole1_new_p4 = table_whole1_new.loc[table_whole1_new['plan'] == 'plan4',:]
table_whole1_new_p1.iloc[:,0:-1].to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_p1.txt',sep = '\t')
table_whole1_new_p2.iloc[:,0:-1].to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_p2.txt',sep = '\t')
table_whole1_new_p3.iloc[:,0:-1].to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_p3.txt',sep = '\t')
table_whole1_new_p4.iloc[:,0:-1].to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_p4.txt',sep = '\t')
#######################
table_whole1_new = pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1.txt',index_col=0)
table_whole1_new1 = table_whole1_new.copy()
features = pd.read_csv('/data/user/msd/biobank_schema/field.txt',sep = '\t')
dict_title = dict(zip(features['field_id'],features['title']))
table_whole1_new1.insert(loc = 0,column = 'left_name',value = table_whole1_new['trait'].apply(lambda x: dict_title[int(x.split('-')[0])]))
table_whole1_new1.insert(loc = 0,column = 'area',value = table_whole1_new1['left_name'].apply(lambda x: x.split(' in ')[1].split(' on FA ')[0] if 'on FA' in x else x.split(' in ')[1].split(' (left)')[0] ))
table_whole1_new1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_with_area.txt',sep = '\t')
###############################
table1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/symmetry_all_organ_brain.csv',index_col=0)
dictionary = dict(zip(table1['code'],table1['name']))
table2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_2_0.csv',index_col=0,nrows=3)
traits_brain = [a for a in table2.columns if a.startswith('25')]
list1 = [[a,a.split('_')[0],a.split('_')[1],dictionary[a.split('_')[0]].split(' (left')[0]]for a in traits_brain]
table11 = pd.DataFrame(list1)
table11.columns = ['asymmetry_trait','left_trait','right_trait','trait']
table11.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/tableS1.txt',sep = '\t',index=None)

#table_with_area name
import os,pickle
import pandas as pd
import numpy as np
def trait_process(x):
    if 'Volume of' in x and ' in ' not in x:
        return x.split(' of ')[1]
    elif 'Volume of' in x and ' in ' in x:
        return x.split(' in ')[1]
    elif 'FA skeleton' in x:
        return x.split(' in ')[1].split(' on FA ')[0]
    else:
        return x.split(' in ')[1]
table1 = pd.read_table('C:/Users/Administrator/OneDrive/brain_paper/table_and_figs/tableS1.txt')
table1.insert(loc = 0,column = 'area',value = table1['trait'].apply(lambda x: trait_process(x)))
table1.to_csv('C:/Users/Administrator/OneDrive/brain_paper/table_and_figs/tableS1_1.csv')
