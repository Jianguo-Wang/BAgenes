import os,pickle
import pandas as pd
import matplotlib as mpl
from matplotlib import pyplot as plt
from collections import Counter
mpl.rcParams['pdf.fonttype'] = 42
from multiprocessing import Pool

features = pd.read_csv('/data/user/msd/biobank_schema/field.txt',sep = '\t')
dict_title = dict(zip(features['field_id'],features['title']))

table_whole1 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump.txt',index_col=0)
table_whole1_counts1 = Counter(table_whole1['trait_id'])
table_whole1_counts2 = Counter(table_whole1['trait'])
gene_counts = Counter(table_whole1['gene_phenoscanner'])
table_whole1.insert(loc = 0,column = 'left_name',value = table_whole1['trait'].apply(lambda x: dict_title[int(x.split('-')[0])]))
table_whole1.insert(loc = 0,column = 'area',value = table_whole1['left_name'].apply(lambda x:x.split('of')[1].split(' (left)')[0] if 'in' not in x  else (x.split(' in ')[1].split(' on FA ')[0] if 'on FA' in x else x.split(' in ')[1].split(' (left)')[0] )))
table_whole1.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_witharea.txt',sep = '\t')

table_whole2 = table_whole1.loc[table_whole1['trait'].apply(lambda x:'-3.0' not in x),:]
gene_counts2 = Counter(table_whole2['gene_phenoscanner'])

table_whole1_group = table_whole1.groupby(('gene_phenoscanner'))
results1 = []
for num,(name, group) in enumerate(table_whole1_group):
    if name == '-':
        continue
    results1.append([name,len(set(group['area'])),list(set(group['area'])),len(set(group['trait'])),list(set(group['left_name'].apply(lambda x: x.replace(' (left)',''))))])
table_gene = pd.DataFrame(results1)
table_gene.columns = ['gene name','area number','area name','filed number','asymmetry field name']
table_gene.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_gene_1.txt',sep = '\t')

table_whole1_group = table_whole1.groupby(('area'))
results1 = []
for num,(name, group) in enumerate(table_whole1_group):
    if name == '-':
        continue
    results1.append([name,len(set(group['gene_phenoscanner'])),list(set(group['gene_phenoscanner'])),len(set(group['trait'])),list(set(group['left_name'].apply(lambda x: x.replace(' (left)',''))))])
table_gene = pd.DataFrame(results1)
table_gene.columns = ['gene name','area number','area name','filed number','asymmetry field name']
table_gene.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_area_1.txt',sep = '\t')



