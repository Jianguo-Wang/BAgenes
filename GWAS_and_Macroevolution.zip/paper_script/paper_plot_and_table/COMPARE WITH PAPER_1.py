import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.lines as lines
import matplotlib as mpl
import matplotlib.patches as mpathes
mpl.rcParams['pdf.fonttype'] = 42
plt.rcParams['font.serif'] = ['Times New Roman']

dataframe2 = pd.read_table('C:/Users/Administrator/OneDrive/brain_paper/table_and_figs/tableS2.txt')
dataframe2['-log10'] = -np.log10(dataframe2.P)
figure, axes = plt.subplots(1, 1,figsize = [3.5,3.5])
axes.scatter(dataframe2['BETA'],dataframe2['-log10'],color='black',s=3)
axes.set_ylabel('-lo$\mathregular{g_{10}}$($P$)')
axes.set_xlabel(r"$\beta$")
axes.axhline(-np.log10(5e-8),color='red',linestyle='--')
plt.tight_layout()
plt.savefig('C:/Users/Administrator/OneDrive/brain_paper/HGNC_method/beta_P_2.pdf')