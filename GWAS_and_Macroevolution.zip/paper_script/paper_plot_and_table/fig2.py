import os,pickle,math
import pandas as pd
import numpy as np
import matplotlib as mpl
from matplotlib import pyplot as plt
from collections import Counter
from scipy import stats
mpl.rcParams['pdf.fonttype'] = 42
from multiprocessing import Pool
from geneview.gwas import qqplot

fig = plt.figure(figsize = (5,7.5))
gs = plt.GridSpec(3, 2,wspace=0.5,hspace=0.5)
ax1 = fig.add_subplot(gs[0, 0])
# identical to ax1 = plt.subplot(gs.new_subplotspec((0, 0), colspan=3))
ax2 = fig.add_subplot(gs[0, 1])
ax3 = fig.add_subplot(gs[1, 0:2])
ax4 = fig.add_subplot(gs[2, 0])
ax5 = fig.add_subplot(gs[2, 1])
ax1.tick_params(labelsize=8)
ax2.tick_params(labelsize=8)
ax3.tick_params(labelsize=8)
ax4.tick_params(labelsize=8)
ax5.tick_params(labelsize=8)

#2A
table_whole2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t')
counts_clump = Counter(table_whole2['trait_id'])
counts_clump1 = pd.DataFrame([[a,counts_clump[a]] for a in counts_clump.keys()])
counts_clump1.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/fig2a.csv')
ax1.hist(counts_clump1.iloc[:,1],bins=100,color='black')
ax1.set_yscale('log')
ax1.set_xlabel('Number of QTLs')
ax1.set_ylabel('Number of traits')

#2C
filename = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/geno_assoc_asymmetry_control_1_25565-2.0_25566-2.0.fastGWA'
table_whole2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t')
table_whole21 = table_whole2.loc[table_whole2['trait_id'] == 'plan1|25565-2.0_25566-2.0']
context = pd.read_table(filename)
final1 = context
df_mid = final1
df_mid1 = df_mid.sort_values(by=['CHR', 'POS'])
df = df_mid1
df['minuslog10pvalue'] = -np.log10(df.P)
df.CHR = df.CHR.astype('category')
df.CHR = df.CHR.cat.set_categories([i for i in range(1, 23)], ordered=True)
df = df.sort_values(by=['CHR', 'POS'])
# How to plot gene vs. -log10(pvalue) and colour it by chromosome?
df['ind'] = range(len(df))
df_qtl = df.loc[df['SNP'].apply(lambda x:x in list(table_whole21['index_snp'])),:]
df1 = df.drop(index = df_qtl.index)
df_grouped = df1.groupby(('CHR'))
# manhattan plot
colors = ['black', 'gray']
x_labels = []
x_labels_pos = []
for num, (name, group) in enumerate(df_grouped):
    group.plot(kind='scatter', x='ind', y='minuslog10pvalue', color=colors[num % len(colors)], ax=ax3, s=1)
    if num in [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22]:
        x_labels.append(name)
    else:
        x_labels.append('')
    x_labels_pos.append((group['ind'].iloc[-1] - (group['ind'].iloc[-1] - group['ind'].iloc[0]) / 2))
ax3.scatter(x = df_qtl['ind'],y = df_qtl['minuslog10pvalue'],color = 'orange',s=2)
ax3.set_xticks(x_labels_pos)
ax3.set_xticklabels(x_labels)
ax3.axhline(y=-math.log10(5 * 10 ** -8), color='r', ls='--', lw=1)
# set axis limits
ax3.set_xlim([0, len(df)])
ax3.set_ylim([0, math.ceil(np.max(df['minuslog10pvalue']))+3])
ax3.tick_params(labelsize=8)
# x axis label
ax3.set_xlabel('Chromosome')
ax3.set_ylabel('-lo$\mathregular{g_{10}}$($P$)')
#ax3.scatter(x=1)

# show the graph
#2B
pvalue=[]
pvalue = list(context['P'])
ax = qqplot(pvalue, color="gray", xlabel="Expected -lo$\mathregular{g_{10}}$($P$)", ylabel="Observed -lo$\mathregular{g_{10}}$($P$)",ax=ax2,s=6) # Q-Q 图
#2D
from pylatexenc.latex2text import LatexNodes2Text
mul_symbol = r"""\times"""
mul_symbol_text = LatexNodes2Text().latex_to_text(mul_symbol)
correlation_counts_2_brain_planA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/betacompare_p3_25565-2.0_25566-2.0.csv',index_col=0)
ax4.scatter(correlation_counts_2_brain_planA['p1_beta'],correlation_counts_2_brain_planA['p2_beta'],c='black',s=2)
stats.pearsonr(correlation_counts_2_brain_planA['p1_beta'],correlation_counts_2_brain_planA['p2_beta'])[0]
stats.pearsonr(correlation_counts_2_brain_planA['p1_beta'],correlation_counts_2_brain_planA['p2_beta'])[1]
ax4.set_xlabel(r"$\beta$ in phase 1" )
ax4.set_ylabel(r"$\beta$ in phase 3")
ax4.text(x=0,y=-0.3,s='$R$ = 0.57',fontsize=8)
ax4.text(x=-0.05,y=-0.4,s='$P$ = 1.25'+mul_symbol_text+'$\mathregular{10^{-26}}$',fontsize=8)


#2E
correlation_counts_2_brain_planA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_planA.csv',index_col=0)
correlation_counts_2_brain_planA.insert(loc=0,column='plan',value=['plan1']*correlation_counts_2_brain_planA.shape[0])
correlation_counts_2_brain_planB = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_planB.csv',index_col=0)
correlation_counts_2_brain_planB.insert(loc=0,column='plan',value=['plan3']*correlation_counts_2_brain_planB.shape[0])
correlation_counts_2_brain_absplanA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_absplanA.csv',index_col=0)
correlation_counts_2_brain_absplanA.insert(loc=0,column='plan',value=['plan2']*correlation_counts_2_brain_absplanA.shape[0])
correlation_counts_2_brain_absplanB = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_absplanB.csv',index_col=0)
correlation_counts_2_brain_absplanB.insert(loc=0,column='plan',value=['plan4']*correlation_counts_2_brain_absplanB.shape[0])
results_all1 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_summarySTATS_1.txt',sep = '\t')
trait_significant_list = list(set(results_all1['trait_id']))
total_1 = pd.concat([correlation_counts_2_brain_planA,correlation_counts_2_brain_planB,correlation_counts_2_brain_absplanA,correlation_counts_2_brain_absplanB])
total_1.insert(loc=0,column='trait_id',value=total_1.apply(lambda x:'|'.join([x[0],x[2]]),axis=1))
total_1.index = total_1['trait_id']
total_2 = total_1.loc[total_1['trait_id'].apply(lambda x: x in trait_significant_list),:]
total_2.mean() # 0.430207
total_2.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/fig2E.csv')
ax5.hist(total_2['correlation'],bins = 30,color='black')
ax5.set_xlabel(r"Pearson's $R$ of $\beta$" )
ax5.set_ylabel('Number of traits')
plt.savefig('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/fig2_11.png')
#S2 p VS r
fig,axes = plt.subplots(2,1,figsize = (4,8))
axes[0].scatter(total_2['correlation'],total_2['Pvalue'].apply(lambda x: -math.log10(x)),c='black',s=3)
axes[0].axhline(y=-math.log10(0.05/(total_2.shape[0])),color='r',ls='--',lw=1)
axes[0].set_xlabel(r"Pearson's $R$ of $\beta$ between phase 1 and phase 3",fontsize = 8)
axes[0].set_ylabel('-lo$\mathregular{g_{10}}$($P$)',fontsize = 8)

axes[1].hist(total_2['Pvalue'].apply(lambda x: -math.log10(x)),bins = 30,color='black')
axes[1].set_xlabel("-lo$\mathregular{g_{10}}$($P$)" )
axes[1].set_ylabel('Number of traits')
plt.savefig('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/figS1.pdf')


###25565-2.0_25566-2.0's loci
filename = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/geno_assoc_asymmetry_control_1_25565-2.0_25566-2.0.fastGWA'
table_whole2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_1.txt',sep = '\t')
table_whole21 = table_whole2.loc[table_whole2['trait_id'] == 'plan1|25565-2.0_25566-2.0']
table_whole21.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/plan1_25565-2.0_25566-2.0_qtl.csv',index=0)