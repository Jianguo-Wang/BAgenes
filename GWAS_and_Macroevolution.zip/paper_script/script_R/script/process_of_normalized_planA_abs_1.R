library(parallel)
library(bestNormalize)
args <- commandArgs(T)
path <- args[1]
proportion <- args[2]
#10 parts
setwd(path)
final_4 <- read.table('symmetry_features_2_3_abs.csv', header = TRUE, sep = "\t",row.names = 1)
final_4_1 <- final_4[,(132*(proportion-1)+1):(132*proportion)]
cluster <- makeCluster(24)
aaaa1<-list()
i = 1
while (i<=dim(final_4_1)[2]){
  print(i)
  aaaa1[[i]] <-bestNormalize(final_4_1[,i],allow_lambert_s = TRUE,cluster = cluster)
  i =i+1
}
i<-3
normalized_data <- cbind(aaaa1[[1]]$x.t,aaaa1[[2]]$x.t)
while (i<=dim(final_4_1)[2]){
  print(i)
  normalized_data <- cbind(normalized_data,aaaa1[[i]]$x.t)
  i =i+1
}
save(aaaa1,file = paste(proportion,'best_normalized_end_absA_4.RData',sep = ''))
row.names(normalized_data) = row.names(final_4_1)
colnames(normalized_data) = colnames(final_4_1)
write.csv(normalized_data,file = paste(proportion,'normalized_data_absA_4.csv',sep = ''),row.names = TRUE)