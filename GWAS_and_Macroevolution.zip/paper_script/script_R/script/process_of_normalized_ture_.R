final_4 <- read.table('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2_3_1.csv', header = TRUE, sep = "\t")
cluster <- makeCluster(60)
aaaa1<-list()
i = 1
while (i<=dim(final_4)[2]){
  print(i)
  aaaa1[[i]] <-bestNormalize(final_4[,i],allow_lambert_s = TRUE,cluster = cluster)
  i =i+1
}

i<-4
normalized_data <- cbind(aaaa1[[2]]$x.t,aaaa1[[3]]$x.t)
while (i<=dim(final_4)[2]){
  print(i)
  normalized_data <- cbind(normalized_data,aaaa1[[i]]$x.t)
  i =i+1
}

setwd('/data/user/msd/ukbiobank_asymmetry/phenotype/data')
save(aaaa1,file = '/data/user/msd/ukbiobank_asymmetry/phenotype/data/best_normalized_end_2.RData')

row.names(normalized_data) = final_4[,1]
colnames(normalized_data) = colnames(final_4)[-1]
write.csv(normalized_data,file = 'normalized_data.csv',row.names = TRUE)
##sd

normalized_data <- read.table('/data/user/msd/ukbiobank_asymmetry/phenotype/data/normalized_data.csv', header = TRUE,row.names = 1, sep = ",")
final_4 <- read.table('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2_3_1.csv', header = TRUE, row.names = 1,sep = "\t")
X_1 = normalized_data
X_1_sd<-apply(X_1,2,sd,na.rm=T)
X = final_4
X_1[,which(X_1_sd<0.99|X_1_sd>1)]<-scale(X[,which(X_1_sd<0.99|X_1_sd>1)])

rownames(X_1)<-rownames(X)
colnames(X_1)<-colnames(X)

##cor with normal 

set.seed(100)
tempNorm<-matrix(rnorm(dim(X_1)[1]*dim(X_1)[2]),nrow=dim(X_1)[1],ncol=dim(X_1)[2])
tempNorm[which(is.na(X_1))]<-NA

normalCor_X_1<-sapply(1:dim(X_1)[2],function(x){cor(sort(na.omit(X_1[,x])),sort(na.omit(tempNorm[,x])))})
normalCor_X<-sapply(1:dim(X_1)[2],function(x){cor(sort(na.omit(X[,x])),sort(na.omit(tempNorm[,x])))})

X_1[,which(normalCor_X>normalCor_X_1)]<-scale(X[,which(normalCor_X>normalCor_X_1)])
write.csv(X_1,file = '/data/user/msd/ukbiobank_asymmetry/phenotype/data/normalized_symmetry_features_1.csv',row.names = TRUE)