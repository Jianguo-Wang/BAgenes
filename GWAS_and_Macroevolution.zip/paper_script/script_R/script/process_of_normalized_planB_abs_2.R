library(parallel)
library(bestNormalize)
setwd('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/')
final_4 <- read.table('symmetry_features_centralized_abs_1.csv', header = TRUE, sep = "\t",row.names = 1)
proportion = 11
final_4_1 <- final_4[,(128*(proportion-1)+1):dim(final_4)[2]]
cluster <- makeCluster(24)
aaaa1<-list()
i = 1
while (i<=dim(final_4_1)[2]){
  print(i)
  aaaa1[[i]] <-bestNormalize(final_4_1[,i],allow_lambert_s = TRUE,cluster = cluster)
  i =i+1
}
i<-3
normalized_data <- cbind(aaaa1[[1]]$x.t,aaaa1[[2]]$x.t)
while (i<=dim(final_4_1)[2]){
  print(i)
  normalized_data <- cbind(normalized_data,aaaa1[[i]]$x.t)
  i =i+1
}
save(aaaa1,file = paste(proportion,'best_normalized_end_absB_4.RData',sep = ''))
row.names(normalized_data) = row.names(final_4_1)
colnames(normalized_data) = colnames(final_4_1)
write.csv(normalized_data,file = paste(proportion,'normalized_data_absB_4.csv',sep = ''),row.names = TRUE)
###############################################
files <- list.files(path = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/',pattern = "normalized_data_absB_4.csv$")
setwd('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/')
normalized_data_0 <- read.table('1normalized_data_absB_4.csv', header = TRUE,row.names = 1, sep = ",")
aa <- which(files == '1normalized_data_absB_4.csv')
files <- files[-aa]
for (a in seq(from=2,to=11,by=1)){
  name = paste(a,'normalized_data_absB_4.csv',sep = '')
  normalized_data_1 <- read.table(name, header = TRUE,row.names = 1, sep = ",")
  normalized_data_0 <- cbind(normalized_data_0,normalized_data_1)
}
sum(colnames(normalized_data_0) == colnames(final_4))
write.csv(normalized_data_0,file = 'normalized_data_absB_4.csv',row.names = TRUE)

##sd###########################
normalized_data <- read.table('normalized_data_absB_4.csv', header = TRUE,row.names = 1, sep = ",")
final_4 <- read.table('symmetry_features_centralized_abs_1.csv', header = TRUE, row.names = 1,sep = "\t")
# a = is.na(final_4)
# b = is.na(normalized_data)
# c = a == b
# d = apply(c, 2, sum)
# e = names(d[d != 409616])#全是4239  离大谱 可全删除 24 traits
# final_4_1 <- final_4[ , -which(colnames(final_4) %in% e)]
# normalized_data_1 <- normalized_data[ , -which(colnames(normalized_data) %in% e)]

X_1 = normalized_data
X_1_sd<-apply(X_1,2,sd,na.rm=T)
X = final_4
X_1[,which(X_1_sd<0.99|X_1_sd>1)]<-scale(X[,which(X_1_sd<0.99|X_1_sd>1)])

rownames(X_1)<-rownames(X)
colnames(X_1)<-colnames(X)

##cor with normal ######################

set.seed(100)
tempNorm<-matrix(rnorm(dim(X_1)[1]*dim(X_1)[2]),nrow=dim(X_1)[1],ncol=dim(X_1)[2])
tempNorm[which(is.na(X_1))]<-NA

normalCor_X_1<-sapply(1:dim(X_1)[2],function(x){cor(sort(na.omit(X_1[,x])),sort(na.omit(tempNorm[,x])))})
normalCor_X<-sapply(1:dim(X_1)[2],function(x){cor(sort(na.omit(X[,x])),sort(na.omit(tempNorm[,x])))})

X_1[,which(normalCor_X>normalCor_X_1)]<-scale(X[,which(normalCor_X>normalCor_X_1)])
write.csv(X_1,file = 'symmetry_features_centralized_abs_2.csv',row.names = TRUE)