library(phenoscanner)
library(parallel)

files <- list.files(path = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval',pattern = "^name")
files1 <- grep('fastGWA$',files,value = T)
#1. 如果名字里有错误的名字，会整批一起报错无结果 2. 如果没有result信息会跳过这个snp的result 只输出snp信息
m<-1 
while (m<=length(files1)){
  print(m)
  a <- files1[m]
  m<-m+1
  context <- read.table(paste("/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval/",a,sep = ''))
  names <- (context$V1)
  if (length(names)>100){
    counts <- length(names)%/%100
    remains <- length(names)%%100
    final1 <- data.frame()
    final2 <- data.frame()
    wrong <- c()
    i <- 1
    while (i<=counts){
      names1 <- grep('^rs',names[((i-1)*100+1):(i*100)],value = T)
      names1_wrong <- grep('^rs',names[((i-1)*100+1):(i*100)],value = T,invert = TRUE)
      wrong <- c(wrong,names1_wrong)
      res <- phenoscanner(snpquery=names1)
      final1<- rbind(final1,res$snps)
      final2<- rbind(final2,res$results)
      i<-i+1
    }
    names1 <- grep('^rs',names[(counts*100+1):length(names)],value = T)
    names1_wrong <- grep('^rs',names[(counts*100+1):length(names)],value = T,invert = TRUE)
    wrong <- c(wrong,names1_wrong)
    res <- phenoscanner(snpquery=names1)
    final1<- rbind(final1,res$snps)
    final2<- rbind(final2,res$results)
    path1 <- paste("/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval/snp_information_",a,sep = '')
    path2 <- paste("/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval/results_information_",a,sep = '')
    path3 <- paste("/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval/wrong_names_",a,sep = '')
    write.table(final1,file = path1,sep = '\t')
    write.table(final2,file = path2,sep = '\t')
    write.table(wrong,file =path3,sep = '\t',row.names = FALSE,col.names = FALSE)
  }else{
    names1 <- grep('^rs',names,value = T)
    names1_wrong <- grep('^rs',names,value = T,invert = TRUE)
    res <- phenoscanner(snpquery=names1)
    path1 <- paste("/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval/snp_information_",a,sep = '')
    path2 <- paste("/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval/results_information_",a,sep = '')
    path3 <- paste("/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval/wrong_names_",a,sep = '')
    write.table(res$snps,file = path1,sep = '\t')
    write.table(res$results,file = path2,sep = '\t')
    write.table(names1_wrong,file =path3,sep = '\t',row.names = FALSE,col.names = FALSE)
  }
  
}
