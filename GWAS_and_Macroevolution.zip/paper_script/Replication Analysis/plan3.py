import pandas as pd
import numpy as np
import pickle,gc,sys
from sklearn.linear_model import LinearRegression
import os,sys,pickle
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from read_bd import return_bd
from gwas_step import process_function_3,extract_clump
from gwas_step import sample_number_threshold,topvalue_proportion_threshold,ancestry_filter,covariates_process_1,generate_phen_step_1,snp_dictionary_chr,symmetry_function_1,snp_dictionary_chr_1
from collections import Counter

###############################################phase2################################################

final = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_1.csv',sep = '\t',index_col = 0)
final_1 = sample_number_threshold(final,final.shape[0]-1000)
final_2 = topvalue_proportion_threshold(final_1,0.5)
final_3 = ancestry_filter(final_2,'/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/bd1_noUK_ancestry_1.txt')
final_3.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_1.csv',sep = '\t')

#Rscript process_of_normalized_v2.R /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/ symmetry_features_planB_p2_1.csv 100

ee = open("/data/user/msd/ukbiobank_asymmetry/phenotype/data/covariates_4.pickle","rb")
covariates_4 = pickle.load(ee)[0]
final = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_v2.csv',sep = ',',index_col =0)
final_0 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_1.csv',sep = '\t',index_col = 0)
final.index = [str(a) for a in final.index]
final.columns = final_0.columns

final_2 = covariates_process_1(final,covariates_4)
final_3 = pd.concat(list(final_2[0].values()),axis=1)
with open('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_3.pickle', 'wb') as f:  # Python 3: open(..., 'wb')
    pickle.dump([final_2], f)
final_3.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_3.txt',sep = '\t')
#################ok
final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_3.txt',sep = '\t',index_col = 0)
#加入family 信息和id  生成phen文件
files = os.listdir('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/')
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('name_')]
files2 = [a.split('_1_')[1].split('_MAF.fastGWA')[0] for a in files1]
final_3_3 = generate_phen_step_1(final_3,'/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_22_whole_nouk_v11_3_hapmap_2.fam')
final_3_3_1 = final_3_3.loc[:,['fam','id']+files2]

final_3_3_1.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/symmetry_features_planB_p2_4.phen',sep = '\t',header = 0,index=0,na_rep = 'NA')
final_3_3_1.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/symmetry_features_planB_p2_4.csv')

snp_names1 = snp_dictionary_chr_1('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/')
a = list(range(23))[1:]
b = [str(x) for x in a]
for num in b:
    print(num)
    with open('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/chr_' + num + '_incl_snp_alternate_id_3.txt', 'w') as f:
        f.write('\n'.join(list(snp_names1[num])))

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3 --extract  /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/chr_' + num + '_incl_snp_alternate_id_3.txt --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/filtered_'+num+'_whole_nouk_v11_3_qtl')
' && '.join(text)

with open('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/mbfile_genome_planB_p2_genome_1.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/filtered_'+num+'_whole_nouk_v11_3_qtl\n')


from multiprocessing import Pool
import pandas as pd
import os
def process_of_gcta_planB_p2(i,name):
    command = '/data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static --mbfile /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/mbfile_genome_planB_p2_genome_1.txt --grm-sparse /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_sp_1 --mpheno '+str(i)+' --fastGWA-mlm --pheno /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/symmetry_features_planB_p2_4.phen  --threads 1 --out /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/geno_assoc_asymmetry_planB_p2_'+name
    os.system(command)
bd = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/symmetry_features_planB_p2_4.csv',index_col=0)
cores_num = 20
pool = Pool(processes=cores_num)
for m in range(bd.shape[1]-2):
    print(m)
    pool.apply_async(process_of_gcta_planB_p2,args=(m+1,bd.columns[m+2],))
pool.close()
pool.join()

with open('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/phase2/mbfile_genome_planB_p2_genome_2.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3\n')
###beta compare
##########result compare true ***
path = '/data/user/msd/ukbiobank_asymmetry/New_gwas/beta_compare_2/planB/clump1/'
prefix1 = 'pval_3_geno_assoc_asymmetry_centralized_1_'
all_data = []
files = [a for a in os.listdir(path) if a.endswith('clumped')]
for file in files:
    name = file.split(prefix1)[1].split('.fastGWA')[0]
    context = extract_clump(path,file)
    mid = [name]*context.shape[0]
    context.insert(0,'trait',mid)
    all_data.append(context)
final3 = pd.concat(all_data)

path1 = '/data/user/msd/ukbiobank_asymmetry/New_gwas/beta_compare_2/planB/'
prefix1 = 'trans_pval_3_geno_assoc_asymmetry_centralized_1_'#使用过滤过的fastgwa可以提高速度的
path2 = '/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/gwas/'
prefix2 = 'geno_assoc_asymmetry_planA_p3_'
ee = open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_planB.pickle',"rb")
planB = pickle.load(ee)
table_planB = planB[0].dropna()
dictionary_pB = Counter(table_planB['trait'])
final = {}
for key in dictionary_pB:
    table1 = final3.loc[final3['trait'] == key,]
    final[key] = [table1]
cores_num = 60
pool = Pool(processes=cores_num)

wrong = []
right = []
i=0
for key in final.keys():
    i+=1
    pathname1 = path1 + prefix1 + key + '.fastGWA'
    pathname2 = path2 + prefix2 + key + '.fastGWA'
    if os.path.exists(pathname2):
        right.append(pool.apply_async(process_function_3, args=(pathname1,pathname2,key,final,i,)))
    else:
        wrong.append(key)
        print(key)
        continue
pool.close()
pool.join()

result_planA = []
for i in right:
    result_planA.append(i.get())

with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/beta_compare_2/planB/clumped_1_combine_sign_test_planB_4.pickle','wb') as F:
    pickle.dump(result_planA, F)

############brain compare ############
import os,pickle,sys
import pandas as pd
import numpy as np
from collections import Counter
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from gwas_step import process_function_3,extract_clump
from multiprocessing import Pool

path1 = '/data/user/msd/ukbiobank_asymmetry/New_gwas/beta_compare_2/planB/'
prefix1 = 'trans_pval_3_geno_assoc_asymmetry_centralized_1_'#使用过滤过的fastgwa可以提高速度的
path2 = '/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/gwas/'
prefix2 = 'geno_assoc_asymmetry_planA_p3_'

from matplotlib import pyplot as plt
ee = open('/data/user/msd/ukbiobank_asymmetry/New_gwas/beta_compare_2/planB/clumped_1_combine_sign_test_planB_4.pickle',"rb")
result_planA = pickle.load(ee)
correlation_counts = {}
for a in result_planA:
    pathname2 = path2 + prefix2 + a[0] + '.fastGWA'
    fastgwas1 = pd.read_csv(pathname2, sep='\t',nrows = 5)
    a1 = a[1].sort_values(by = 'p1_p')
    a2 = a1.iloc[0:200,:]
    correlation_counts[a[0]] = [np.corrcoef(a2['p1_beta'],a2['p2_beta'])[0,1],np.mean(fastgwas1['N'])]


correlation_counts_1 = pd.DataFrame([[a]+correlation_counts[a] for a in correlation_counts.keys()])
correlation_counts_1.columns = ['name','correlation','counts']
a = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/paper_context/symmetry_features_organ_all.csv')
dict_all_organ = dict(zip(a['code'],a['organ_new']))

correlation_counts_1.insert(loc=0,column='organ',value=[dict_all_organ[a.split('_')[0]] for a in correlation_counts_1['name']])
correlation_counts_1_brain = correlation_counts_1.loc[correlation_counts_1['organ'] == 'brain',:]
correlation_counts_1_brain['correlation'].mean()#0.03429044962700193

correlation_counts_1_brain_2 = correlation_counts_1_brain.loc[correlation_counts_1_brain['name'].apply(lambda x: '-3.0' not in x),:]
correlation_counts_1_brain_2['correlation'].mean()#0.040086
correlation_counts_1_brain_2.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_phase2_planB.csv')


#sign concordance rate
from scipy.stats import binom_test
correlation_counts_1 = []
for a in result_planA:
    name = a[0]
    a1 = a[1].copy()
    a1.insert(0, 'trait_name',[name]*a1.shape[0])
    correlation_counts_1.append(a1)
correlation_counts_2 = pd.concat(correlation_counts_1)
correlation_counts_2.insert(0, 'p1_sign',correlation_counts_2['p1_beta'] > 0)
correlation_counts_2.insert(0, 'p2_sign',correlation_counts_2['p2_beta'] > 0)
correlation_counts_2.insert(0,'sign_concordance',correlation_counts_2.apply(lambda x: x[0] == x[1],axis = 1))
correlation_counts_2.insert(loc=0,column='organ',value=[dict_all_organ[a.split('_')[0]] for a in correlation_counts_2['trait_name']])

correlation_counts_2_brain =  correlation_counts_2.loc[correlation_counts_2['organ'] == 'brain',:]
concordance_num = correlation_counts_2_brain.iloc[:,1].sum()#16025 VS 30431
binom_test(concordance_num,correlation_counts_2_brain.shape[0],alternative='greater')# p = 8.691342107671916e-21

correlation_counts_2_brain_2 = correlation_counts_2_brain.loc[correlation_counts_2_brain['trait_name'].apply(lambda x: '-3.0' not in x),:]
concordance_num = correlation_counts_2_brain_2.iloc[:,1].sum()#11988 VS 22453
binom_test(concordance_num,correlation_counts_2_brain_2.shape[0],alternative='greater')# p = 1.478014181513484e-24
correlation_counts_2_brain_2.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_phase2_planB.csv')

###############################################phase3################################################
import pandas as pd
import numpy as np
import pickle,gc,sys,os
from multiprocessing import Pool
from collections import Counter
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from gwas_step import process_function_3,extract_clump

path2 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/'
files = os.listdir(path2)
files2 = [a for a in files if a.startswith('geno_assoc_asymmetry_centralized_1_') and a.endswith('fastGWA')]
names2 = [a.split('geno_assoc_asymmetry_centralized_1_')[1].split('.fastGWA')[0] for a in files2 ]

names11 = [(a.split('-')[0],a.split('.')[1].split('_')[0]) for a in names2]
items_pair = [[a,(a.split('-')[0],a.split('.')[1].split('_')[0])] for a in names2]
aaa = Counter(names11)
bbb = [a for a in aaa.keys() if aaa[a]>1]
final_big_small = []
i=1
for key in bbb:
    items = [a for a in items_pair if key in a]
    dict_items = {}
    print(i)
    i+=1
    for key1 in items:
        name111 = key1[0]
        filename = [a for a in files2 if name111 in a]
        if len(filename)>1:
            raise ValueError
        else:
            filename1 = filename[0]
        datatable = pd.read_csv(path2+filename1, sep='\t',nrows = 10)
        sample_size = datatable.loc[:,'N'].mean()
        dict_items[filename1] = sample_size
    ans1 = sorted(dict_items,key=lambda x:dict_items[x],reverse = True)[0]
    ans2 = sorted(dict_items,key=lambda x:dict_items[x],reverse = True)[1]
    final_big_small.append([ans2,ans1])
final_big_small_1 = pd.DataFrame(final_big_small)
final_big_small_1.columns = ['small','max']
with open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_planB.pickle', 'wb') as f:
    pickle.dump([final_big_small_1], f)
ee = open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_planB.pickle',"rb")
final_big_small_1 = pickle.load(ee)[0]
#############################################

####beta compare ------0.0001 clumped--------------############################
path = '/data/user/msd/ukbiobank_asymmetry/New_gwas/beta_compare_2/planB/clump1/'
prefix1 = 'pval_3_geno_assoc_asymmetry_centralized_1_'
all_data = []
files = [a for a in os.listdir(path) if a.endswith('clumped')]
clump_max_files = ['trans_pval_3_'+a+'.clumped' for a in final_big_small_1['max']]
dictionary1 = dict(zip(final_big_small_1['max'],final_big_small_1['small']))
for file in clump_max_files:
    name = file.split(prefix1)[1].split('.fastGWA')[0]
    context = extract_clump(path,file)
    mid = [name]*context.shape[0]
    context.insert(0,'trait',mid)
    all_data.append((file,dictionary1[file.replace('trans_pval_3_','').replace('.clumped','')],name,context))
final = {}
for key in all_data:
    final[key[2]] = [key[3]]

cores_num = 60
pool = Pool(processes=cores_num)
path1 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/'
prefix1 = 'geno_assoc_asymmetry_centralized_1_'
path2 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/'
prefix2 = 'geno_assoc_asymmetry_centralized_1_'
wrong = []
right = []
i=0
for key in final.keys():
    i+=1
    pathname1 = path1 + prefix1 + key + '.fastGWA'
    pathname2 = path2 + dictionary1[prefix1 + key + '.fastGWA']
    if os.path.exists(pathname2):
        right.append(pool.apply_async(process_function_3, args=(pathname1,pathname2,key,final,i,)))
    else:
        wrong.append(key)
        print(key)
        continue
pool.close()
pool.join()

result_planA = []
for i in right:
    result_planA.append(i.get())

with open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_planB_1.pickle','wb') as F:
    pickle.dump(result_planA, F)

from matplotlib import pyplot as plt
from scipy import stats
ee = open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_planB_1.pickle',"rb")
result_planA = pickle.load(ee)
correlation_counts = {}
for a in result_planA:
    pathname2 = path2 + dictionary1[prefix2 + a[0] + '.fastGWA']
    fastgwas1 = pd.read_csv(pathname2, sep='\t',nrows = 5)
    a1 = a[1].sort_values(by = 'p1_p')
    a2 = a1.iloc[0:200,:]
    correlation_counts[a[0]] = [stats.pearsonr(a1['p1_beta'],a1['p2_beta'])[0],np.mean(fastgwas1['N']),stats.pearsonr(a1['p1_beta'],a1['p2_beta'])[1]]

correlation_counts_1 = pd.DataFrame([[a]+correlation_counts[a] for a in correlation_counts.keys()])
correlation_counts_1.columns = ['name','correlation','counts','Pvalue']
correlation_counts_2 = correlation_counts_1.copy()
correlation_counts_2_brain = correlation_counts_2
correlation_counts_2_brain.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_planB.csv')

#sign concordance rate
from scipy.stats import binom_test
correlation_counts_1 = []
for a in result_planA:
    name = a[0]
    a1 = a[1].copy()
    a1.insert(0, 'trait_name',[name]*a1.shape[0])
    correlation_counts_1.append(a1)
correlation_counts_2 = pd.concat(correlation_counts_1)
correlation_counts_2.insert(0, 'p1_sign',correlation_counts_2['p1_beta'] > 0)
correlation_counts_2.insert(0, 'p2_sign',correlation_counts_2['p2_beta'] > 0)
correlation_counts_2.insert(0,'sign_concordance',correlation_counts_2.apply(lambda x: x[0] == x[1],axis = 1))
concordance_num = correlation_counts_2.iloc[:,0].sum()#80901 VS 125292
binom_test(concordance_num,correlation_counts_2.shape[0],alternative='greater')# p = 0
correlation_counts_2.to_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_planB.csv')

#sig_snp   no nan exist
ee = open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_planB.pickle',"rb")
final_big_small_1 = pickle.load(ee)[0]

path = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/clump1/'
prefix1 = 'pval_geno_assoc_asymmetry_centralized_1_'
all_data = []
files = [a for a in os.listdir(path) if a.endswith('clumped')]
clump_max_files = ['pval_'+a.replace('.fastGWA','_MAF.fastGWA.clumped') for a in final_big_small_1['max']]
dictionary1 = dict(zip(final_big_small_1['max'],final_big_small_1['small']))
clump_max_files_1 = list(set(clump_max_files).intersection(set(files)))
for file in clump_max_files_1:
    name = file.split(prefix1)[1].split('_MAF.fastGWA')[0]
    context = extract_clump(path,file)
    mid = [name]*context.shape[0]
    context.insert(0,'trait',mid)
    all_data.append((file,dictionary1[file.replace('pval_','').replace('.clumped','').replace('_MAF','')],name,context))
final = {}
for key in all_data:
    final[key[2]] = [key[3]]

cores_num = 60
pool = Pool(processes=cores_num)
path1 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/'
prefix1 = 'geno_assoc_asymmetry_centralized_1_'#使用过滤过的fastgwa可以提高速度的
path2 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/'
prefix2 = 'geno_assoc_asymmetry_centralized_1_'
wrong = []
right = []
i=0
for key in final.keys():
    i+=1
    pathname1 = path1 + prefix1 + key + '.fastGWA'
    pathname2 = path2 + dictionary1[prefix1 + key + '.fastGWA']
    if os.path.exists(pathname2):
        right.append(pool.apply_async(process_function_3, args=(pathname1,pathname2,key,final,i,)))
    else:
        wrong.append(key)
        print(key)
        continue
pool.close()
pool.join()

result_planA = []
for i in right:
    result_planA.append(i.get())

with open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_planB_10.pickle','wb') as F:
    pickle.dump(result_planA, F)



############for top beta compare###########
import pandas as pd
import numpy as np
import pickle,gc,sys
from sklearn.linear_model import LinearRegression
import os,sys,pickle
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from gwas_step import generate_phen_step_1

final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_3.txt',sep = '\t',index_col = 0)
#加入family 信息和id  生成phen文件
files = os.listdir('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/')
final_3_3 = generate_phen_step_1(final_3,'/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_22_whole_nouk_v11_3_hapmap_2.fam')

final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_5.phen',sep = '\t',header = 0,index=0,na_rep = 'NA')
final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_5.csv')


from multiprocessing import Pool
import pandas as pd
import os
def process_of_gcta_planA_p3(i,name):
    command = '/data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static --mbfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/mbfile_genome_planA_p2_genome_2.txt  --grm-sparse /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_sp_1 --mpheno '+str(i)+' --fastGWA-mlm --pheno /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_5.phen  --threads 1 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/gwas/geno_assoc_asymmetry_planA_p3_'+name
    os.system(command)
bd = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/symmetry_features_planB_p2_5.csv',index_col=0)
cores_num = 100
pool = Pool(processes=cores_num)
for m in range(bd.shape[1]-2):
    print(m)
    pool.apply_async(process_of_gcta_planA_p3,args=(m+1,bd.columns[m+2],))
pool.close()
pool.join()
