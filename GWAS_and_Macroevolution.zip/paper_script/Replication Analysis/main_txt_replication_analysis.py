import os,pickle,sys
import pandas as pd
import numpy as np
from collections import Counter
from scipy.stats import binom_test

#results combined from 4 plans
import os,pickle,sys
import pandas as pd
import matplotlib as mpl
from matplotlib import pyplot as plt
from collections import Counter
mpl.rcParams['pdf.fonttype'] = 42

a = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/paper_context/symmetry_features_organ_all.csv')
dict_all_organ = dict(zip(a['code'],a['organ_new']))
###################1 phenoscanner combine

path1 = '/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/'
files1 = os.listdir(path1)
files_name_planA = [a for a in files1 if a.find('control_1') != -1]
files_name_planB = [a for a in files1 if a.find('centralized_1') != -1]
files_name_absplanA = [a for a in files1 if a.find('abs_A') != -1]
files_name_absplanB = [a for a in files1 if a.find('abs_B') != -1]

files_name_planA_snp = [a for a in files_name_planA if a.startswith('snp_')]
files_name_planB_snp = [a for a in files_name_planB if a.startswith('snp_')]
files_name_absplanA_snp = [a for a in files_name_absplanA if a.startswith('snp_')]
files_name_absplanB_snp = [a for a in files_name_absplanB if a.startswith('snp_')]
col_table = []
for file in files_name_planA_snp:
    name = file.split('_MAF')[0].split('_control_1_')[1]
    aa = pd.read_table(path1+file)
    aa.insert(loc=0,column='plan',value=['plan1']*aa.shape[0])
    aa.insert(loc=0, column='organ', value=[dict_all_organ[name.split('_')[0]]] * aa.shape[0])
    aa.insert(loc=0, column='trait', value=[name] * (aa.shape[0]))
    col_table.append(aa)
for file in files_name_absplanA_snp:
    name = file.split('_MAF')[0].split('_abs_A_')[1]
    aa = pd.read_table(path1+file)
    aa.insert(loc=0,column='plan',value=['plan2']*aa.shape[0])
    aa.insert(loc=0, column='organ', value=[dict_all_organ[name.split('_')[0]]] * aa.shape[0])
    aa.insert(loc=0, column='trait', value=[name] * (aa.shape[0]))
    col_table.append(aa)
for file in files_name_planB_snp:
    name = file.split('_MAF')[0].split('_centralized_1_')[1]
    aa = pd.read_table(path1+file)
    aa.insert(loc=0,column='plan',value=['plan3']*aa.shape[0])
    aa.insert(loc=0, column='organ', value=[dict_all_organ[name.split('_')[0]]] * aa.shape[0])
    aa.insert(loc=0, column='trait', value=[name] * (aa.shape[0]))
    col_table.append(aa)
for file in files_name_absplanB_snp:
    name = file.split('_MAF')[0].split('_abs_B_')[1]
    aa = pd.read_table(path1+file)
    aa.insert(loc=0,column='plan',value=['plan4']*aa.shape[0])
    aa.insert(loc=0, column='organ', value=[dict_all_organ[name.split('_')[0]]] * aa.shape[0])
    aa.insert(loc=0, column='trait', value=[name] * (aa.shape[0]))
    col_table.append(aa)
col_table1 = pd.concat(col_table)
col_table1.index = list(range(col_table1.shape[0]))
col_table1.insert(loc=0, column='name', value=(col_table1.apply(lambda x: "_".join([x.iloc[0], x.iloc[3]]), axis=1)))
col_table1.index = col_table1.iloc[:, 0]
col_table1.to_csv('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_MAF_GWAS_SNP_1.txt',sep = '\t')

###################2 annovar combine
#the data belowed is copied from gwas_process_drop_maf_1*** script
a = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/paper_context/symmetry_features_organ_all.csv')
dict_all_organ = dict(zip(a['code'],a['organ_new']))

path1 = '/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/annovar/'
files1 = os.listdir(path1)
files_name_planA = [a for a in files1 if a.find('control_1') != -1]
files_name_planB = [a for a in files1 if a.find('centralized_1') != -1]
files_name_absplanA = [a for a in files1 if a.find('abs_A') != -1]
files_name_absplanB = [a for a in files1 if a.find('abs_B') != -1]
col_table = []
for file in files_name_planA:
    name = file.split('_MAF')[0].split('_control_1_')[1]
    aa = pd.read_csv(path1+file)
    aa.insert(loc=0,column='plan',value=['plan1']*aa.shape[0])
    aa.insert(loc=0, column='organ', value=[dict_all_organ[name.split('_')[0]]] * aa.shape[0])
    aa.insert(loc=0, column='trait', value=[name] * (aa.shape[0]))
    col_table.append(aa)
for file in files_name_absplanA:
    name = file.split('_MAF')[0].split('_abs_A_')[1]
    aa = pd.read_csv(path1+file)
    aa.insert(loc=0,column='plan',value=['plan2']*aa.shape[0])
    aa.insert(loc=0, column='organ', value=[dict_all_organ[name.split('_')[0]]] * aa.shape[0])
    aa.insert(loc=0, column='trait', value=[name] * (aa.shape[0]))
    col_table.append(aa)
for file in files_name_planB:
    name = file.split('_MAF')[0].split('_centralized_1_')[1]
    aa = pd.read_csv(path1+file)
    aa.insert(loc=0,column='plan',value=['plan3']*aa.shape[0])
    aa.insert(loc=0, column='organ', value=[dict_all_organ[name.split('_')[0]]] * aa.shape[0])
    aa.insert(loc=0, column='trait', value=[name] * (aa.shape[0]))
    col_table.append(aa)
for file in files_name_absplanB:
    name = file.split('_MAF')[0].split('_abs_B_')[1]
    aa = pd.read_csv(path1+file)
    aa.insert(loc=0,column='plan',value=['plan4']*aa.shape[0])
    aa.insert(loc=0, column='organ', value=[dict_all_organ[name.split('_')[0]]] * aa.shape[0])
    aa.insert(loc=0, column='trait', value=[name] * (aa.shape[0]))
    col_table.append(aa)
col_table1 = pd.concat(col_table)
col_table1.index = list(range(col_table1.shape[0]))
col_table1.to_csv('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_MAF_GWAS_SNP_annovar_1.txt',sep = '\t')

###################3 location to snp id index
list1 = []
path1 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/MAF_GWAS/annovar_annotation/'
files = os.listdir(path1)
files = [a for a in files if a.endswith('avinput')]
snp_inf = []
for file in files:
    context =pd.read_csv(path1+file,sep='\t',header=None)
    context.columns = ['chr','start','end','ref','alt','snp']
    snp_inf.append(context)
snp_inf_1 = pd.concat(snp_inf)
snp_inf_1.insert(loc = 0,column = 'inf',value = snp_inf_1.apply(lambda x: '_'.join([str(x['chr']),str(x['start']),str(x['end'])]),axis=1 ))
snp_inf_2 = snp_inf_1.drop_duplicates()
list1.append(snp_inf_2)

path1 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/annovar_annotation/'
files = os.listdir(path1)
files = [a for a in files if a.endswith('avinput')]
snp_inf = []
for file in files:
    context =pd.read_csv(path1+file,sep='\t',header=None)
    context.columns = ['chr','start','end','ref','alt','snp']
    snp_inf.append(context)
snp_inf_1 = pd.concat(snp_inf)
snp_inf_1.insert(loc = 0,column = 'inf',value = snp_inf_1.apply(lambda x: '_'.join([str(x['chr']),str(x['start']),str(x['end'])]),axis=1 ))
snp_inf_2 = snp_inf_1.drop_duplicates()
list1.append(snp_inf_2)

path1 = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_A_1/MAF_GWAS/annovar_annotation/'
files = os.listdir(path1)
files = [a for a in files if a.endswith('avinput')]
snp_inf = []
for file in files:
    context =pd.read_csv(path1+file,sep='\t',header=None)
    context.columns = ['chr','start','end','ref','alt','snp']
    snp_inf.append(context)
snp_inf_1 = pd.concat(snp_inf)
snp_inf_1.insert(loc = 0,column = 'inf',value = snp_inf_1.apply(lambda x: '_'.join([str(x['chr']),str(x['start']),str(x['end'])]),axis=1 ))
snp_inf_2 = snp_inf_1.drop_duplicates()
list1.append(snp_inf_2)

path1 = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/MAF_GWAS/annovar_annotation/'
files = os.listdir(path1)
files = [a for a in files if a.endswith('avinput')]
snp_inf = []
for file in files:
    context =pd.read_csv(path1+file,sep='\t',header=None)
    context.columns = ['chr','start','end','ref','alt','snp']
    snp_inf.append(context)
snp_inf_1 = pd.concat(snp_inf)
snp_inf_1.insert(loc = 0,column = 'inf',value = snp_inf_1.apply(lambda x: '_'.join([str(x['chr']),str(x['start']),str(x['end'])]),axis=1 ))
snp_inf_2 = snp_inf_1.drop_duplicates()
list1.append(snp_inf_2)

list2 = pd.concat(list1)
dataframe1 = list2.drop_duplicates()
dict_snp = dict(zip(dataframe1['inf'],dataframe1['snp']))
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/dict_snp_location.pickle', 'wb') as f:
    pickle.dump([dict_snp], f)
###################################

ee = open("/data/user/msd/ukbiobank_asymmetry/New_gwas/dict_snp_location.pickle","rb")
dict_snp = pickle.load(ee)[0]

col_table1=pd.read_table('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_MAF_GWAS_SNP_annovar_1.txt',sep = '\t',index_col=0)
col_table1.insert(loc = 0,column = 'inf',value = col_table1.apply(lambda x: '_'.join([str(x['Chr']),str(x['Start']),str(x['End'])]),axis=1 ))
col_table1.insert(loc = 0,column = 'snp',value = col_table1.apply(lambda x: dict_snp[x['inf']],axis=1 ))
col_table1.insert(loc=0,column = 'name',value=col_table1.apply(lambda x: "_".join([x.iloc[2],x.iloc[0]]),axis=1))
col_table1.index = col_table1.iloc[:,0]
col_table1.to_csv('/data/user/msd/ukbiobank_asymmetry/New_gwas/annotation/all_MAF_GWAS_SNP_annovar_2.txt',sep = '\t')

###################4 clump combine
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from gwas_step import clumped_collect_3,compare_clump_packing_1

dictionary_planA_p1 = clumped_collect_3('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/MAF_GWAS/clump1/','control_1_')
dictionary_planB_p1 = clumped_collect_3('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/clump1/','centralized_1_')
dictionary_abs_planA_p1 = clumped_collect_3('/data/user/msd/ukbiobank_asymmetry/absolute_plan_A_1/MAF_GWAS/clump1/','_abs_A_')
dictionary_abs_planB_p1 = clumped_collect_3('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/MAF_GWAS/clump1/','_abs_B_')
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_planA_clumped_2.pickle', 'wb') as f:
    pickle.dump([dictionary_planA_p1], f)
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_planB_clumped_2.pickle', 'wb') as f:
    pickle.dump([dictionary_planB_p1], f)
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_abs_planA_clumped_2.pickle','wb') as F:
    pickle.dump([dictionary_abs_planA_p1], F)
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_abs_planB_clumped_2.pickle','wb') as F:
    pickle.dump([dictionary_abs_planB_p1], F)

planA = compare_clump_packing_1('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/MAF_GWAS/phase2/','geno_assoc_asymmetry_planA_p2_','/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_planA_clumped_2.pickle','planA_','/data/user/msd/ukbiobank_asymmetry/New_gwas/GWAS_result_compare/')
planB = compare_clump_packing_1('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planB_phase2/gwas/','geno_assoc_asymmetry_planB_p2_','/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_planB_clumped_2.pickle','planB_','/data/user/msd/ukbiobank_asymmetry/New_gwas/GWAS_result_compare/')
abs_planA = compare_clump_packing_1('/data/user/msd/ukbiobank_asymmetry/absolute_plan_A_2/gwas/','geno_assoc_asymmetry_abs_planA_p2_','/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_abs_planA_clumped_2.pickle','abs_planA_','/data/user/msd/ukbiobank_asymmetry/New_gwas/GWAS_result_compare/')
abs_planB = compare_clump_packing_1('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_2/gwas/','geno_assoc_asymmetry_abs_planB_p2_','/data/user/msd/ukbiobank_asymmetry/New_gwas/symmetry_features_abs_planB_clumped_2.pickle','abs_planB_','/data/user/msd/ukbiobank_asymmetry/New_gwas/GWAS_result_compare/')
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_planA_1.pickle', 'wb') as f:
    pickle.dump(planA, f)
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_planB_1.pickle', 'wb') as f:
    pickle.dump(planB, f)
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_abs_planA_1.pickle','wb') as F:
    pickle.dump(abs_planA, F)
with open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_abs_planB_1.pickle','wb') as F:
    pickle.dump(abs_planB, F)

#phase2
#snp number in phase2
ee = open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_planA_1.pickle',"rb")
planA = pickle.load(ee)
planA11 = planA[0].dropna()
planA11.insert(loc=0,column='plan',value=['plan1']*planA11.shape[0])
ee = open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_planB_1.pickle',"rb")
planA = pickle.load(ee)
planB11 = planA[0].dropna()
planB11.insert(loc=0,column='plan',value=['plan3']*planB11.shape[0])
ee = open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_abs_planA_1.pickle',"rb")
planA = pickle.load(ee)
absplanA11 = planA[0].dropna()
absplanA11.insert(loc=0,column='plan',value=['plan2']*absplanA11.shape[0])
ee = open('/data/user/msd/ukbiobank_asymmetry/New_gwas/compare_clump_abs_planB_1.pickle',"rb")
planA = pickle.load(ee)
absplanB11 = planA[0].dropna()
absplanB11.insert(loc=0,column='plan',value=['plan4']*absplanB11.shape[0])

table1 = pd.concat([planA11,planB11,absplanA11,absplanB11])
table2 =table1.loc[table1['organ'] == 'brain',:]
table3 =table2.loc[table2['trait'].apply(lambda x: '-3.0' not in x),:]
table3.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/brainloci_replicate_phase2_total_whole.csv')
table3_s1 = table3.loc[table3.apply(lambda x:x[-1] < (0.05/(table3.shape[0])),axis = 1),:]#19
binom_test(table3_s1.shape[0],table3.shape[0],p=0.05/(table3.shape[0]),alternative='greater')# p = 1.2791482828727135e-42
table3_s1.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/brainloci_replicate_phase2_total.csv')

#beta replicate in phase2
correlation_counts_2_brain_planA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_phase2_planA.csv',index_col=0)
correlation_counts_2_brain_planA.insert(loc=0,column='plan',value=['plan1']*correlation_counts_2_brain_planA.shape[0])
correlation_counts_2_brain_planB = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_phase2_planB.csv',index_col=0)
correlation_counts_2_brain_planB.insert(loc=0,column='plan',value=['plan3']*correlation_counts_2_brain_planB.shape[0])
correlation_counts_2_brain_absplanA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_phase2_absplanA.csv',index_col=0)
correlation_counts_2_brain_absplanA.insert(loc=0,column='plan',value=['plan2']*correlation_counts_2_brain_absplanA.shape[0])

total_1 = pd.concat([correlation_counts_2_brain_planA,correlation_counts_2_brain_planB,correlation_counts_2_brain_absplanA])
total_1.mean() #0.053672
from matplotlib import pyplot as plt
plt.clf()
plt.hist(total_1['correlation'],bins = 100)
plt.savefig('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_beata_phase2_hist_total_1_brain.pdf')

#sign compare
sign_counts_2_brain_planA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_phase2_planA.csv',index_col=0)
sign_counts_2_brain_planA.insert(loc=0,column='plan',value=['plan1']*sign_counts_2_brain_planA.shape[0])
sign_counts_2_brain_planB = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_phase2_planB.csv',index_col=0)
sign_counts_2_brain_planB.insert(loc=0,column='plan',value=['plan3']*sign_counts_2_brain_planB.shape[0])
sign_counts_2_brain_absplanA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_phase2_absplanA.csv',index_col=0)
sign_counts_2_brain_absplanA.insert(loc=0,column='plan',value=['plan2']*sign_counts_2_brain_absplanA.shape[0])
total_2 = pd.concat([sign_counts_2_brain_planA,sign_counts_2_brain_planB,sign_counts_2_brain_absplanA])
concordance_num = total_2.loc[:,'sign_concordance'].sum()#38254 VS 71159
binom_test(concordance_num,total_2.shape[0],alternative='greater')# p = 8.647905160132537e-90

##phase3
#replicate SNP
ee = open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_planA_10.pickle',"rb")
result_planA = pickle.load(ee)
list_1 = []
for item in result_planA:
    name = item[0]
    aaa = item[1]
    aaa.insert(loc=0,column='trait',value=[name]*aaa.shape[0])
    list_1.append(aaa)
result_planA1 = pd.concat(list_1)
result_planA1.insert(loc=0,column='organ',value=[dict_all_organ[a.split('_')[0]] for a in result_planA1['trait']])
result_planA1.insert(loc=0,column='plan',value=['plan1']*result_planA1.shape[0])
ee = open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_planB_10.pickle',"rb")
result_planA = pickle.load(ee)
list_1 = []
for item in result_planA:
    name = item[0]
    aaa = item[1]
    aaa.insert(loc=0,column='trait',value=[name]*aaa.shape[0])
    list_1.append(aaa)
result_planB1 = pd.concat(list_1)
result_planB1.insert(loc=0,column='organ',value=[dict_all_organ[a.split('_')[0]] for a in result_planB1['trait']])
result_planB1.insert(loc=0,column='plan',value=['plan3']*result_planB1.shape[0])
ee = open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_absplanA_10.pickle',"rb")
result_planA = pickle.load(ee)
list_1 = []
for item in result_planA:
    name = item[0]
    aaa = item[1]
    aaa.insert(loc=0,column='trait',value=[name]*aaa.shape[0])
    list_1.append(aaa)
result_absplanA1 = pd.concat(list_1)
result_absplanA1.insert(loc=0,column='organ',value=[dict_all_organ[a.split('_')[0]] for a in result_absplanA1['trait']])
result_absplanA1.insert(loc=0,column='plan',value=['plan2']*result_absplanA1.shape[0])
ee = open('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_time_absplanB_10.pickle',"rb")
result_planA = pickle.load(ee)
list_1 = []
for item in result_planA:
    name = item[0]
    aaa = item[1]
    aaa.insert(loc=0,column='trait',value=[name]*aaa.shape[0])
    list_1.append(aaa)
result_absplanB1 = pd.concat(list_1)
result_absplanB1.insert(loc=0,column='organ',value=[dict_all_organ[a.split('_')[0]] for a in result_absplanB1['trait']])
result_absplanB1.insert(loc=0,column='plan',value=['plan4']*result_absplanB1.shape[0])

aaaa = pd.concat([result_planA1,result_planB1,result_absplanA1,result_absplanB1])
table3 = aaaa.loc[aaaa['organ'] =='brain',: ]
table3.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/brainloci_replicate_phase3_total_whole.csv')
table3_s1 = table3.loc[table3.apply(lambda x:x[-1] < (0.05/(table3.shape[0])),axis = 1),:]#1
binom_test(table3_s1.shape[0],table3.shape[0],p=0.05/(table3.shape[0]),alternative='greater')# p = 0.04877159967696033
table3_s1.to_csv('/data/user/msd/ukbiobank_asymmetry/msd_paper_use/brainloci_replicate_phase3_total.csv')

#beta correlation
correlation_counts_2_brain_planA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_planA.csv',index_col=0)
correlation_counts_2_brain_planA.insert(loc=0,column='plan',value=['plan1']*correlation_counts_2_brain_planA.shape[0])
correlation_counts_2_brain_planB = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_planB.csv',index_col=0)
correlation_counts_2_brain_planB.insert(loc=0,column='plan',value=['plan3']*correlation_counts_2_brain_planB.shape[0])
correlation_counts_2_brain_absplanA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_absplanA.csv',index_col=0)
correlation_counts_2_brain_absplanA.insert(loc=0,column='plan',value=['plan2']*correlation_counts_2_brain_absplanA.shape[0])
correlation_counts_2_brain_absplanB = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/brain_beta_corr_absplanB.csv',index_col=0)
correlation_counts_2_brain_absplanB.insert(loc=0,column='plan',value=['plan4']*correlation_counts_2_brain_absplanB.shape[0])

results_all1 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_summarySTATS_1.txt',sep = '\t')
trait_significant_list = list(set(results_all1['trait_id']))

total_1 = pd.concat([correlation_counts_2_brain_planA,correlation_counts_2_brain_planB,correlation_counts_2_brain_absplanA,correlation_counts_2_brain_absplanB])
total_1.insert(loc=0,column='trait_id',value=total_1.apply(lambda x:'|'.join([x[0],x[2]]),axis=1))
total_1.index = total_1['trait_id']
total_2 = total_1.loc[total_1['trait_id'].apply(lambda x: x in trait_significant_list),:]
total_2.mean() # 0.430207
from matplotlib import pyplot as plt
plt.clf()
plt.hist(total_1['correlation'],bins = 30)
plt.savefig('/data/user/msd/ukbiobank_asymmetry/compare_2_time/compare_beata_hist_total_1_brain.pdf')

#sign compare
sign_counts_2_brain_planA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_planA.csv',index_col=0)
sign_counts_2_brain_planA.insert(loc=0,column='plan',value=['plan1']*sign_counts_2_brain_planA.shape[0])
sign_counts_2_brain_planB = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_planB.csv',index_col=0)
sign_counts_2_brain_planB.insert(loc=0,column='plan',value=['plan3']*sign_counts_2_brain_planB.shape[0])
sign_counts_2_brain_absplanA = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_absplanA.csv',index_col=0)
sign_counts_2_brain_absplanA.insert(loc=0,column='plan',value=['plan2']*sign_counts_2_brain_absplanA.shape[0])
sign_counts_2_brain_absplanB = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/compare_2_time/all_sign_absplanB.csv',index_col=0)
sign_counts_2_brain_absplanB.insert(loc=0,column='plan',value=['plan4']*sign_counts_2_brain_absplanB.shape[0])

total_21 = pd.concat([sign_counts_2_brain_planA,sign_counts_2_brain_planB,sign_counts_2_brain_absplanA,sign_counts_2_brain_absplanB])
results_all1 = pd.read_table('/data/user/msd/ukbiobank_asymmetry/compare_2_time/whole_clump_inf_1_allclump_summarySTATS_1.txt',sep = '\t')
trait_significant_list = list(set(results_all1['trait_id']))
total_21.insert(loc=0,column='trait_id',value=total_21.apply(lambda x:'|'.join([x[0],x[4]]),axis=1))
total_21.index = total_21['trait_id']
total_2 = total_21.loc[total_21['trait_id'].apply(lambda x: x in trait_significant_list),:]

concordance_num = total_2.iloc[:,2].sum()#55824 VS 80390
concordance_num/total_2.shape[0] # 0.6944147282000249
binom_test(concordance_num,total_2.shape[0],alternative='greater')# p = 0
