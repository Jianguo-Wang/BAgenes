import pickle,sys,os
import numpy as np
import pandas as pd
from collections import Counter
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from read_bd import return_bd
#from PCA_population
bd = return_bd()
bd1 = bd.iloc[1:, :]
bd1.index = bd1['eid']
bd1_UK_ancestry_0 = bd1.loc[:,['21000-0.0','21000-1.0','21000-2.0']]
bd1_UK_ancestry_0.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/bd1_ancestry_0.txt',sep = '\t')
#from PCA_population end

##################################
#######kinship generalized#########from gwas_step_for_no_uk_phase_2_1.py
##################################
bd = return_bd()
bd1 = bd.iloc[1:, :]
bd1.index = bd1['eid']
#22006
bd1_UK_ancestry= bd1['22006-0.0']
bd1_noUK_ancestry_1 = bd1_UK_ancestry.loc[bd1_UK_ancestry != '1',]
bd1_noUK_ancestry_1.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/bd1_noUK_ancestry.txt',sep = '\t')
bd1_noUK_ancestry_1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/bd1_noUK_ancestry.txt',sep = '\t')
bd1_noUK_ancestry_1['eid'] = [str(a) for a in bd1_noUK_ancestry_1['eid']]
with open('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/noEI_ancestry_1.txt', 'w') as f:
    f.write('\t'.join(list(bd1_noUK_ancestry_1['eid'])))
fam_format = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_1_whole_2.fam', sep='\t',header = None)
fam_format.index = [str(a) for a in fam_format.iloc[:,1]]
uk_ind_with_geno = set(bd1_noUK_ancestry_1['eid']).intersection(fam_format.index)
fam_format_1= fam_format.loc[list(uk_ind_with_geno),:]
fam_format_1.iloc[:,[0,1]].to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filter_nouk_ind.txt', sep = ' ',header=0,index=0,na_rep = 'NA')

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_'+num+'_whole_2 --keep  /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filter_nouk_ind.txt --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_3')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_3 --geno 0.05 --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_4')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_4 --hwe 1e-6 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_5')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_5 --extract  /data/user/msd/hapmap3/hapmap3_snp.txt --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_hapmap_1')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_hapmap_1 --indep-pairwise 1000 100 0.9 --maf 0.01 --threads 60 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_hapmap_1_pruned')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_hapmap_1 --extract  /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_hapmap_1_pruned.prune.in --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_hapmap_2')
' && '.join(text)

#for whole genome
with open('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/mbfile_list_2.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_5\n')

with open('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/mbfile_list_hapmap_pruned_2.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v2_hapmap_2\n')

#/data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/mbfile_list_hapmap_pruned_2.txt --make-grm-part 4 1 --thread-num 30 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1
#/data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/mbfile_list_hapmap_pruned_2.txt --make-grm-part 4 2 --thread-num 30 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1
#/data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/mbfile_list_hapmap_pruned_2.txt --make-grm-part 4 3 --thread-num 30 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1
#/data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/mbfile_list_hapmap_pruned_2.txt --make-grm-part 4 4 --thread-num 30 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1
#cat /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1.part_4_*.grm.id > /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1.grm.id
#cat /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1.part_4_*.grm.bin > /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1.grm.bin
#cat /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1.part_4_*.grm.N.bin > /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1.grm.N.bin

#/data/user/msd/gcta_1.93.3beta2/gcta64 --grm /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1 --make-bK-sparse 0.05 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1_sp_grm

from collections import Counter
sp_table = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1_sp_grm.grm.sp',sep = '\t')
sp_table.columns = ['iid1','iid2','kinship']
sp_table_1 = sp_table.loc[sp_table['iid1'] != sp_table['iid2'] ,:]
index_list = list(sp_table_1['iid1'])+list(sp_table_1['iid2'])
C = Counter(index_list)
data_table = pd.DataFrame({'name':C.keys(),'counts':C.values()})
data_table.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/kinship_colletions.csv')

##from gwas_step_for_no_uk_phase_2_1.py end

bd = return_bd()
bd1 = bd.iloc[1:, :]
bd1.index = bd1['eid']
bd1_UK_ancestry= bd1['22006-0.0']
bd1_noUK_ancestry_1 = bd1_UK_ancestry.loc[bd1_UK_ancestry != '1',]
bd1_noUK_ancestry_1.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/bd1_noUK_ancestry.txt',sep = '\t')
bd1_UK_ancestry_0 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/bd1_ancestry_0.txt',sep = '\t',dtype = object)
bd1_UK_ancestry_0.index = bd1_UK_ancestry_0['eid']
bd1_noUK_ancestry_1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/bd1_noUK_ancestry.txt',sep = '\t',dtype = object)
bd1_noUK_ancestry_1.index = bd1_noUK_ancestry_1['eid']

admixed_population  = ['2001','2002','2003','2004','6','-1','-3','2']
bd1_noUK_ancestry_2 = bd1_UK_ancestry_0.loc[bd1_noUK_ancestry_1.index,:]
a = bd1_noUK_ancestry_2['21000-0.0'].apply(lambda x:x not in admixed_population)
b = Counter(bd1_noUK_ancestry_2['21000-0.0'])
bd1_noUK_ancestry_3 = bd1_noUK_ancestry_2.loc[a,:]
bd1_noUK_ancestry_4 = bd1_noUK_ancestry_3.loc[bd1_noUK_ancestry_3['21000-0.0'].dropna().index,:]
fam_format = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_1_whole_2.fam', sep='\t',header = None)
fam_format.index = [str(a) for a in fam_format.iloc[:,1]]
nouk_ind_with_geno = set(bd1_noUK_ancestry_4['eid']).intersection(fam_format.index)
bd1_noUK_ancestry_5 = bd1_noUK_ancestry_4.loc[nouk_ind_with_geno,:]

data_table = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/kinship_colletions.csv',index_col = 0)
id_list = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/symmetry_grm_hapmap3_pruned_1_sp_grm.grm.id',sep = '\t',header=None,dtype = object)
id_list.columns = ['family','id']
dictionary_id = dict(zip(id_list['family'],id_list['id']))
data_table_1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/kinship_colletions_error.csv',index_col = 0)
data_table_2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/kinship_colletions_true.csv',index_col = 0)
#100？
data_table.index = data_table['name']
data_table_remove = data_table.loc[data_table['counts'] >100,:]
id_list_1 = id_list.iloc[data_table_remove.index,:]

inter_1 = set(id_list_1['id']).intersection(set(bd1_noUK_ancestry_5['eid']))
bd1_noUK_ancestry_6 = bd1_noUK_ancestry_5.drop(list(inter_1))
fam_format = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_1_whole_2.fam', sep='\t',header = None)
fam_format.index = [str(a) for a in fam_format.iloc[:,1]]
fam_format_1= fam_format.loc[list(bd1_noUK_ancestry_6['eid']),:]
fam_format_1.iloc[:,[0,1]].to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filter_mixed_nouk_1.txt', sep = ' ',header=0,index=0,na_rep = 'NA')

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_'+num+'_whole_2 --keep  /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filter_mixed_nouk_1.txt --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_1')
' && '.join(text)
#

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_1 --geno 0.05 --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_2')
' && '.join(text)
###########OK
text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_2 --hwe 1e-6 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_3')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_3 --extract  /data/user/msd/hapmap3/hapmap3_snp.txt --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_3_hapmap_1')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_3_hapmap_1 --indep-pairwise 1000 100 0.9 --maf 0.01 --threads 60 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_3_hapmap_1_pruned')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_3_hapmap_1 --extract  /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_3_hapmap_1_pruned.prune.in --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_'+num+'_whole_nouk_v10_3_hapmap_2')
' && '.join(text)
#mv /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_*_whole_nouk_v10_3_hapmap_2* /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2
#mv /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/genotype/filtered_*_whole_nouk_v10_3* /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2
#for whole genome

with open('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/mbfile_hapmap_planA_p2.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v10_3_hapmap_2\n')

#/data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static --mbfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/mbfile_hapmap_planA_p2.txt --make-grm --thread-num 100 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2

#/data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static --grm /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2 --make-bK-sparse 0.05 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_sp

from collections import Counter
sp_table = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_sp.grm.sp',sep = '\t',header = None)
sp_table.columns = ['iid1','iid2','kinship']
sp_table_1 = sp_table.loc[sp_table['iid1'] != sp_table['iid2'] ,:]
index_list = list(sp_table_1['iid1'])+list(sp_table_1['iid2'])
C = Counter(index_list)
data_table = pd.DataFrame({'name':C.keys(),'counts':C.values()})
data_table.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/kinship_colletions_planA_p2.csv')

data_table = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/kinship_colletions_planA_p2.csv',index_col = 0)
id_list = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_sp.grm.id',sep = '\t',header=None,dtype = object)
id_list.columns = ['family','id']
dictionary_id = dict(zip(id_list['family'],id_list['id']))
data_table.index = data_table['name']
data_table_remove = data_table.loc[data_table['counts'] >100,:]
id_list_1 = id_list.iloc[data_table_remove.index,:]
fam_format = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_22_whole_nouk_v10_3.fam', sep='\t',header = None)
fam_format.index = [str(a) for a in fam_format.iloc[:,1]]
fam_format_1= fam_format.drop(id_list_1['id'])
fam_format_1.iloc[:,[0,1]].to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filter_planA_p2_nouk_1.txt', sep = ' ',header=0,index=0,na_rep = 'NA')
fam_format_2 = fam_format_1.iloc[:,[1,2]]
fam_format_2.columns = ['eid','unused']
fam_format_2.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/bd1_noUK_ancestry_1.txt',sep = '\t',index = 0)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_'+num+'_whole_2 --keep  /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filter_planA_p2_nouk_1.txt --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_1')
' && '.join(text)
#

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_1 --geno 0.05 --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_2')
' && '.join(text)
text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_2 --hwe 1e-6 --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3')
' && '.join(text)
text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3 --extract  /data/user/msd/hapmap3/hapmap3_snp.txt --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3_hapmap_1')
' && '.join(text)
text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3_hapmap_1 --indep-pairwise 1000 100 0.9 --maf 0.01 --threads 100 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3_hapmap_1_pruned')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3_hapmap_1 --extract  /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3_hapmap_1_pruned.prune.in --make-bed --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3_hapmap_2')
' && '.join(text)
#for whole genome
with open('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/mbfile_genome_planA_p2_1.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3\n')

with open('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/mbfile_hapmap_planA_p2_1.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3_hapmap_2\n')

#/data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static --mbfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/mbfile_hapmap_planA_p2_1.txt --make-grm --thread-num 100 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_1

#/data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static --grm /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_1 --make-bK-sparse 0.05 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_sp_1
