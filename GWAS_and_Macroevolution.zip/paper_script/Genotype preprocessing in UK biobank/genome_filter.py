import pandas as pd
import sys,os
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from read_bd import return_bd
from collections import Counter

import pandas as pd

def get_variant_id(num,MAF,Info_score):
    sample_file = '/home/msd/ShortcutTo96/biobank/biobank_sample_genetics/variants_inf_chr'+num+'_v3.txt'
    df = pd.read_csv(sample_file,sep = '\t',header = None)
    df.columns = ['Alternate_id','RS_id','Position','Allele1','Allele2','MAF','Minor Allele','Info score']
    df1 = df.loc[((df['MAF']>MAF) & (df['Info score']>Info_score)),:]
    Alter_ids = df1['Alternate_id']
    return Alter_ids

a = list(range(23))[1:]
b = [str(x) for x in a]
for num in b:
    print(num)
    MAF = 0.01
    Info_score = 0.8
    order_snp_id_1 = get_variant_id(num,MAF,Info_score)
    with open('/data/user/msd/ukbiobank_asymmetry/genotype/chr_' + num + '_incl_snp_alternate_id_2.txt', 'w') as f:
        f.write(' '.join(list(order_snp_id_1)))

for num in [str(a+1) for a in list(range(22))]:
    print('/home/msd/ShortcutTo96/qctool/qctool_v2.0.6-Ubuntu16.04-x86_64/qctool -g /data/resource/project/ukb/ukb_chr'+num+'.bgen -s /home/msd/ShortcutTo96/biobank/biobank_sample_genetics/ukb_genome_c_' + num + '.sample -ofiletype binary_ped -threshold 0.9 -og /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_'+num+'_whole_1 -incl-snpids /data/user/msd/ukbiobank_asymmetry/genotype/chr_' + num + '_incl_snp_alternate_id_2.txt -os /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/chr_'+num+'_out_sample_whole_1.txt')

#biallilic genotype
for num in [str(a+1) for a in list(range(22))]:
    data = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_'+num+'_whole_1.bim',sep=' ',header = None)
    data.index = data.iloc[:,1]
    C = Counter(data.iloc[:,1])
    multi = [key for key in C if C[key] > 1]
    data1 = data.loc[multi,:]
    print(num)
    print(data.shape[0] - len(list(set(data.iloc[:,1]))))
    print(data1.shape[0]/data.shape[0])
    data2 = data1.iloc[:,1][data1.iloc[:,1].duplicated() == False]
    data2.to_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/excluded_multi_'+str(num)+'_1.txt', sep = ' ',header=0,index=0,na_rep = 'NA')

for num in [str(a+1) for a in list(range(22))]:
    print('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_'+num+'_whole_1 --exclude /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/excluded_multi_'+str(num)+'_1.txt --make-bed --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_'+num+'_whole_2')


#ethnicity backgroud
bd = return_bd()
bd1 = bd.iloc[1:, :]
bd1.index = bd1['eid']
#22006
bd1_UK_ancestry= bd1['22006-0.0']
bd1_UK_ancestry_1 = bd1_UK_ancestry.loc[bd1_UK_ancestry == '1',]
bd1_UK_ancestry_1.to_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/bd1_UK_ancestry.txt',sep = '\t')
bd1_UK_ancestry_1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/bd1_UK_ancestry.txt',sep = '\t')
bd1_UK_ancestry_1['eid'] = [str(a) for a in bd1_UK_ancestry_1['eid']]
with open('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/EI_ancestry_1.txt', 'w') as f:
    f.write('\t'.join(list(bd1_UK_ancestry_1['eid'])))
fam_format = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_1_whole_2.fam', sep='\t',header = None)
fam_format.index = [str(a) for a in fam_format.iloc[:,1]]
uk_ind_with_geno = set(bd1_UK_ancestry_1['eid']).intersection(fam_format.index)
fam_format_1= fam_format.loc[list(uk_ind_with_geno),:]
fam_format_1.iloc[:,[0,1]].to_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filter_uk_ind.txt', sep = ' ',header=0,index=0,na_rep = 'NA')

text = []
for num in [str(a+1) for a in list(range(22))]:
    print('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_1/filtered_'+num+'_whole_2 --keep  /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filter_uk_ind.txt --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_3')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    print('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_3 --geno 0.05 --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_4')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_4 --hwe 1e-6 --make-bed --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_5')
' && '.join(text)

bd1_UK_ancestry = pd.read_csv('/data/user/msd/hapmap3/hapmap3_r2_b36_fwd.consensus.qc.poly.map',sep = '\t',header=None)
l1 = list(bd1_UK_ancestry.iloc[:,1])
with open('/data/user/msd/hapmap3/hapmap3_snp.txt', 'w') as f:
    f.write(' '.join(list(l1)))

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_5 --extract  /data/user/msd/hapmap3/hapmap3_snp.txt --make-bed --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_hapmap_1')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_hapmap_1 --indep-pairwise 1000 100 0.9 --maf 0.01 --threads 60 --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_hapmap_1_pruned')
' && '.join(text)

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_hapmap_1 --extract  /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_hapmap_1_pruned.prune.in --make-bed --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_hapmap_2')
' && '.join(text)

#for whole genome
with open('/data/user/msd/ukbiobank_asymmetry/gwas/mbfile_list_test_1.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_5\n')

