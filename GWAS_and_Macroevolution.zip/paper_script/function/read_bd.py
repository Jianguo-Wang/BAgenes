import pickle,gc
import pandas as pd

def return_bd():
    ee = open("/home/msd/ShortcutTo96/biobank/ukbtable_a.pickle","rb")
    a = pickle.load(ee)[0]
    ee = open("/home/msd/ShortcutTo96/biobank/ukbtable_b.pickle","rb")
    b = pickle.load(ee)[0]
    ee = open("/home/msd/ShortcutTo96/biobank/ukbtable_c.pickle","rb")
    c = pickle.load(ee)[0]
    ee = open("/home/msd/ShortcutTo96/biobank/ukbtable_d.pickle","rb")
    d = pickle.load(ee)[0]
    ee = open("/home/msd/ShortcutTo96/biobank/ukbtable_e.pickle","rb")
    e = pickle.load(ee)[0]
    bd = a.append(b)
    bd = bd.append(c)
    del a
    del b
    del c
    gc.collect()
    bd = bd.append(d)
    bd = bd.append(e)
    del d
    del e
    gc.collect()
    header = bd.iloc[0,:]
    bd.columns = header
    return bd
