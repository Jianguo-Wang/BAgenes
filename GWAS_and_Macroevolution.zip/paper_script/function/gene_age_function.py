import pandas as pd
import os,pickle
from collections import Counter
from scipy.stats import binomtest
import numpy as np

def ensembl_id_name_1(path1):
    with open(path1,'r') as FILE:
        context = FILE.readlines()
    list_1 = []
    for line in context:
        gene_id = line.split('gene_id "')[1].split('";')[0]
        gene_name = line.split('gene_name "')[1].split('";')[0]
        list_1.append((gene_id,gene_name))
    list_2 = list(set(list_1))
    list_3 = pd.DataFrame(list_2)
    list_3.index = list_3.iloc[:,1]
    b = Counter(list_3.iloc[:, 1])
    bbb = [a for a in b if b[a] >1]
    bbb1 = [a for a in b if b[a] ==1]
    list_4 = list_3.loc[bbb1,:]
    dictionary = dict(zip(list_4.iloc[:,1],list_4.iloc[:,0]))#gene name and ensembl stable ID dictionary without gene names having multi stable IDs
    # 1 to 1
    return dictionary

def age_inf(path):
    table_1 = pd.read_csv(path)
    table_mid = table_1.loc[:,['Ensembl ID','SBP Branch','SBP Label']]
    table_mid = table_mid.dropna()
    dict_sbp = dict(zip(table_mid['Ensembl ID'],table_mid['SBP Branch']))
    dict_sbp_label = dict(zip(table_mid['Ensembl ID'], table_mid['SBP Label']))
    table_mid = table_1.loc[:,['Ensembl ID','ProteinHistorian  Branch','ProteinHistorian  Label']]
    table_mid = table_mid.dropna()
    dict_historian = dict(zip(table_mid['Ensembl ID'], table_mid['ProteinHistorian  Branch']))
    dict_historian_label = dict(zip(table_mid['Ensembl ID'], table_mid['ProteinHistorian  Label']))
    return dict_sbp,dict_sbp_label,dict_historian,dict_historian_label

def phenoscanner_extract(path_to_annotation,prefix):
    files2 = os.listdir(path_to_annotation)
    files2_1 = [a for a in files2 if a.startswith('snp_')]
    age_inf_1 = []
    for file in files2_1:
        trait = file.split(prefix)[1].split('.fastGWA')[0]
        context = pd.read_csv(path_to_annotation + file, sep='\t')
        context.insert(loc=0, column='trait', value=[trait] * (context.shape[0]))
        age_inf_1.append(context)
    age_inf_2 = pd.concat(age_inf_1)
    age_inf_2.index = list(range(age_inf_2.shape[0]))
    age_inf_2.insert(loc=0, column='name', value=(age_inf_2.apply(lambda x: "_".join([x.iloc[0], x.iloc[2]]), axis=1)))
    age_inf_2.index = age_inf_2.iloc[:, 0]
    return age_inf_2

def clump_extract(path_to_clump):
    ee = open(path_to_clump, "rb")
    dictionary_o = pickle.load(ee)[0]
    final = []
    for key in dictionary_o.keys():
        mid = pd.DataFrame(dictionary_o[key])
        mid.insert(loc=0, column='trait', value=([key] * (mid.shape[0])))
        final.append(mid)
    final_1 = pd.concat(final)
    snp_with_trait = final_1.apply(lambda x: "_".join([x.iloc[0], x.iloc[2]]), axis=1)
    final_1.insert(loc=0, column='name', value=snp_with_trait)
    final_1.index = final_1.iloc[:, 0]
    return final_1

def gene_age_process_0(gene_names,dict_historian):
    gene_ages = Counter([dict_historian[a] for a in gene_names])
    gene_ages_0 = Counter(dict_historian.values())
    gene_ages_1 = pd.DataFrame([[a, gene_ages[a]] for a in gene_ages.keys()])
    gene_ages_1.index = gene_ages_1.iloc[:, 0].apply(float)
    gene_ages_0_1 = pd.DataFrame([[a, gene_ages_0[a]] for a in gene_ages_0.keys()])
    gene_ages_0_1.index = gene_ages_0_1.iloc[:, 0].apply(float)
    gene_ages_compare = (pd.concat([gene_ages_1.iloc[:, 1], gene_ages_0_1.iloc[:, 1]], axis=1)).sort_index()
    gene_ages_compare1 = gene_ages_compare.copy()
    gene_ages_compare1.columns = ['planA', 'origin']
    gene_ages_compare2 = gene_ages_compare1.copy()
    gene_ages_compare2['planA'] = gene_ages_compare2['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare2['origin'] = gene_ages_compare2['origin'] / (gene_ages_compare1.sum()['origin'])
    list_1 = []
    for n in range(gene_ages_compare2.shape[0]):
        print(n)
        a = binomtest(int(gene_ages[n]), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_0[n] / gene_ages_compare1.sum()['origin']))
        list_1.append(float('%.5g' % a.pvalue))
    gene_ages_compare2.insert(loc=2, column='pvalue', value=list_1)
    # gene older than mammal
    gene_ages_compare3 = (gene_ages_compare1.iloc[gene_ages_compare1.index <1, :]).sum()
    a = binomtest(int(gene_ages_compare3['planA']), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_compare3['origin'] / gene_ages_compare1.sum()['origin']))
    gene_ages_compare3['planA'] = gene_ages_compare3['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare3['origin'] = gene_ages_compare3['origin'] / (gene_ages_compare1.sum()['origin'])
    gene_ages_compare3['pvalue'] = a.pvalue
    gene_ages_compare3.name = 'before_Euteleostomi'
    gene_ages_compare2 = (pd.concat([gene_ages_compare2.T, gene_ages_compare3], axis=1)).T
    return gene_ages_compare,gene_ages_compare1,gene_ages_compare2,gene_ages_compare3

def gene_age_process_1(gene_names,dict_historian):
    gene_ages = Counter([dict_historian[a] for a in gene_names])
    gene_ages_0 = Counter(dict_historian.values())
    gene_ages_1 = pd.DataFrame([[a, gene_ages[a]] for a in gene_ages.keys()])
    gene_ages_1.index = gene_ages_1.iloc[:, 0].apply(float)
    gene_ages_0_1 = pd.DataFrame([[a, gene_ages_0[a]] for a in gene_ages_0.keys()])
    gene_ages_0_1.index = gene_ages_0_1.iloc[:, 0].apply(float)
    gene_ages_compare = (pd.concat([gene_ages_1.iloc[:, 1], gene_ages_0_1.iloc[:, 1]], axis=1)).sort_index()
    gene_ages_compare1 = gene_ages_compare.copy()
    gene_ages_compare1.columns = ['planA', 'origin']
    gene_ages_compare2 = gene_ages_compare1.copy()
    gene_ages_compare2['planA'] = gene_ages_compare2['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare2['origin'] = gene_ages_compare2['origin'] / (gene_ages_compare1.sum()['origin'])
    list_1 = []
    for n in range(gene_ages_compare2.shape[0]):
        print(n)
        a = binomtest(int(gene_ages[n]), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_0[n] / gene_ages_compare1.sum()['origin']))
        list_1.append(float('%.5g' % a.pvalue))
    gene_ages_compare2.insert(loc=2, column='pvalue', value=list_1)
    # gene older than mammal
    gene_ages_compare3 = (gene_ages_compare1.iloc[gene_ages_compare1.index > 8, :]).sum()
    a = binomtest(int(gene_ages_compare3['planA']), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_compare3['origin'] / gene_ages_compare1.sum()['origin']))
    gene_ages_compare3['planA'] = gene_ages_compare3['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare3['origin'] = gene_ages_compare3['origin'] / (gene_ages_compare1.sum()['origin'])
    gene_ages_compare3['pvalue'] = a.pvalue
    gene_ages_compare3.name = 'before_Euteleostomi'
    gene_ages_compare2 = (pd.concat([gene_ages_compare2.T, gene_ages_compare3], axis=1)).T
    return gene_ages_compare,gene_ages_compare1,gene_ages_compare2,gene_ages_compare3


def gene_age_process_2(gene_names,dict_historian):
    gene_ages = Counter([dict_historian[a] for a in gene_names])
    gene_ages_0 = Counter(dict_historian.values())
    gene_ages_1 = pd.DataFrame([[a, gene_ages[a]] for a in gene_ages.keys()])
    gene_ages_1.index = gene_ages_1.iloc[:, 0].apply(float)
    gene_ages_0_1 = pd.DataFrame([[a, gene_ages_0[a]] for a in gene_ages_0.keys()])
    gene_ages_0_1.index = gene_ages_0_1.iloc[:, 0].apply(float)
    gene_ages_compare = (pd.concat([gene_ages_1.iloc[:, 1], gene_ages_0_1.iloc[:, 1]], axis=1)).sort_index()
    gene_ages_compare1 = gene_ages_compare.copy()
    gene_ages_compare1.columns = ['planA', 'origin']
    gene_ages_compare2 = gene_ages_compare1.copy()
    gene_ages_compare2['planA'] = gene_ages_compare2['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare2['origin'] = gene_ages_compare2['origin'] / (gene_ages_compare1.sum()['origin'])
    list_1 = []
    for n in range(1,gene_ages_compare2.shape[0]+1):
        print(n)
        a = binomtest(int(gene_ages[n]), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_0[n] / gene_ages_compare1.sum()['origin']))
        list_1.append(float('%.5g' % a.pvalue))
    gene_ages_compare2.insert(loc=2, column='pvalue', value=list_1)
    # gene older than mammal
    gene_ages_compare3 = (gene_ages_compare1.iloc[gene_ages_compare1.index < 13, :]).sum()
    a = binomtest(int(gene_ages_compare3['planA']), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_compare3['origin'] / gene_ages_compare1.sum()['origin']))
    gene_ages_compare3['planA'] = gene_ages_compare3['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare3['origin'] = gene_ages_compare3['origin'] / (gene_ages_compare1.sum()['origin'])
    gene_ages_compare3['pvalue'] = a.pvalue
    gene_ages_compare3.name = 'before_Euteleostomi'
    gene_ages_compare2 = (pd.concat([gene_ages_compare2.T, gene_ages_compare3], axis=1)).T
    return gene_ages_compare,gene_ages_compare1,gene_ages_compare2,gene_ages_compare3


def gene_age_process_0_greater(gene_names,dict_historian):
    gene_ages = Counter([dict_historian[a] for a in gene_names])
    gene_ages_0 = Counter(dict_historian.values())
    gene_ages_1 = pd.DataFrame([[a, gene_ages[a]] for a in gene_ages.keys()])
    gene_ages_1.index = gene_ages_1.iloc[:, 0].apply(float)
    gene_ages_0_1 = pd.DataFrame([[a, gene_ages_0[a]] for a in gene_ages_0.keys()])
    gene_ages_0_1.index = gene_ages_0_1.iloc[:, 0].apply(float)
    gene_ages_compare = (pd.concat([gene_ages_1.iloc[:, 1], gene_ages_0_1.iloc[:, 1]], axis=1)).sort_index()
    gene_ages_compare1 = gene_ages_compare.copy()
    gene_ages_compare1.columns = ['planA', 'origin']
    gene_ages_compare2 = gene_ages_compare1.copy()
    gene_ages_compare2['planA'] = gene_ages_compare2['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare2['origin'] = gene_ages_compare2['origin'] / (gene_ages_compare1.sum()['origin'])
    list_1 = []
    for n in range(gene_ages_compare2.shape[0]):
        print(n)
        a = binomtest(int(gene_ages[n]), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_0[n] / gene_ages_compare1.sum()['origin']),alternative='greater')
        list_1.append(float('%.5g' % a.pvalue))
    gene_ages_compare2.insert(loc=2, column='pvalue', value=list_1)
    # gene older than mammal
    gene_ages_compare3 = (gene_ages_compare1.iloc[gene_ages_compare1.index <1, :]).sum()
    a = binomtest(int(gene_ages_compare3['planA']), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_compare3['origin'] / gene_ages_compare1.sum()['origin']),alternative='greater')
    gene_ages_compare3['planA'] = gene_ages_compare3['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare3['origin'] = gene_ages_compare3['origin'] / (gene_ages_compare1.sum()['origin'])
    gene_ages_compare3['pvalue'] = a.pvalue
    gene_ages_compare3.name = 'before_Euteleostomi'
    gene_ages_compare2 = (pd.concat([gene_ages_compare2.T, gene_ages_compare3], axis=1)).T
    return gene_ages_compare,gene_ages_compare1,gene_ages_compare2,gene_ages_compare3

def gene_age_process_1_greater(gene_names,dict_historian):
    gene_ages = Counter([dict_historian[a] for a in gene_names])
    gene_ages_0 = Counter(dict_historian.values())
    gene_ages_1 = pd.DataFrame([[a, gene_ages[a]] for a in gene_ages.keys()])
    gene_ages_1.index = gene_ages_1.iloc[:, 0].apply(float)
    gene_ages_0_1 = pd.DataFrame([[a, gene_ages_0[a]] for a in gene_ages_0.keys()])
    gene_ages_0_1.index = gene_ages_0_1.iloc[:, 0].apply(float)
    gene_ages_compare = (pd.concat([gene_ages_1.iloc[:, 1], gene_ages_0_1.iloc[:, 1]], axis=1)).sort_index()
    gene_ages_compare1 = gene_ages_compare.copy()
    gene_ages_compare1.columns = ['planA', 'origin']
    gene_ages_compare2 = gene_ages_compare1.copy()
    gene_ages_compare2['planA'] = gene_ages_compare2['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare2['origin'] = gene_ages_compare2['origin'] / (gene_ages_compare1.sum()['origin'])
    list_1 = []
    for n in range(gene_ages_compare2.shape[0]):
        print(n)
        a = binomtest(int(gene_ages[n]), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_0[n] / gene_ages_compare1.sum()['origin']),alternative='greater')
        list_1.append(float('%.5g' % a.pvalue))
    gene_ages_compare2.insert(loc=2, column='pvalue', value=list_1)
    # gene older than mammal
    gene_ages_compare3 = (gene_ages_compare1.iloc[gene_ages_compare1.index > 8, :]).sum()
    a = binomtest(int(gene_ages_compare3['planA']), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_compare3['origin'] / gene_ages_compare1.sum()['origin']),alternative='greater')
    gene_ages_compare3['planA'] = gene_ages_compare3['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare3['origin'] = gene_ages_compare3['origin'] / (gene_ages_compare1.sum()['origin'])
    gene_ages_compare3['pvalue'] = a.pvalue
    gene_ages_compare3.name = 'before_Euteleostomi'
    gene_ages_compare2 = (pd.concat([gene_ages_compare2.T, gene_ages_compare3], axis=1)).T
    return gene_ages_compare,gene_ages_compare1,gene_ages_compare2,gene_ages_compare3


def gene_age_process_2_greater(gene_names,dict_historian):
    gene_ages = Counter([dict_historian[a] for a in gene_names])
    gene_ages_0 = Counter(dict_historian.values())
    gene_ages_1 = pd.DataFrame([[a, gene_ages[a]] for a in gene_ages.keys()])
    gene_ages_1.index = gene_ages_1.iloc[:, 0].apply(float)
    gene_ages_0_1 = pd.DataFrame([[a, gene_ages_0[a]] for a in gene_ages_0.keys()])
    gene_ages_0_1.index = gene_ages_0_1.iloc[:, 0].apply(float)
    gene_ages_compare = (pd.concat([gene_ages_1.iloc[:, 1], gene_ages_0_1.iloc[:, 1]], axis=1)).sort_index()
    gene_ages_compare1 = gene_ages_compare.copy()
    gene_ages_compare1.columns = ['planA', 'origin']
    gene_ages_compare2 = gene_ages_compare1.copy()
    gene_ages_compare2['planA'] = gene_ages_compare2['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare2['origin'] = gene_ages_compare2['origin'] / (gene_ages_compare1.sum()['origin'])
    list_1 = []
    for n in range(1,gene_ages_compare2.shape[0]+1):
        print(n)
        a = binomtest(int(gene_ages[n]), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_0[n] / gene_ages_compare1.sum()['origin']),alternative='greater')
        list_1.append(float('%.5g' % a.pvalue))
    gene_ages_compare2.insert(loc=2, column='pvalue', value=list_1)
    # gene older than mammal
    gene_ages_compare3 = (gene_ages_compare1.iloc[gene_ages_compare1.index < 13, :]).sum()
    a = binomtest(int(gene_ages_compare3['planA']), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_compare3['origin'] / gene_ages_compare1.sum()['origin']),alternative='greater')
    gene_ages_compare3['planA'] = gene_ages_compare3['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare3['origin'] = gene_ages_compare3['origin'] / (gene_ages_compare1.sum()['origin'])
    gene_ages_compare3['pvalue'] = a.pvalue
    gene_ages_compare3.name = 'before_Euteleostomi'
    gene_ages_compare2 = (pd.concat([gene_ages_compare2.T, gene_ages_compare3], axis=1)).T
    return gene_ages_compare,gene_ages_compare1,gene_ages_compare2,gene_ages_compare3


def gene_age_process_2017_greater(gene_names,dict_historian):
    gene_ages = Counter([dict_historian[a] for a in gene_names])
    gene_ages_0 = Counter(dict_historian.values())
    gene_ages_1 = pd.DataFrame([[a, gene_ages[a]] for a in gene_ages.keys()])
    gene_ages_1.index = gene_ages_1.iloc[:, 0].apply(float)
    gene_ages_0_1 = pd.DataFrame([[a, gene_ages_0[a]] for a in gene_ages_0.keys()])
    gene_ages_0_1.index = gene_ages_0_1.iloc[:, 0].apply(float)
    gene_ages_compare = (pd.concat([gene_ages_1.iloc[:, 1], gene_ages_0_1.iloc[:, 1]], axis=1)).sort_index()
    gene_ages_compare1 = gene_ages_compare.copy()
    gene_ages_compare1.columns = ['planA', 'origin']
    gene_ages_compare2 = gene_ages_compare1.copy()
    gene_ages_compare2['planA'] = gene_ages_compare2['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare2['origin'] = gene_ages_compare2['origin'] / (gene_ages_compare1.sum()['origin'])
    list_1 = []
    for n in range(1,gene_ages_compare2.shape[0]+1):
        print(n)
        a = binomtest(int(gene_ages[n]), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_0[n] / gene_ages_compare1.sum()['origin']),alternative='greater')
        list_1.append(float('%.5g' % a.pvalue))
    gene_ages_compare2.insert(loc=2, column='pvalue', value=list_1)
    # gene older than mammal
    gene_ages_compare3 = (gene_ages_compare1.iloc[gene_ages_compare1.index < 9, :]).sum()
    a = binomtest(int(gene_ages_compare3['planA']), int(gene_ages_compare1.sum()['planA']),p=(gene_ages_compare3['origin'] / gene_ages_compare1.sum()['origin']),alternative='greater')
    gene_ages_compare3['planA'] = gene_ages_compare3['planA'] / (gene_ages_compare1.sum()['planA'])
    gene_ages_compare3['origin'] = gene_ages_compare3['origin'] / (gene_ages_compare1.sum()['origin'])
    gene_ages_compare3['pvalue'] = a.pvalue
    gene_ages_compare3.name = 'before_Euteleostomi'
    gene_ages_compare2 = (pd.concat([gene_ages_compare2.T, gene_ages_compare3], axis=1)).T
    return gene_ages_compare,gene_ages_compare1,gene_ages_compare2,gene_ages_compare3
