import pandas as pd
import scipy
import numpy as np
def asymmetry_1(x1,x2):
    asymmetry = np.lib.scimath.arcsin(abs(x1-x2)/(2*(x1**2+x2**2))**0.5)
    return asymmetry


def symmetry_function_1(bd_0):
    final = pd.DataFrame(bd_0.iloc[:,0])
    for i in range(bd_0.shape[1]/2):
        bd_1 = bd_0.iloc[:,[i*2,i*2+1]]
        bd_mid = bd_1.apply(lambda x: asymmetry_1(x[0],x[1]),axis = 1)
        final = pd.concat([final,bd_mid],axis = 1)
    return