from collections import Counter
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import os,pickle
from multiprocessing import Pool
from collections import Counter
def sample_number_threshold(final,n):
    a = final.isnull().sum().sort_values()
    final_1 = final.loc[:,a[a <n].index]
    return final_1

def topvalue_proportion_threshold(final_1,threshold):
    percent = {}
    for key in final_1.columns:
        final_2 = final_1[key]
        final_3 = final_2.dropna()
        dict_0 = Counter(final_3)
        max_num = np.max(list(dict_0.values()))
        percent[key] = [max_num / (final_3.shape[0]), final_3.shape[0], key]
    outlierq1 = pd.DataFrame([percent[a] for a in percent.keys() if percent[a][0] > threshold])
    outlierq1.columns = ['percent', 'whole', 'name']
    below_50 = set(final_1.columns) - set(outlierq1['name'])
    final_2 = final_1.loc[:, list(below_50)]
    a = final_2.isnull().sum().sort_values()
    final_2 = final_2.loc[:, a.index]
    return final_2

def ancestry_filter(final_2,path_to_ancestry_files):
    bd1_noUK_ancestry_1 = pd.read_csv(path_to_ancestry_files, sep='\t')
    bd1_noUK_ancestry_1.index = bd1_noUK_ancestry_1['eid']
    final_3 = final_2.loc[bd1_noUK_ancestry_1.index, :]
    return final_3

def covariates_process_1(features_0,covariates):
    control_covariates = {}
    error_item = []
    i = 0
    for feature in features_0.columns:
        print(i)
        i+=1
        instance = feature.split('-')[1].split('.')[0]
        covar_list = ['31-0.0','21003-'+instance+'.0','age2-'+instance+'.0','agexsex-'+instance+'.0','age2xsex_'+instance+'.0']+[a for a in covariates.columns if a.split('-')[0] in ['22009']]
        bd_mid = features_0.loc[:,feature]
        covariates_mid = covariates.loc[:,covar_list]
        bd_mid_1 = pd.concat([bd_mid,covariates_mid],axis = 1)
        bd_mid_2 = bd_mid_1.dropna(axis = 0,how = 'any')
        if bd_mid_2.shape[0] == 0:
            error_item.append(feature)
            continue
        reg = LinearRegression().fit(bd_mid_2.iloc[:,1:], bd_mid_2.iloc[:,0])
        residuals = bd_mid_2.iloc[:,0] - reg.predict(bd_mid_2.iloc[:,1:])
        control_covariates[feature] = residuals
    return control_covariates,error_item

def generate_phen_step_1(final_3,bd_fam_path):
    bd_fam = pd.read_csv(bd_fam_path, sep='\t',header=None)
    bd_fam.iloc[:, 1] = bd_fam.iloc[:, 1]
    bd_fam.iloc[:, 0] = bd_fam.iloc[:, 0]
    dictionary = dict(zip(bd_fam.iloc[:, 1], bd_fam.iloc[:, 0]))
    final_3['id'] = final_3.index
    intersect = set(final_3['id']).intersection(set(bd_fam.iloc[:, 1]))
    final_3_1 = final_3.loc[intersect, :]
    final_3_2 = final_3_1.sort_index()
    final_3_2['fam'] = final_3_2['id'].apply(lambda x: dictionary[x])
    final_3_3 = final_3_2.iloc[:,[final_3_2.shape[1] - 1, final_3_2.shape[1] - 2, ] + list(range(final_3_2.shape[1] - 2))]
    return final_3_3

def snp_dictionary_chr(path):
    files = os.listdir(path)
    files1 = [a for a in files if a.endswith('fastGWA') and a.startswith('pval_')]
    snp_names = {'1': [], '2': [], '3': [], '4': [], '5': [], '6': [], '7': [], '8': [], '9': [], '10': [], '11': [],'12': [], '13': [], '14': [], '15': [], '16': [], '17': [], '18': [], '19': [], '20': [], '21': [],'22': []}
    i = 0
    for file in files1:
        i += 1
        print(i)
        data3 = pd.read_csv(path + file,sep='\t')
        n = data3.shape[0]
        m = 0
        while m < n:
            snp_names[str(data3.iloc[m, 1])].append(data3.iloc[m, 2])
            m += 1
    snp_names1 = {}
    for key in snp_names.keys():
        snp_names1[key] = list(set(snp_names[key]))
    return snp_names1

def snp_dictionary_chr_1(path):
    files = os.listdir(path)
    files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]
    snp_names = {'1': [], '2': [], '3': [], '4': [], '5': [], '6': [], '7': [], '8': [], '9': [], '10': [], '11': [],'12': [], '13': [], '14': [], '15': [], '16': [], '17': [], '18': [], '19': [], '20': [], '21': [],'22': []}
    i = 0
    for file in files1:
        i += 1
        print(i)
        data3 = pd.read_csv(path + file,sep='\t',index_col=0)
        n = data3.shape[0]
        m = 0
        while m < n:
            snp_names[str(data3['CHR'].iloc[m])].append(data3['SNP'].iloc[m])
            m += 1
    snp_names1 = {}
    for key in snp_names.keys():
        snp_names1[key] = list(set(snp_names[key]))
    return snp_names1


def symmetry_function_1(bd_0):
    final0 = {}
    for i in range(int(bd_0.shape[1]/2)):
        print(i)
        bd_1 = bd_0.iloc[:,[i*2,i*2+1]]
        bd_mid = np.lib.scimath.arcsin((bd_1.iloc[:,0] - bd_1.iloc[:,1])/((2*((bd_1.iloc[:,0])**2 + (bd_1.iloc[:,1])**2))**0.5))
        final0['_'.join(bd_1.columns)] = bd_mid
    final = pd.DataFrame(final0)
    return final

def process_of_gwas_1(path,file,threshold):
    data3 = pd.read_csv(path+file, sep='\t')
    data3_1 = data3.loc[data3['P'] < threshold, :]
    data3_1.to_csv(path+'pval_' + file,sep = '\t')

def process_of_gwas_2(path,file,threshold,path_out,prefix):
    data3 = pd.read_csv(path + file, sep='\t')
    data3_1 = data3.loc[data3['P'] < threshold, :]
    data3_1.to_csv(path_out + prefix + file, sep='\t')

def clump_packing_1(file,a,path):
    os.system('/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_' + str(a) + '_whole_uk_v2_5  --memory 3000  --clump-r2 0.50 --clump-kb 250    --clump '+path+str(a)+'_'+file+' --out '+path+str(a)+'_' + file )

def clump_packing_2(file,a,path):
    os.system('/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/filtered_' + str(a) + '_uk_ind_ref_1  --memory 3000  --clump-r2 0.50 --clump-kb 250    --clump '+path+str(a)+'_'+file+' --out '+path+str(a)+'_' + file )


def clumped_1_chromosome_phase_1(path):
    files = os.listdir(path)
    files1 = [a for a in files if a.endswith('fastGWA') and a.startswith('pval_')]
    collection = []
    for file in files1:
        data3 = pd.read_csv(path + file, sep='\t')
        if data3.shape[0] == 0:
            print(file)
            continue
        chrs = list(set(data3['CHR']))
        for a in chrs:
            collection.append([file, a])
            data3_1 = data3.loc[data3['CHR'] == a, ['SNP', 'P']]
            data3_1.to_csv(path+'clump/' + str(a) + '_' + file,sep='\t', index=0)
    cores_num = 60
    count = len(collection)
    pool = Pool(processes=cores_num)
    for m in range(count):
        pool.apply_async(clump_packing_1, args=(collection[m][0], collection[m][1], path+'clump/',))
    pool.close()
    pool.join()


def table_annovar_1(path,file):
    os.system('perl /data/user/msd/annovar/table_annovar.pl '+path+file+' /data/user/msd/annovar/humandb/ -buildver hg19 -out '+path+file+'.table_annovar_end -remove -protocol refGene,phastConsElements100way,tfbsConsSites,wgRna,gwasCatalog,EUR.sites.2015_08 -operation g,r,r,r,r,f, -nastring . -csvout -polish')


def clumped_collect_1(clump_path,label1):
    clumped_1_files = os.listdir(clump_path)
    files1 = [a for a in clumped_1_files if a.endswith('clumped')]
    files_name = [a.split(label1)[1].split('.fastGWA')[0] for a in files1]
    files_name1 = list(set(files_name))
    dictionary = {}
    for name in files_name1:
        files2 = [a for a in files1 if a.find(name) != -1]
        i = 0
        dictionary[name] = []
        for name1 in files2:
            with open(clump_path + name1,'r') as FILE:
                context = FILE.readlines()
                context = [a for a in context if a != '\n']
                lines_num = len(context)-1
                m = 0
                while m < lines_num:
                    dictionary[name].append(context[m + 1])
                    m += 1
    dictionary_1 = {}
    for key in dictionary.keys():
        dictionary_1[key] = []
        for item in dictionary[key]:
            item1 = list(filter(lambda x: x != '', item.split(' ')))
            chr = item1[0]
            snp = item1[2]
            position = item1[3]
            p = item1[4]
            total = item1[5]
            snp2 = item1[-1][0:-1].split(',')
            dictionary_1[key].append([chr, snp, position, p, total, snp2])
    return dictionary_1

def clumped_collect_2(clump_path,label1):
    clumped_1_files = os.listdir(clump_path)
    files1 = [a for a in clumped_1_files if a.endswith('clumped')]
    files_name = [a.split(label1)[1].split('_MAF.fastGWA')[0] for a in files1]
    files_name1 = list(set(files_name))
    dictionary = {}
    for name in files_name1:
        files2 = [a for a in files1 if a.find(name) != -1]
        i = 0
        dictionary[name] = []
        for name1 in files2:
            with open(clump_path + name1,'r') as FILE:
                context = FILE.readlines()
                context = [a for a in context if a != '\n']
                lines_num = len(context)-1
                m = 0
                while m < lines_num:
                    dictionary[name].append(context[m + 1])
                    m += 1
    dictionary_1 = {}
    for key in dictionary.keys():
        dictionary_1[key] = []
        for item in dictionary[key]:
            item1 = list(filter(lambda x: x != '', item.split(' ')))
            chr = item1[0]
            snp = item1[2]
            position = item1[3]
            p = item1[4]
            total = item1[5]
            snp2 = item1[-1][0:-1].split(',')
            dictionary_1[key].append([chr, snp, position, p, total, snp2])
    return dictionary_1

def clumped_collect_3(clump_path,label1):
    clumped_1_files = os.listdir(clump_path)
    files1 = [a for a in clumped_1_files if a.endswith('clumped')]
    dictionary = {}
    for file in files1:
        name = file.split(label1)[1].split('_MAF.fastGWA')[0]
        dictionary[name] = []
        with open(clump_path + file,'r') as FILE:
            context = FILE.readlines()
            context = [a for a in context if a != '\n']
            lines_num = len(context)-1
            m = 0
            while m < lines_num:
                dictionary[name].append(context[m + 1])
                m += 1
    dictionary_1 = {}
    for key in dictionary.keys():
        dictionary_1[key] = []
        for item in dictionary[key]:
            item1 = list(filter(lambda x: x != '', item.split(' ')))
            chr = item1[0]
            snp = item1[2]
            position = item1[3]
            p = item1[4]
            total = item1[5]
            snp2 = item1[-1][0:-1].split(',')
            dictionary_1[key].append([chr, snp, position, p, total, snp2])
    return dictionary_1


def compare_clump_packing_1(path_to_phase2_gwas_data, phase_2_prefix, path_to_phase1_clump_inf, batch_name,path_to_out):
    files = os.listdir(path_to_phase2_gwas_data)
    files1 = [a for a in files if a.endswith('fastGWA') and a.startswith(phase_2_prefix)]
    names2 = [a.split(phase_2_prefix)[1].split('.fastGWA')[0] for a in files1]
    ee = open(path_to_phase1_clump_inf, "rb")
    dictionary_o = pickle.load(ee)[0]
    overlap_names = set(names2).intersection(set(dictionary_o.keys()))
    for key in overlap_names:
        origin_1 = dictionary_o[key]
        origin_2 = pd.DataFrame(origin_1)
        origin_2.index = origin_2.iloc[:, 1]
        ref_nouk = pd.read_csv(path_to_phase2_gwas_data + phase_2_prefix + key + '.fastGWA', sep='\t', index_col=0)
        dict_nouk = dict(zip(ref_nouk['SNP'], ref_nouk['P']))
        dict_nouk_1 = dict(zip(ref_nouk['SNP'], ref_nouk['N']))
        dict_nouk_2 = dict(zip(ref_nouk['SNP'], ref_nouk['BETA']))
        inter = set(origin_2.iloc[:, 1]).intersection(set(ref_nouk.iloc[:, 0]))
        origin_3 = origin_2.loc[list(inter), :]
        origin_3_N = origin_3.iloc[:, 1].apply(lambda x: dict_nouk_1[x]).copy()
        origin_2.insert(loc=6, column='N', value=origin_3_N)
        origin_3_BETA = origin_3.iloc[:, 1].apply(lambda x: dict_nouk_2[x]).copy()
        origin_2.insert(loc=7, column='BETA', value=origin_3_BETA)
        origin_3_P = origin_3.iloc[:, 1].apply(lambda x: dict_nouk[x]).copy()
        origin_2.insert(loc=8, column='P', value=origin_3_P)
        origin_2.columns = ['chr', 'index_snp', 'loc', 'p_origin', 'number', 'snps', 'N_origin', 'BETA_origin','P_origin']
        origin_2['chr'] = origin_2['chr'].apply(int).copy()
        origin_2['loc'] = origin_2['loc'].apply(int).copy()
        origin_2 = origin_2.sort_values(by=['chr', 'loc'])
        origin_2.to_csv(path_to_out + batch_name + 'compare_clumped_' + key + '.csv', sep='\t', index=0)
    files3 = os.listdir(path_to_out)
    files1 = [a for a in files3 if a.endswith('csv') and a.startswith(batch_name + 'compare_clumped_')]
    names2 = [a.split(batch_name + 'compare_clumped_')[1].split('.csv')[0] for a in files1]
    collect = []
    for trait in names2:
        aa = pd.read_csv(path_to_out + batch_name + 'compare_clumped_' + trait + '.csv', sep='\t')
        trait_list = [trait] * aa.shape[0]
        aa.insert(loc=0, column='trait', value=trait_list)
        collect.append(aa)
    final = pd.concat(collect)
    final.to_csv(path_to_out + batch_name + 'compare_clumped_all.txt', sep='\t', index=0)
    return final, collect

def p2_random_clump_generate(planA,path_to_p2_gwas,p2_prefix,counts):
    dictionary = Counter(planA['trait'])
    list_r = []
    for m  in range(0,counts):
        print(m)
        dataframe_list = []
        for key in dictionary.keys():
            number = dictionary[key]
            dataframe = pd.read_csv(path_to_p2_gwas+p2_prefix+key+'.fastGWA', sep='\t', index_col=0)
            dataframe1 = dataframe.sample(n = number,)
            dataframe1.insert(loc = 0,column = 'trait',value = [key] * number)
            dataframe_list.append(dataframe1)
        dataframe_combine = pd.concat(dataframe_list)
        list_r.append(dataframe_combine)
    return list_r

def clumped_1_chromosome_phase_2_1(path,prefix):
    files = os.listdir(path)
    files1 = [a for a in files if a.endswith('fastGWA') and a.startswith(prefix)]
    collection = []
    for file in files1:
        print(file)
        data3 = pd.read_csv(path + file, sep='\t')
        name = file.split(prefix)[1].split('.fastGWA')[0]
        if data3.shape[0] == 0:
            print(file)
            continue
        chrs = list(set(data3['CHR']))
        if os.path.exists(path+name):
            pass
        else:
            os.mkdir(path+name)
        for a in chrs:
            collection.append([file, a])
            data3_1 = data3.loc[data3['CHR'] == a, ['SNP', 'P']]
            data3_1.to_csv(path+name+'/' + str(a) + '_' + file,sep='\t', index=0)
    return collection


def clump_packing_3(file,a,path,mem,i):# for phase2
    print('location: '+str(i))
    os.system('/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_' + str(a) + '_whole_uk_v2_5  --memory '+str(mem)+'  --clump-r2 0.50 --clump-kb 250    --clump '+path+str(a)+'_'+file+' --out '+path+str(a)+'_' + file)

def clumped_1_chromosome_phase_2_2(collection,path,cores_num,mem,prefix):
    count = len(collection)
    pool = Pool(processes=cores_num)
    for m in range(count):
        pool.apply_async(clump_packing_3, args=(collection[m][0], collection[m][1], path+collection[m][0].split(prefix)[1].split('.fastGWA')[0]+'/',mem,m,))
    pool.close()
    pool.join()


def process_top_loci(path1,prefix1,collection1):
    chrs = []
    commands1 = []
    for i in range(22):
        m = i+1
        mid = [a for a in collection1 if a[1] == m]
        chrs.append(mid)
    for chr in chrs:
        counts = len(chr)/400
        counts1 = int(counts)+1
        commands = []
        for i in range(counts1):
            text_1 = []
            for combine in chr[i*400:(i+1)*400]:
                text_1.append(path1+combine[0].split(prefix1)[1].split('.fastGWA')[0] + '/' + str(combine[1]) + '_' + combine[0])
            text_2 = ','.join(text_1)
            text_3 = '/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+str(combine[1])+'_whole_uk_v2_5  --clump-r2 0.50 --clump-kb 250    --clump '+text_2+' --out '+path1+'final_chr_'+str(combine[1])+'_'+str(i)+'_out'
            commands.append(text_3)
            os.system(text_3)
        commands1.append(commands)
    return commands1


def extract_clump(path,clump):
    context_1 = []
    with open(path + clump,'r') as FILE:
        context = FILE.readlines()
    context = [a for a in context if a != '\n']
    lines_num = len(context)-1
    m = 0
    while m < lines_num:
        context_1.append(context[m + 1])
        m += 1
    context_2 = [list(filter(lambda x: x != '', context[0].split(' ')))]
    context_2[0][-1] = context_2[0][-1][0:-1]
    for item in context_1:
        item1 = list(filter(lambda x: x != '', item.split(' ')))
        chr = item1[0]
        F = item1[1]
        snp = item1[2]
        position = item1[3]
        p = item1[4]
        total = item1[5]
        nsig = item1[6]
        s05 = item1[7]
        s01 = item1[8]
        s001 = item1[9]
        s0001 = item1[10]
        snp2 = item1[-1][0:-1].split(',')
        context_2.append([chr,F, snp, position, p, total,nsig,s05,s01,s001,s0001, snp2])
    final = pd.DataFrame(context_2[1:])
    final.columns = context_2[0]
    return final
def extract_log(path,log,prefix):
    with open(path + log,'r') as FILE:
        context = FILE.readlines()
    inf_1 = [a for a in context if a.startswith('  --clump ')][0]
    inf_2 = [a.split(prefix)[1].split('.fastGWA')[0] for a in inf_1.split(',')]
    dictionary = {}
    i = 0
    while i < len(inf_2):
        dictionary[str(i+1)] = inf_2[i]
        i+=1
    return dictionary
def sp2_transfer(input,dictionary):
    final = []
    for a in input:
        if a == 'NONE':
            final.append('NONE')
            return final
        index = a.split('(')[1].split(')')[0]
        name = a.split('(')[0]
        trait = dictionary[index]
        final.append(name+'('+trait+')')
    return final

def process_top_loci_1(path,prefix):
    files = [a for a in os.listdir(path) if a.startswith('final_chr_')]
    logs = [a for a in files if a.endswith('log')]
    clumps = [a for a in files if a.endswith('clumped')]
    final_1 = {}
    for i in range(22):
        final_1[i+1] = []
        m = i+1
        clumps_1 = [a for a in clumps if a.startswith('final_chr_'+str(m)+'_')]
        logs_1 = [a for a in logs if a.startswith('final_chr_'+str(m)+'_')]
        counts = len(clumps_1)
        for n in range(counts):
            clump = 'final_chr_'+str(m)+'_'+str(n)+'_out.clumped'
            log = 'final_chr_' + str(m) + '_' + str(n) + '_out.log'
            final = extract_clump(path,clump)
            dictionary = extract_log(path,log,prefix,)
            mid = final['F'].apply(lambda x: dictionary[x])
            final.insert(2,'trait',mid)
            mid1 = final['SP2'].apply(lambda x: sp2_transfer(x,dictionary))
            final.insert(13, 'SP2_with_traits', mid1)
            final_1[i+1].append(final)
    return final_1

def process_function(input):
    a = pd.DataFrame(input)
    a.columns = ['snp','beta','p']
    b = a.sort_values(by = 'p')
    return list(b.iloc[0,:])


def process_function_2(pathname1,pathname2,key,final,i):
    print(i)
    fastgwa1 = pd.read_csv(pathname1, sep='\t')
    fastgwa1.index = fastgwa1['SNP']
    fastgwa2 = pd.read_csv(pathname2, sep='\t')
    fastgwa2.index = fastgwa2['SNP']
    table3 = final[key][0]
    table1 = final[key][1]
    table3_snp_name = table3['SP2_with_traits_3'].apply(lambda x: x[0])
    table11 = table1.loc[:,'SNP']
    table3.insert(0,'snp_other',table3_snp_name)
    table31 = table3.loc[:,'snp_other']
    table_4 = pd.concat([table11,table31])
    dictionary1_beta = dict(zip(fastgwa1['SNP'],fastgwa1['BETA']))
    dictionary1_p = dict(zip(fastgwa1['SNP'],fastgwa1['P']))
    dictionary2_beta = dict(zip(fastgwa2['SNP'],fastgwa2['BETA']))
    dictionary2_p = dict(zip(fastgwa2['SNP'],fastgwa2['P']))
    inter = set(table_4).intersection(set(fastgwa2['SNP']))
    table_4.index = table_4.values
    table_4 = table_4[list(inter)]
    table_41 = table_4.apply(lambda x: dictionary1_beta[x])
    table_42 = table_4.apply(lambda x: dictionary1_p[x])
    table_43 = table_4.apply(lambda x: dictionary2_beta[x])
    table_44 = table_4.apply(lambda x: dictionary2_p[x])
    table_5 = pd.concat([table_4,table_41,table_42,table_43,table_44],axis=1)
    table_5.columns = ['snp','p1_beta','p1_p','p2_beta','p2_p']
    return [key,table_5]

def process_function_3(pathname1,pathname2,key,final,i):
    print(i)
    fastgwa1 = pd.read_csv(pathname1, sep='\t')
    fastgwa1.index = fastgwa1['SNP']
    fastgwa2 = pd.read_csv(pathname2, sep='\t')
    fastgwa2.index = fastgwa2['SNP']
    table1 = final[key][0]
    table11 = table1.loc[:,'SNP']
    table_4 = table11
    dictionary1_beta = dict(zip(fastgwa1['SNP'],fastgwa1['BETA']))
    dictionary1_p = dict(zip(fastgwa1['SNP'],fastgwa1['P']))
    dictionary2_beta = dict(zip(fastgwa2['SNP'],fastgwa2['BETA']))
    dictionary2_p = dict(zip(fastgwa2['SNP'],fastgwa2['P']))
    inter = set(table_4).intersection(set(fastgwa2['SNP']))
    table_4.index = table_4.values
    table_4 = table_4[list(inter)]
    table_41 = table_4.apply(lambda x: dictionary1_beta[x])
    table_42 = table_4.apply(lambda x: dictionary1_p[x])
    table_43 = table_4.apply(lambda x: dictionary2_beta[x])
    table_44 = table_4.apply(lambda x: dictionary2_p[x])
    table_5 = pd.concat([table_4,table_41,table_42,table_43,table_44],axis=1)
    table_5.columns = ['snp','p1_beta','p1_p','p2_beta','p2_p']
    return [key,table_5]


def process_of_gwas_3(pathin,pathout,file,fileout):
    data3 = pd.read_csv(pathin+file, sep='\t')
    if data3.shape[0] == 0:
        pass
    else:
        data3_1 = data3.loc[data3['AF1'] > 0.01, :]
        data3_2 = data3_1.loc[data3_1['AF1'] <0.99, :]
        data3_2.to_csv(pathout + fileout,sep = '\t')
        print(data3_2.shape[0])

def process_of_gwas_4(pathin,pathout,file,fileout):
    data3 = pd.read_csv(pathin+file, sep='\t',index_col = 0)
    if data3.shape[0] == 0:
        pass
    else:
        data3_1 = data3.loc[data3['AF1'] > 0.01, :]
        data3_2 = data3_1.loc[data3_1['AF1'] <0.99, :]
        data3_2.to_csv(pathout + fileout,sep = '\t')
        print(data3_2.shape[0])


def table_annovar_2(file,input_filepathway,output_filepathway):
    os.system('perl /data/user/msd/annovar/table_annovar.pl '+input_filepathway+file+' /data/user/msd/annovar/humandb/ -buildver hg19 -out '+output_filepathway+file+'.table_annovar_end -remove -protocol refGene,ensGene,phastConsElements100way,tfbsConsSites,wgRna,gwasCatalog,EUR.sites.2015_08 -operation g,g,r,r,r,r,f, -nastring . -csvout -polish')


def clump_packing_4(file,path2,path2out):
    os.system('/home/msd/ShortcutTo96/plink1/plink --bfile /data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/clump_ref_genome  --memory 3000  --clump-r2 0.50 --clump-kb 250    --clump '+path2+file+' --out '+path2out+ file)

def clumped_1_chromosome_phase_3_1(path,prefix,pathout):
    files = os.listdir(path)
    files1 = [a for a in files if a.endswith('fastGWA') and a.startswith(prefix)]
    collection = []
    for file in files1:
        data3 = pd.read_csv(path + file, sep='\t')
        if data3.shape[0] == 0:
            print(file)
            continue
        data3.iloc[:,1:].to_csv(pathout+'trans_' +file,sep='\t', index=0)
    return collection

