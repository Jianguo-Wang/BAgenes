import pickle,os
from matplotlib import pyplot as plt
from multiprocessing import Pool
import pandas as pd
from gwas_step import process_of_gwas_1,clump_packing_4,process_of_gwas_3

#for grm
with open('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/mbfile_list_hapmap_pruned_1.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_hapmap_2\n')
#/data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/mbfile_list_hapmap_pruned_1.txt --make-grm-part 4 1 --thread-num 80 --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1 && /data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/mbfile_list_hapmap_pruned_1.txt --make-grm-part 4 2 --thread-num 80 --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1
#nohup /data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/mbfile_list_hapmap_pruned_1.txt --make-grm-part 4 3 --thread-num 80 --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1 &
#nohup /data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/mbfile_list_hapmap_pruned_1.txt --make-grm-part 4 4 --thread-num 80 --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1 &
#cat /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1.part_4_*.grm.id > /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1.grm.id
#cat /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1.part_4_*.grm.bin > /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1.grm.bin
#cat /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1.part_4_*.grm.N.bin > /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1.grm.N.bin

#/data/user/msd/gcta_1.93.3beta2/gcta64 --grm /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1 --make-bK-sparse 0.05 --out /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1_sp_grm

def process_of_gcta_1(i,name):
    command = '/data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/gwas/mbfile_list_test_1.txt --grm-sparse /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1_sp_grm --mpheno '+str(i)+' --fastGWA-mlm --pheno /data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_2.phen  --threads 1 --out /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/geno_assoc_asymmetry_control_1_'+name
    os.system(command)

bd = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_2_0.csv',index_col=0)

cores_num = 100
pool = Pool(processes=cores_num)
for m in range(bd.shape[1]-2):
    print(m)
    pool.apply_async(process_of_gcta_1,args=(m+1,bd.columns[m+2],))
pool.close()
pool.join()

#p-value threshold
def process_of_gwas_1(file):
    print('4')
    data3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/'+file, sep='\t')
    data3_1 = data3.loc[data3['P'] < 5 * 10 ** -8, :]
    data3_1.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/pval_' + file,sep = '\t')
    print(data3_1.shape[0])


files = os.listdir('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/')
files1 = [a for a in files if a.endswith('fastGWA')]
files2 = [a for a in files if a.endswith('log')]
differ = set([a.split('log')[0] for a in files2]).difference(set([a.split('fastGWA')[0] for a in files1]))
print('start')

cores_num = 80
count = (len(files1))//cores_num
remains = (len(files1))%cores_num
print('1')
for i in range(count):
    pool = Pool(processes=cores_num)
    print('2')
    for m in range(cores_num):
        pool.apply_async(process_of_gwas_1,args=(files1[i*80+m],))
        print('3')
    pool.close()
    pool.join()

cores_num = remains
pool = Pool(processes=cores_num)
for m in range(cores_num):
    pool.apply_async(process_of_gwas_1,args=(files1[1280+m],))
pool.close()
pool.join()


#MAF filtering
path1 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/'
path2 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/MAF_GWAS/'
os.system('mkdir '+ path2)
files = os.listdir(path1)
files1 = [a for a in files if a.startswith('pval_')]
files2 = [a for a in files1 if a.endswith('fastGWA')]
cores_num = 80
pool = Pool(processes=cores_num)
for file in files2:
    fileout = file.split('.fastGWA')[0]+'_MAF'+'.fastGWA'
    pool.apply_async(process_of_gwas_3,args=(path1,path2,file,fileout,))
pool.close()
pool.join()

###clump###################################change
files = os.listdir(path2)
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]
os.system('mkdir '+path2+'clump1')

for file in files1:
    data3 = pd.read_csv(path2 + file, sep='\t',index_col=0)
    if data3.shape[0] == 0:
        print(file)
        continue
    data3.iloc[:,1:].to_csv(path2+'clump1/' + file, sep='\t',index=0)

files = os.listdir(path2+'clump1/')
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]

#len(collection) = 723
cores_num = 4
pool = Pool(processes=cores_num)
for m in (files1):
    pool.apply_async(clump_packing_4,args=(m,path2+'clump1/',path2+'clump1/',))
pool.close()
pool.join()



############for top beta compare###########
import pandas as pd
import numpy as np
import pickle,gc,sys
from sklearn.linear_model import LinearRegression
import os,sys,pickle
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from read_bd import return_bd
from gwas_step import sample_number_threshold,topvalue_proportion_threshold,ancestry_filter,covariates_process_1,generate_phen_step_1,snp_dictionary_chr,process_of_gwas_1
final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_features_planA_p2_3.txt',sep = '\t',index_col = 0)
final_3_3 = generate_phen_step_1(final_3,'/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_22_whole_nouk_v11_3_hapmap_2.fam')

final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_features_planA_p2_5.phen',sep = '\t',header = 0,index=0,na_rep = 'NA')
final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_features_planA_p2_5.csv')

with open('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/mbfile_genome_planA_p2_genome_2.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/filtered_'+num+'_whole_nouk_v11_3\n')

from multiprocessing import Pool
import pandas as pd
import os
def process_of_gcta_planA_p3(i,name):
    command = '/data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static --mbfile /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/mbfile_genome_planA_p2_genome_2.txt  --grm-sparse /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_grm_hapmap3_p2_sp_1 --mpheno '+str(i)+' --fastGWA-mlm --pheno /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_features_planA_p2_5.phen  --threads 1 --out /data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/gwas/geno_assoc_asymmetry_planA_p3_'+name
    os.system(command)
bd = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/no_uk_ancestry/planA_phase2/symmetry_features_planA_p2_5.csv',index_col=0)
cores_num = 30
pool = Pool(processes=cores_num)
for m in range(bd.shape[1]-2):
    print(m)
    pool.apply_async(process_of_gcta_planA_p3,args=(m+1,bd.columns[m+2],))
pool.close()
pool.join()
