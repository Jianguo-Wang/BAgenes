#scp -i .Key/Moon/sysu_ls_xlhe_1.id -r sysu_ls_xlhe_1@172.16.22.11:/WORK/sysu_ls_xlhe_1/msd/*best_normalized_end_absB_4* /data/scratch/data_from_msd_ukbiobank/

#python3 /WORK/sysu_ls_xlhe_1/msd/gwas_abs_A_1/absolute_value_plan_A_gwas_execute.py 24 /WORK/sysu_ls_xlhe_1/msd/gwas_abs_A_1/ /WORK/sysu_ls_xlhe_1/msd/gcta64/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static symmetry_features_2_3_abs_3.csv mbfile_list_abs_A.txt symmetry_grm_hapmap3_pruned_1_sp_grm symmetry_features_2_3_abs_3.phen 2 abs_A 1
import pandas as pd
import os,sys
from multiprocessing import Pool
from matplotlib import pyplot as plt
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from read_bd import return_bd
from gwas_step import sample_number_threshold,topvalue_proportion_threshold,ancestry_filter,covariates_process_1,generate_phen_step_1,snp_dictionary_chr,process_of_gwas_1,clumped_1_chromosome_phase_1,snpid2avinput_1,table_annovar_1


files = os.listdir('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1')
files1 = [a for a in files if a.endswith('fastGWA')]
files2 = [a for a in files if a.endswith('log')]

cores_num = 100
pool = Pool(processes=cores_num)
for m in range(len(files1)):
    print(m)
    pool.apply_async(process_of_gwas_1,args=('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/',files1[m],5 * 10 ** -8,))
pool.close()
pool.join()


#MAF filtering
import pandas as pd
import numpy as np
import pickle,gc,sys
from sklearn.linear_model import LinearRegression
import os,sys,pickle
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from multiprocessing import Pool
from read_bd import return_bd
from gwas_step import sample_number_threshold,topvalue_proportion_threshold,ancestry_filter,covariates_process_1,generate_phen_step_1,snp_dictionary_chr,process_of_gwas_1,clump_packing_4,process_of_gwas_3

path1 = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/'
path2 = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/MAF_GWAS/'
os.system('mkdir '+ path2)
files = os.listdir(path1)
files1 = [a for a in files if a.startswith('pval_')]
files2 = [a for a in files1 if a.endswith('fastGWA')]
cores_num = 80
pool = Pool(processes=cores_num)
for file in files2:
    fileout = file.split('.fastGWA')[0]+'_MAF'+'.fastGWA'
    pool.apply_async(process_of_gwas_3,args=(path1,path2,file,fileout,))
pool.close()
pool.join()

###clump###################################change
files = os.listdir(path2)
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]
os.system('mkdir '+path2+'clump1')

for file in files1:
    data3 = pd.read_csv(path2 + file, sep='\t',index_col=0)
    if data3.shape[0] == 0:
        print(file)
        continue
    data3.iloc[:,1:].to_csv(path2+'clump1/' + file, sep='\t',index=0)

files = os.listdir(path2+'clump1/')
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]

#len(collection) = 723
cores_num = 20
pool = Pool(processes=cores_num)
for m in (files1):
    pool.apply_async(clump_packing_4,args=(m,path2+'clump1/',path2+'clump1/',))
pool.close()
pool.join()
#####ok
