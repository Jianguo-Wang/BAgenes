import pandas as pd
import numpy as np
import pickle,gc,sys
from sklearn.linear_model import LinearRegression
import os,sys,pickle
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from multiprocessing import Pool
from read_bd import return_bd
from gwas_step import sample_number_threshold,topvalue_proportion_threshold,ancestry_filter,covariates_process_1,generate_phen_step_1,snp_dictionary_chr,process_of_gwas_1,clump_packing_4,process_of_gwas_3
def process_of_gcta_1(i,name):
    command = '/data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/gwas/mbfile_list_test_1.txt --grm-sparse /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1_sp_grm --mpheno '+str(i)+' --fastGWA-mlm --pheno /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_3.phen  --threads 1 --out /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/geno_assoc_asymmetry_centralized_1_'+name
    os.system(command)

def process_of_gcta_2(i,name):
    command = '/data/user/msd/gcta_1.93.3beta2/gcta64 --mbfile /data/user/msd/ukbiobank_asymmetry/gwas/mbfile_list_test_1.txt --grm-sparse /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/symmetry_grm_hapmap3_pruned_1_sp_grm --mpheno '+str(i)+' --fastGWA-mlm --pheno /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_3.phen  --threads 10 --out /data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/geno_assoc_asymmetry_centralized_1_'+name
    os.system(command)


bd = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_3.csv',index_col=0)

cores_num = 80
count = (bd.shape[1]-2)//cores_num
remains = (bd.shape[1]-2)%cores_num
for i in range(count):
    if i ==0:
        continue
    pool = Pool(processes=cores_num)
    for m in range(cores_num):
        pool.apply_async(process_of_gcta_1,args=(i*80+m+1,bd.columns[i*80+m+2]))
    pool.close()
    pool.join()

cores_num = 80
count = (bd.shape[1]-2)//cores_num
remains = (bd.shape[1]-2)%cores_num
for i in range(count):
    if i ==0:
        pool = Pool(processes=cores_num)
        for m in range(cores_num):
            pool.apply_async(process_of_gcta_1,args=(i*80+m+1,bd.columns[i*80+m+2]))
        pool.close()
        pool.join()
    else:
        continue

cores_num = 80
remains = (bd.shape[1]-2)%cores_num
cores_num = remains
pool = Pool(processes=cores_num)
for m in range(cores_num):
    pool.apply_async(process_of_gcta_2,args=(1280+m+1,bd.columns[1280+m+2]))
pool.close()
pool.join()


#########5e-8
import pandas as pd
import os
from multiprocessing import Pool
def process_of_gwas_1(file):
    data3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/'+file, sep='\t')
    data3_1 = data3.loc[data3['P'] < 5 * 10 ** -8, :]
    data3_1.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/pval_' + file,sep = '\t')

files = os.listdir('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/')
files1 = [a for a in files if a.endswith('fastGWA')]
files2 = [a for a in files if a.endswith('log')]
differ = set([a.split('log')[0] for a in files2]).difference(set([a.split('fastGWA')[0] for a in files1]))
cores_num = 80
count = (len(files1))//cores_num
remains = (len(files1))%cores_num
print('1')
for i in range(count):
    pool = Pool(processes=cores_num)
    print('2')
    for m in range(cores_num):
        pool.apply_async(process_of_gwas_1,args=(files1[i*80+m],))
        print('3')
    pool.close()
    pool.join()

cores_num = remains
pool = Pool(processes=cores_num)
for m in range(cores_num):
    pool.apply_async(process_of_gwas_1,args=(files1[1200+m],))
pool.close()
pool.join()


#MAF filter
path1 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/'
path2 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/gwas/MAF_GWAS/'
os.system('mkdir '+ path2)
files = os.listdir(path1)
files1 = [a for a in files if a.startswith('pval_')]
files2 = [a for a in files1 if a.endswith('fastGWA')]
cores_num = 80
pool = Pool(processes=cores_num)
for file in files2:
    fileout = file.split('.fastGWA')[0]+'_MAF'+'.fastGWA'
    pool.apply_async(process_of_gwas_3,args=(path1,path2,file,fileout,))
pool.close()
pool.join()

###clump###################################change
files = os.listdir(path2)
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]
os.system('mkdir '+path2+'clump1')

for file in files1:
    data3 = pd.read_csv(path2 + file, sep='\t',index_col=0)
    if data3.shape[0] == 0:
        print(file)
        continue
    data3.iloc[:,1:].to_csv(path2+'clump1/' + file, sep='\t',index=0)

files = os.listdir(path2+'clump1/')
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]

#len(collection) = 723
cores_num = 4
pool = Pool(processes=cores_num)
for m in (files1):
    pool.apply_async(clump_packing_4,args=(m,path2+'clump1/',path2+'clump1/',))
pool.close()
pool.join()
#####ok

