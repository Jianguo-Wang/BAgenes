######################################
#####################GWAS#############
######################################

import argparse,os
from multiprocessing import Pool
#python3 ./absolute_value_plan_A_gwas_execute.py 24 /data/scratch/data_from_msd_ukbiobank/ /data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static symmetry_features_2_3_abs_3.csv mbfile_list_abs_A.txt symmetry_grm_hapmap3_pruned_1_sp_grm symmetry_features_2_3_abs_3.phen 2 abs_A 1
#python3 /WORK/sysu_ls_xlhe_1/msd/gwas_abs_A_1/absolute_value_plan_A_gwas_execute.py 24 /WORK/sysu_ls_xlhe_1/msd/gwas_abs_A_1/ /WORK/sysu_ls_xlhe_1/msd/gcta64/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static symmetry_features_2_3_abs_3.csv mbfile_list_abs_A.txt symmetry_grm_hapmap3_pruned_1_sp_grm symmetry_features_2_3_abs_3.phen 2 abs_A 1

def process_of_gcta_abs_A(i,name,path1,path2,batch,mb_name,sp_name,phen_name):
    command = path2 + ' --mbfile '+path1+mb_name+' --grm-sparse '+path1+sp_name+' --mpheno '+str(i)+' --fastGWA-mlm --pheno '+path1+phen_name+'  --threads 1 --out '+path1+'gwas/geno_assoc_asymmetry_'+batch+'_'+name
    print(command)
    os.system(command)

def path_clear(input):
    if input.endswith('/'):
        return input
    else:
        return input+'/'

if __name__ == '__main__':
    parse = argparse.ArgumentParser(description='ukbiobank gwas absolute planA phase1')
    parse.add_argument('cores_number', help='number of cores used')
    parse.add_argument('path1',help='work path')
    parse.add_argument('path2', help='GCTA path')
    parse.add_argument('reference', help='reference name')
    parse.add_argument('mbfile', help='mbfile name')
    parse.add_argument('spgrm', help='sp_grm name prefix')
    parse.add_argument('phen', help='phenotype file name')
    parse.add_argument('multiplex',help='multiple of cores',default=2)
    parse.add_argument('batch_name',help='batch name')
    parse.add_argument('seq_number', help='the sequence of execute')
    args = parse.parse_args()
    cores = args.cores_number
    path1 = path_clear(args.path1)
    path2 = args.path2
    ref = args.reference
    mbf = args.mbfile
    spg = args.spgrm
    pheno = args.phen
    multip = int(args.multiplex)
    batch = args.batch_name
    number = int(args.seq_number)
    if  os.path.exists(path1 +'gwas'):
        pass
    else:
        os.mkdir(path1+'gwas')
    with open(path1+ref, 'r') as f:
        bd = f.readline()
    bd1 = bd[1:-1]
    bd2 = bd1.split(',')#1297
    cores_num = int(cores)
    count = int(multip)
    if (len(bd2)-2-(number-1)*cores_num*multip) < cores_num*multip:
        print('the last part')
        for i in range(count):
            if i == (count-1):
                pool = Pool(processes=(len(bd2)-2-(number-1)*cores_num*multip - (count-1)*cores_num))
                for m in range((len(bd2)-2-(number-1)*cores_num*multip - (count-1)*cores_num)):
                    pool.apply_async(process_of_gcta_abs_A, args=(((number - 1) * cores_num * multip + i * cores_num + m + 1),bd2[(number - 1) * cores_num * multip + i * cores_num + m + 2], path1, path2, batch, mbf, spg,pheno,))
                pool.close()
                pool.join()
            else:
                pool = Pool(processes=cores_num)
                for m in range(cores_num):
                    pool.apply_async(process_of_gcta_abs_A, args=(((number - 1) * cores_num * multip + i * cores_num + m + 1),bd2[(number - 1) * cores_num * multip + i * cores_num + m + 2], path1, path2, batch, mbf, spg, pheno,))
                pool.close()
                pool.join()
    else:
        for i in range(count):
            pool = Pool(processes=cores_num)
            for m in range(cores_num):
                pool.apply_async(process_of_gcta_abs_A,args=(((number-1)*cores_num*multip+i*cores_num+m+1),bd2[(number - 1) * cores_num * multip + i * cores_num + m + 2], path1, path2,batch, mbf, spg, pheno,))
            pool.close()
            pool.join()
######
import pandas as pd
import os,sys
from multiprocessing import Pool
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from read_bd import return_bd
from gwas_step import process_of_gwas_1,clump_packing_1,process_of_gwas_3,clump_packing_4

files = os.listdir('/data/user/msd/ukbiobank_asymmetry/absolute_plan_A_1')
files1 = [a for a in files if a.endswith('fastGWA')]
files2 = [a for a in files if a.endswith('log')]

cores_num = 50
pool = Pool(processes=cores_num)
for m in range(len(files1)):
    print(m)
    pool.apply_async(process_of_gwas_1,args=('/data/user/msd/ukbiobank_asymmetry/absolute_plan_A_1/',files1[m],5 * 10 ** -8,))
pool.close()
pool.join()


path1 = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_A_1/'
path2 = '/data/user/msd/ukbiobank_asymmetry/absolute_plan_A_1/MAF_GWAS/'
os.system('mkdir '+ path2)
files = os.listdir(path1)
files1 = [a for a in files if a.startswith('pval_')]
files2 = [a for a in files1 if a.endswith('fastGWA')]
cores_num = 80
pool = Pool(processes=cores_num)
for file in files2:
    fileout = file.split('.fastGWA')[0]+'_MAF'+'.fastGWA'
    pool.apply_async(process_of_gwas_3,args=(path1,path2,file,fileout,))
pool.close()
pool.join()

###clump###################################change
files = os.listdir(path2)
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]
os.system('mkdir '+path2+'clump1')

for file in files1:
    data3 = pd.read_csv(path2 + file, sep='\t',index_col=0)
    if data3.shape[0] == 0:
        print(file)
        continue
    data3.iloc[:,1:].to_csv(path2+'clump1/' + file, sep='\t',index=0)

files = os.listdir(path2+'clump1/')
files1 = [a for a in files if a.endswith('_MAF.fastGWA') and a.startswith('pval_')]

#len(collection) = 723
cores_num = 20
pool = Pool(processes=cores_num)
for m in (files1):
    pool.apply_async(clump_packing_4,args=(m,path2+'clump1/',path2+'clump1/',))
pool.close()
pool.join()
