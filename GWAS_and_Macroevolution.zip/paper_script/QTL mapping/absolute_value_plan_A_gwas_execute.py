import argparse,os
from multiprocessing import Pool
#python3 ./absolute_value_plan_A_gwas_execute.py 24 /data/scratch/data_from_msd_ukbiobank/ /data/user/msd/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static symmetry_features_2_3_abs_3.csv mbfile_list_abs_A.txt symmetry_grm_hapmap3_pruned_1_sp_grm symmetry_features_2_3_abs_3.phen 2 abs_A 1
#python3 /WORK/sysu_ls_xlhe_1/msd/gwas_abs_A_1/absolute_value_plan_A_gwas_execute.py 24 /WORK/sysu_ls_xlhe_1/msd/gwas_abs_A_1/ /WORK/sysu_ls_xlhe_1/msd/gcta64/gcta_v1.94.0Beta_linux_kernel_3_x86_64/gcta_v1.94.0Beta_linux_kernel_3_x86_64_static symmetry_features_2_3_abs_3.csv mbfile_list_abs_A.txt symmetry_grm_hapmap3_pruned_1_sp_grm symmetry_features_2_3_abs_3.phen 2 abs_A 1

def process_of_gcta_abs_A(i,name,path1,path2,batch,mb_name,sp_name,phen_name):
    command = path2 + ' --mbfile '+path1+mb_name+' --grm-sparse '+path1+sp_name+' --mpheno '+str(i)+' --fastGWA-mlm --pheno '+path1+phen_name+'  --threads 1 --out '+path1+'gwas/geno_assoc_asymmetry_'+batch+'_'+name
    print(command)
    os.system(command)

def path_clear(input):
    if input.endswith('/'):
        return input
    else:
        return input+'/'

if __name__ == '__main__':
    parse = argparse.ArgumentParser(description='ukbiobank gwas absolute planA phase1')
    parse.add_argument('cores_number', help='number of cores used')
    parse.add_argument('path1',help='work path')
    parse.add_argument('path2', help='GCTA path')
    parse.add_argument('reference', help='reference name')
    parse.add_argument('mbfile', help='mbfile name')
    parse.add_argument('spgrm', help='sp_grm name prefix')
    parse.add_argument('phen', help='phenotype file name')
    parse.add_argument('multiplex',help='multiple of cores',default=2)
    parse.add_argument('batch_name',help='batch name')
    parse.add_argument('seq_number', help='the sequence of execute')
    args = parse.parse_args()
    cores = args.cores_number
    path1 = path_clear(args.path1)
    path2 = args.path2
    ref = args.reference
    mbf = args.mbfile
    spg = args.spgrm
    pheno = args.phen
    multip = int(args.multiplex)
    batch = args.batch_name
    number = int(args.seq_number)
    if  os.path.exists(path1 +'gwas'):
        pass
    else:
        os.mkdir(path1+'gwas')
    with open(path1+ref, 'r') as f:
        bd = f.readline()
    bd1 = bd[1:-1]
    bd2 = bd1.split(',')#1297
    cores_num = int(cores)
    count = int(multip)
    if (len(bd2)-2-(number-1)*cores_num*multip) < cores_num*multip:
        print('the last part')
        for i in range(count):
            if i == (count-1):
                pool = Pool(processes=(len(bd2)-2-(number-1)*cores_num*multip - (count-1)*cores_num))
                for m in range((len(bd2)-2-(number-1)*cores_num*multip - (count-1)*cores_num)):
                    pool.apply_async(process_of_gcta_abs_A, args=(((number - 1) * cores_num * multip + i * cores_num + m + 1),bd2[(number - 1) * cores_num * multip + i * cores_num + m + 2], path1, path2, batch, mbf, spg,pheno,))
                pool.close()
                pool.join()
            else:
                pool = Pool(processes=cores_num)
                for m in range(cores_num):
                    pool.apply_async(process_of_gcta_abs_A, args=(((number - 1) * cores_num * multip + i * cores_num + m + 1),bd2[(number - 1) * cores_num * multip + i * cores_num + m + 2], path1, path2, batch, mbf, spg, pheno,))
                pool.close()
                pool.join()
    else:
        for i in range(count):
            pool = Pool(processes=cores_num)
            for m in range(cores_num):
                pool.apply_async(process_of_gcta_abs_A,args=(((number-1)*cores_num*multip+i*cores_num+m+1),bd2[(number - 1) * cores_num * multip + i * cores_num + m + 2], path1, path2,batch, mbf, spg, pheno,))
            pool.close()
            pool.join()
