import pickle,gc,sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

def symmetry_function_1(bd_0):
    final0 = {}
    for i in range(int(bd_0.shape[1]/2)):
        print(i)
        bd_1 = bd_0.iloc[:,[i*2,i*2+1]]
        bd_mid = np.lib.scimath.arcsin((bd_1.iloc[:,0] - bd_1.iloc[:,1])/((2*((bd_1.iloc[:,0])**2 + (bd_1.iloc[:,1])**2))**0.5))
        final0['_'.join(bd_1.columns)] = bd_mid
    final = pd.DataFrame(final0)
    return final
symmetry_features_bd_2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_bd_2.csv',sep = '\t',index_col=0)
drop_list = []
for i in range(int(symmetry_features_bd_2.shape[1] / 2)):
    bd_1 = symmetry_features_bd_2.iloc[:, [i * 2, i * 2 + 1]]
    if bd_1.var()[0] == 0 or bd_1.var()[1] == 0:
        drop_list = drop_list+[[bd_1.columns[0],bd_1.var()[0]],[bd_1.columns[1],bd_1.var()[1]]]
        continue
drop = pd.DataFrame(drop_list)
drop_list_1 = [a[0] for a in drop_list]
symmetry_features_bd_4 = symmetry_features_bd_2.drop(drop_list_1,axis = 1)
mean = symmetry_features_bd_4.mean()
std_1 = symmetry_features_bd_4.std()
mid = symmetry_features_bd_4.sub(mean,axis = 1)
symmetry_features_bd_5 = mid.div(std_1,axis = 1)
symmetry_features_bd_5.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_bd_5.csv',sep = '\t')
symmetry_features_bd_5 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_bd_5.csv',sep = '\t',index_col = 0)

final_0 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2_3_1.csv',sep = '\t',index_col = 0)

final = symmetry_function_1(symmetry_features_bd_5)
final.index = symmetry_features_bd_5.index
[a for a in final_0.columns if a not in final.columns]
final.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_1.csv',sep = '\t')
final = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_1.csv',sep = '\t',index_col = 0)

a = final.isnull().sum().sort_values()
a[a <501506].index
final_1 = final.loc[:,a[a <501506].index]

from collections import Counter
percent = {}
for key in final_1.columns:
    final_2 = final_1[key]
    final_3=  final_2.dropna()
    dict_0 = Counter(final_3)
    max_num = np.max(list(dict_0.values()))
    percent[key] = [max_num/(final_3.shape[0]),final_3.shape[0],key]
outlierq1 = pd.DataFrame([percent[a] for a in percent.keys() if percent[a][0] >0.5])
outlierq1.columns = ['percent','whole','name']
below_50 = set(final_1.columns) - set(outlierq1['name'])
final_2 = final_1.loc[:,list(below_50)]
a = final_2.isnull().sum().sort_values()
final_2 = final_2.loc[:,a.index]

bd1_UK_ancestry_1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/bd1_UK_ancestry.txt',sep = '\t')
bd1_UK_ancestry_1.index = bd1_UK_ancestry_1['eid']
final_3 = final_2.loc[bd1_UK_ancestry_1.index,:]

final_3.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3.csv',sep = '\t')
# to R script process_of_normalized_ture_standardization_uk.R

final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3.csv',sep = '\t',index_col = 0)
#fllowing process_of_normalized_ture_standardization_uk.R

ee = open("/data/user/msd/ukbiobank_asymmetry/phenotype/data/covariates_4.pickle","rb")
covariates_4 = pickle.load(ee)[0]
final = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_1.csv',sep = ',',index_col=0)
final_0 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3.csv',sep = '\t',index_col=0)
final.index = [str(a) for a in final.index]
final.columns = final_0.columns

############################

def covariates_process_1(features_0,covariates):
    control_covariates = {}
    error_item = []
    i = 0
    for feature in features_0.columns:
        print(i)
        i+=1
        instance = feature.split('-')[1].split('.')[0]
        covar_list = ['31-0.0','21003-'+instance+'.0','age2-'+instance+'.0','agexsex-'+instance+'.0','age2xsex_'+instance+'.0']+[a for a in covariates.columns if a.split('-')[0] in ['22009']]
        bd_mid = features_0.loc[:,feature]
        covariates_mid = covariates.loc[:,covar_list]
        bd_mid_1 = pd.concat([bd_mid,covariates_mid],axis = 1)
        bd_mid_2 = bd_mid_1.dropna(axis = 0,how = 'any')
        if bd_mid_2.shape[0] == 0:
            error_item.append(feature)
            continue
        reg = LinearRegression().fit(bd_mid_2.iloc[:,1:], bd_mid_2.iloc[:,0])
        residuals = bd_mid_2.iloc[:,0] - reg.predict(bd_mid_2.iloc[:,1:])
        control_covariates[feature] = residuals
    return control_covariates,error_item

final_2 = covariates_process_1(final,covariates_4)
final_3 = pd.concat(list(final_2[0].values()),axis=1)
with open('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_2.pickle', 'wb') as f:  # Python 3: open(..., 'wb')
    pickle.dump([final_2], f)

ee = open("/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/symmetry_features_centralized_final_3_2.pickle","rb")
final_2 = pickle.load(ee)[0]

final_3.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_2.txt',sep = '\t')
final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_2.txt',sep = '\t',index_col = 0)

bd_fam = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_9_whole_uk_v2_hapmap_2.fam',sep='\t',header=None)
bd_fam.iloc[:,1] = bd_fam.iloc[:,1]
bd_fam.iloc[:,0] = bd_fam.iloc[:,0]
dictionary = dict(zip(bd_fam.iloc[:,1],bd_fam.iloc[:,0]))
final_3['id'] = final_3.index
intersect = set(final_3['id']).intersection(set(bd_fam.iloc[:,1]))
final_3_1 = final_3.loc[intersect,:]
final_3_2 = final_3_1.sort_index()
final_3_2['fam'] = final_3_2['id'].apply(lambda x: dictionary[x])
final_3_3 = final_3_2.iloc[:,[final_3_2.shape[1]-1,final_3_2.shape[1]-2,]+list(range(final_3_2.shape[1]-2))]

final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_3.phen',sep = '\t',header = 0,index=0,na_rep = 'NA')
final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3_3.csv')
