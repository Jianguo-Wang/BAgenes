import sys,os,gc,pickle
import pandas as pd
import numpy as np
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from read_bd import return_bd
from itertools import chain
from sklearn.linear_model import LinearRegression


bd = return_bd()
bd1 = bd.iloc[1:, :]
bd1.index = bd1['eid']

features = pd.read_csv('/data/user/msd/biobank_schema/brain_field.txt',sep = '\t')
features['combine'] = features.apply(lambda x: '_'.join([x[1],str(x[13])]),axis = 1)
left_featrures = [a for a in features['combine'] if 'left' in a]
right_featrures = [a for a in features['combine'] if 'right' in a]
pairs = []
for feature in left_featrures:
    feature1 = feature.replace('left','right')
    if feature1 in right_featrures:
        pairs.append((feature,feature1))
left_more = set(left_featrures) - set([a[0] for a in pairs])

name_code_dict = dict(zip(features['combine'],features['field_id']))
name_code_dict_1 = dict(zip(name_code_dict.keys(),[(name_code_dict[key],key.split('_')[0]) for key in name_code_dict.keys()]))
name_code_dict_symmetry = [[key[0],name_code_dict[key[0]],name_code_dict_1[key[0]][1],key[1],name_code_dict[key[1]],name_code_dict_1[key[1]][1]] for key in pairs]
pair_symmetry = pd.DataFrame(name_code_dict_symmetry)
pair_symmetry_1 = pair_symmetry.iloc[:,[1,2,0,4,5,3]]
pair_symmetry_1.columns = ['left_id','left_name','left_name_with_category','right_id','right_name','right_name_with_category']
pair_symmetry_1.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/pair_symmetry_1.txt',sep = '\t',index = 0)
pair_symmetry_1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/pair_symmetry_1.txt',sep = '\t')

left_features_bd = [a for a in bd1.columns if a.split('-')[0] in [str(b) for b in pair_symmetry_1['left_id']]]
right_features_bd = [a for a in bd1.columns if a.split('-')[0] in [str(b) for b in pair_symmetry_1['right_id']]]
left2right = dict(zip(pair_symmetry_1['left_id'].apply(str),pair_symmetry_1['right_id'].apply(str)))
pair_symmetry_bd_1 = [(a,a.replace(a.split('-')[0],left2right[a.split('-')[0]])) for a in left_features_bd if a.replace(a.split('-')[0],left2right[a.split('-')[0]]) in right_features_bd]
pair_symmetry_bd_1_left = [(int(a[0].split('-')[0]),int(a[0].split('-')[1].split('.')[0]),int(a[0].split('-')[1].split('.')[1])) for a in pair_symmetry_bd_1]
pair_symmetry_bd_1_left_df = pd.DataFrame(pair_symmetry_bd_1_left)
pair_symmetry_bd_1_left_df.columns = ['field','instance','array']
ps_bd_1_left_df_1 = pair_symmetry_bd_1_left_df.sort_values(by = ['field','instance','array'],ascending = [True,True,True])
ps_bd_1_left_df_1['name'] = ps_bd_1_left_df_1.apply(lambda x: '-'.join([str(x[0]),'.'.join([str(x[1]),str(x[2])])]),axis = 1)
ps_dict = dict(zip([a[0] for a in pair_symmetry_bd_1],[a[1] for a in pair_symmetry_bd_1]))
ps_feature_order = list(chain.from_iterable(zip(list(ps_bd_1_left_df_1['name']), [ps_dict[a] for a in ps_bd_1_left_df_1['name']])))
name_code_dict_1 = dict(zip(features['field_id'],features['title']))
dataframe_core = [(a,name_code_dict_1[int(a.split('-')[0])]) for a in ps_feature_order]
symmetry_features = pd.DataFrame(dataframe_core)
symmetry_features.columns = ['code','name']
name_code_dict_2 = dict(zip(features['field_id'],features['value_type']))
symmetry_features['field_id'] = symmetry_features['code'].apply(lambda x: int(x.split('-')[0]))
symmetry_features['value_type'] = symmetry_features['field_id'].apply(lambda x: name_code_dict_2[x])
symmetry_features.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_1.txt',sep = '\t',index = 0)
###value type 11:integer 2X:categorical 31:continuous 41:text 51:date 61 time 101:compound

bd = return_bd()
bd1 = bd.iloc[1:, :]
bd1.index = bd1['eid']
def nan_replace(a):
    if a == '':
        return np.nan
    else:
        return a
symmetry_features = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_1.txt',sep = '\t')
symmetry_features_1 = symmetry_features.loc[symmetry_features.apply(lambda x: x[3] in [11,31],axis = 1),:]
symmetry_features_bd = bd1.loc[:,symmetry_features_1['code']]
symmetry_features_bd_1 = symmetry_features_bd.applymap(nan_replace)
symmetry_features_bd_2 = symmetry_features_bd_1.applymap(lambda x:float(x))
symmetry_features_bd_2.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_bd_2.csv',sep = '\t')
symmetry_features_bd_2 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_bd_2.csv',sep = '\t')

def symmetry_function_1(bd_0):
    final0 = {}
    for i in range(int(bd_0.shape[1]/2)):
        print(i)
        bd_1 = bd_0.iloc[:,[i*2,i*2+1]]
        bd_mid = np.lib.scimath.arcsin((bd_1.iloc[:,0] - bd_1.iloc[:,1])/((2*((bd_1.iloc[:,0])**2 + (bd_1.iloc[:,1])**2))**0.5))
        final0['_'.join(bd_1.columns)] = bd_mid
    final = pd.DataFrame(final0)
    return final

final = symmetry_function_1(symmetry_features_bd_2)
final.index = bd1.index
final.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2.csv',sep = '\t')
final = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2.csv',sep = '\t',index_col = 0)
final = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2.csv',sep = '\t',index_col = 0,nrows = 5)

#sample size
a = final.isnull().sum().sort_values()
a[a <501506].index
final_1 = final.loc[:,a[a <501506].index]
final_1.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2_1.csv',sep = '\t')
final_1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2_1.csv',sep = '\t',index_col = 0)

#max value proportion
from collections import Counter
percent = {}
for key in final_1.columns:
    final_2 = final_1[key]
    final_3=  final_2.dropna()
    dict_0 = Counter(final_3)
    max_num = np.max(list(dict_0.values()))
    percent[key] = [max_num/(final_3.shape[0]),final_3.shape[0],key]
outlierq1 = pd.DataFrame([percent[a] for a in percent if percent[a][0] >0.5])
outlierq1.columns = ['percent','whole','name']

below_50 = set(final_1.columns) - set(outlierq1['name'])
final_2 = final_1.loc[:,list(below_50)]
a = final_2.isnull().sum().sort_values()
final_2 = final_2.loc[:,a.index]
final_2.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2_2.csv',sep = '\t')


#ENGLAND+IRISH
bd1_UK_ancestry_1 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/bd1_UK_ancestry.txt',sep = '\t')
bd1_UK_ancestry_1.index = bd1_UK_ancestry_1['eid']
final_3 = final_2.loc[bd1_UK_ancestry_1.index,:]
final_3.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2_3_1.csv',sep = '\t')

#to R script process_of_normalized_ture_.R
#following process_of_normalized_ture_.R

bd = return_bd()
bd1 = bd.iloc[1:, :]
bd1.index = bd1['eid']

#gender
sex1 = bd1['31-0.0']
sex2 = bd1['22001-0.0']
sex21 = sex2[sex2 != '']
sex11 = sex1[sex21.index]
mid = sex21 == sex11
sex = sex21[mid]
#age
#21003:Age when attended assessment centre  21002:weight  22009:PC
covariates_list = [a for a in bd1.columns if a.split('-')[0] in ['31','21002','21003','22009']]
covariates_0 = bd1.loc[:,covariates_list]
covariates_1 = covariates_0.loc[sex.index,:]

def nan_replace(a):
    if a == '':
        return np.nan
    else:
        return a
covariates_2 = covariates_1.applymap(nan_replace)
covariates_3 = covariates_2.applymap(lambda x:float(x))

covariates_3['age2-0.0'] = covariates_3.loc[:,'21003-0.0']**2
covariates_3['age2-1.0'] = covariates_3.loc[:,'21003-1.0']**2
covariates_3['age2-2.0'] = covariates_3.loc[:,'21003-2.0']**2
covariates_3['age2-3.0'] = covariates_3.loc[:,'21003-3.0']**2
covariates_3['agexsex-0.0'] = covariates_3.loc[:,'21003-0.0']*covariates_3.loc[:,'31-0.0']
covariates_3['agexsex-1.0'] = covariates_3.loc[:,'21003-1.0']*covariates_3.loc[:,'31-0.0']
covariates_3['agexsex-2.0'] = covariates_3.loc[:,'21003-2.0']*covariates_3.loc[:,'31-0.0']
covariates_3['agexsex-3.0'] = covariates_3.loc[:,'21003-3.0']*covariates_3.loc[:,'31-0.0']
covariates_3['age2xsex_0.0'] = covariates_3.loc[:,'age2-0.0']*covariates_3.loc[:,'31-0.0']
covariates_3['age2xsex_1.0'] = covariates_3.loc[:,'age2-1.0']*covariates_3.loc[:,'31-0.0']
covariates_3['age2xsex_2.0'] = covariates_3.loc[:,'age2-2.0']*covariates_3.loc[:,'31-0.0']
covariates_3['age2xsex_3.0'] = covariates_3.loc[:,'age2-3.0']*covariates_3.loc[:,'31-0.0']

covariates_4 = covariates_3.loc[:,[a for a in covariates_3.columns if int(a.split('.')[1]) <= 20]]
with open('/data/user/msd/ukbiobank_asymmetry/phenotype/data/covariates_4.pickle', 'wb') as f:
    pickle.dump([covariates_4], f)

ee = open("/data/user/msd/ukbiobank_asymmetry/phenotype/data/covariates_4.pickle","rb")
covariates_4 = pickle.load(ee)[0]
covariates_4.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/covariates_4.txt',sep = '\t')
final = pd.read_csv('/home/msd/ShortcutTo96/ukbiobank_asymmetry/phenotype/data/normalized_symmetry_features_1.csv',sep = ',',index_col =0)
final_0 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_2_3_1.csv',sep = '\t',index_col = 0)
final.index = [str(a) for a in final.index]
final.columns = final_0.columns

def covariates_process_1(features_0,covariates):
    control_covariates = {}
    error_item = []
    i = 0
    for feature in features_0.columns:
        print(i)
        i+=1
        instance = feature.split('-')[1].split('.')[0]
        covar_list = ['31-0.0','21003-'+instance+'.0','age2-'+instance+'.0','agexsex-'+instance+'.0','age2xsex_'+instance+'.0']+[a for a in covariates.columns if a.split('-')[0] in ['22009']]
        bd_mid = features_0.loc[:,feature]
        covariates_mid = covariates.loc[:,covar_list]
        bd_mid_1 = pd.concat([bd_mid,covariates_mid],axis = 1)
        bd_mid_2 = bd_mid_1.dropna(axis = 0,how = 'any')
        if bd_mid_2.shape[0] == 0:
            error_item.append(feature)
            continue
        reg = LinearRegression().fit(bd_mid_2.iloc[:,1:], bd_mid_2.iloc[:,0])
        residuals = bd_mid_2.iloc[:,0] - reg.predict(bd_mid_2.iloc[:,1:])
        control_covariates[feature] = residuals
    return control_covariates,error_item
final_2 = covariates_process_1(final,covariates_4)
final_3 = pd.concat(list(final_2[0].values()),axis=1)
with open('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_1.pickle', 'wb') as f:
    pickle.dump([final_2], f)

ee = open("/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_1.pickle","rb")
final_2 = pickle.load(ee)[0]
final_3.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_1.txt',sep = '\t')
final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_1.txt',sep = '\t',index_col = 0)
######################################

final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_1.txt',sep = '\t',index_col = 0)

bd_fam = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_9_whole_uk_v2_hapmap_2.fam',sep='\t',header=None)
bd_fam.iloc[:,1] = bd_fam.iloc[:,1]
bd_fam.iloc[:,0] = bd_fam.iloc[:,0]
dictionary = dict(zip(bd_fam.iloc[:,1],bd_fam.iloc[:,0]))
final_3['id'] = final_3.index
intersect = set(final_3['id']).intersection(set(bd_fam.iloc[:,1]))
final_3_1 = final_3.loc[intersect,:]
final_3_2 = final_3_1.sort_index()
final_3_2['fam'] = final_3_2['id'].apply(lambda x: dictionary[x])
final_3_3 = final_3_2.iloc[:,[final_3_2.shape[1]-1,final_3_2.shape[1]-2,]+list(range(final_3_2.shape[1]-2))]
final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_2.phen',sep = '\t',header = 0,index=0,na_rep = 'NA')
final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/phenotype/data/symmetry_features_3_control_2_0.csv')

