import pandas as pd
import numpy as np
import pickle,gc,sys
from sklearn.linear_model import LinearRegression
import os,sys,pickle
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from read_bd import return_bd
from gwas_step import sample_number_threshold,topvalue_proportion_threshold,ancestry_filter,covariates_process_1,generate_phen_step_1,snp_dictionary_chr
final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/centralized_features/symmetry_features_centralized_final_3.csv',sep = '\t',index_col = 0)
final_3_abs = final_3.applymap(lambda x:np.absolute(x))
final_3_abs.to_csv('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_1.csv',sep = '\t')
##R process_of_normalized_planA_abs_1.R
ee = open("/data/user/msd/ukbiobank_asymmetry/phenotype/data/covariates_4.pickle","rb")
covariates_4 = pickle.load(ee)[0]
final = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_2.csv',sep = ',',index_col=0)
final_0 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_1.csv',sep = '\t',index_col=0)
l1 = final.columns
l2 = ['.'.join(['-'.join([(a[1:].split('.'))[0],(a[1:].split('.'))[1]]),'-'.join([(a[1:].split('.'))[2],(a[1:].split('.'))[3]]),(a[1:].split('.'))[4]]) for a in l1 ]
final.index = [str(a) for a in final.index]
final.columns = l2

final_2 = covariates_process_1(final,covariates_4)
final_3 = pd.concat(list(final_2[0].values()),axis=1)
with open('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_3.pickle', 'wb') as f:  # Python 3: open(..., 'wb')
    pickle.dump([final_2], f)

ee = open("/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_3.pickle","rb")
final_2 = pickle.load(ee)[0]
final_3.to_csv('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_3.txt',sep = '\t')
final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_3.txt',sep = '\t',index_col = 0)

#########################417 complete

final_3 = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_3.txt',sep = '\t',index_col = 0)
final_3_3 = generate_phen_step_1(final_3,'/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_9_whole_uk_v2_hapmap_2.fam')
final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_4.phen',sep = '\t',header = 0,index=0,na_rep = 'NA')
final_3_3.to_csv('/data/user/msd/ukbiobank_asymmetry/absolute_plan_B_1/symmetry_features_centralized_abs_4.csv')
