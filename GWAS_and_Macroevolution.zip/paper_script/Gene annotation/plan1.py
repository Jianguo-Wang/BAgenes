import pandas as pd
import numpy as np
import pickle,gc,sys
from sklearn.linear_model import LinearRegression
import os,sys,pickle
sys.path.append("/data/user/msd/ukbiobank_asymmetry/function/")
from multiprocessing import Pool
from read_bd import return_bd
from gwas_step import table_annovar_2

path1 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/'
path2 = '/data/user/msd/ukbiobank_asymmetry/gwas_asymmetry/MAF_GWAS/'
#phenoscanner snp id
files = os.listdir(path2)
files = [a for a in files if a.startswith('pval')]
i = 0
for file in files:
    i+=1
    print(i)
    data = pd.read_table(path2+file)
    if data.shape[0] == 0:
        continue
    else:
        names = data['SNP']
        names.to_csv(path2+'name_'+file,header=0,index=0)

#avinput transform
files = os.listdir(path2)
files = [a for a in files if a.startswith('pval')]

ee = open("/data/user/msd/ukbiobank_asymmetry/ukb_mfi_2.pickle","rb")
list_3 = pickle.load(ee)
dict3 = dict(zip(list_3['RS_id'],list_3['Allele1']))
dict4 = dict(zip(list_3['RS_id'],list_3['Allele2']))
dict1 = dict(zip(list_3['RS_id'],list_3['Position']))
dict2 = dict(zip(list_3['RS_id'],list_3['end_position']))
path3 = path2+'annovar_annotation/'
os.system('mkdir '+path3)

i = 0
for file in files:
    i+=1
    print(i)
    data = pd.read_table(path2+file)
    if data.shape[0] == 0:
        continue
    else:
        mid1 = data['SNP'].apply(lambda x:dict1[x])
        mid2 = data['SNP'].apply(lambda x: dict2[x])
        mid3 = data['SNP'].apply(lambda x: dict3[x])
        mid4 = data['SNP'].apply(lambda x: dict4[x])
        mid5 = data['CHR']
        mid = pd.concat([mid5,mid1,mid2,mid3,mid4,data['SNP']],axis=1)
        mid.to_csv(path3+file.replace('fastGWA','avinput'),header=0,index=0,sep='\t')

#annovar annotation
files = os.listdir(path3)
files = [a for a in files if a.endswith('avinput')]

print('start')

cores_num = 60
pool = Pool(processes=cores_num)
for i in range(len(files)):
    print(i)
    pool.apply_async(table_annovar_2,args=(files[i],path3,path3))
pool.close()
pool.join()
