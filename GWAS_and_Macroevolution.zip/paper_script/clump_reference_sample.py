#all unrelated sample:
#10000 individuals
#for clump and cojo
import pandas as pd
relative = pd.read_csv('/data/user/msd/biobank/ukb54148_rel_s488239.dat', sep=' ',)
list_relative = list(set(list(relative['ID1'])+list(relative['ID2'])))
list_relative_1 = [str(a) for a in list_relative]

fam_format = pd.read_csv('/data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_1_whole_uk_v2_5.fam', sep='\t',header = None)#换成2——5
fam_format.index = [str(a) for a in fam_format.iloc[:,1]]
uk_ind_with_geno = set(fam_format.index)-set(list_relative_1)
fam_format_1= fam_format.loc[list(uk_ind_with_geno),:]
fam_format_2 = fam_format_1.sample(n=10000)
fam_format_2.iloc[:,[0,1]].to_csv('/data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/filter_uk_rel.txt', sep = ' ',header=0,index=0,na_rep = 'NA')

text = []
for num in [str(a+1) for a in list(range(22))]:
    text.append('/home/msd/ShortcutTo96/plink2/plink2 --bfile /data/user/msd/ukbiobank_asymmetry/genotype/genotype_2/filtered_'+num+'_whole_uk_v2_5 --keep  /data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/filter_uk_rel.txt --memory 30000 --make-bed --out /data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/filtered_'+num+'_uk_ind_ref_1')
' && '.join(text)

with open('/data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/merge_file_1.txt', 'w') as f:
    for num in [str(a+1) for a in list(range(22))]:
        f.write('/data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/filtered_'+num+'_uk_ind_ref_1\n')

'/home/msd/ShortcutTo96/plink1/plink --merge-list /data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/merge_file_1.txt --make-bed --out /data/user/msd/ukbiobank_asymmetry/clump_ukbiobank_reference/clump_ref_genome'